
%connected fixed to fixed

clear
format long

alpha = 1.4;
beta  = 0.3;
epsi  = 0.001;
N     = 110;        %Polynomial approximation order
scale = 1;
 x0 =[1;1];

%Fixed Point of Henon Imp
 p0 = Newton_for_Henon_fixed_point(x0,alpha,beta,epsi);
 
 p3=[-3;3];
p_f2 = Newton_for_Henon_fixed_point(p3,alpha,beta,epsi);


figure
hold on
plot(p0(1), p0(2), 'r*')
plot(p_f2(1), p_f2(2), 'b*')
hold off

%Eigenvalues and Eigen Vectors
[R,Sigma] = eigs(Diff_for_Eigen(p0,alpha,beta, epsi)); 

 P = zeros(2,N+1);
 Q = zeros(2,N+1);
 Lambda = Sigma(1,1);
 Tambda = Sigma(2,2);
 mu = Lambda^(-1);
 nu=Tambda^(-1);
 P(:,1) = p0;
 P(:,2) = scale*R(:,1);
 Q(:,1) =p0;
 Q(:,2)=scale*R(:,2);
 P;
 Q ;
  
[P,Q]=  fixed_cauchy(P,Q,p0,mu,nu,alpha,beta,epsi,N);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[R1,Sigma1] = eigs(Diff_for_Eigen(p_f2,alpha,beta, epsi));
 P_1 = zeros(2,N+1);
 Q_1 = zeros(2,N+1);
 Lambda_1 = Sigma1(1,1);
 Tambda_1 = Sigma1(2,2);
 mu_1 = Lambda_1^(-1);
 nu_1=Tambda_1^(-1);
 P_1(:,1) = p_f2;
 P_1(:,2) = scale*R1(:,1);
 Q_1(:,1) =p_f2;
 Q_1(:,2)=scale*R1(:,2);
 
[P_1,Q_1] =fixed_cauchy(P_1,Q_1,p_f2,mu_1,nu_1,alpha,beta,epsi,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


numPoints = 20000;
NumR =500;
radii = 0.9*abs(mu);
Thetas = linspace(-1,1, numPoints);
Thetas1 = linspace(radii,1,NumR);
Wu1 = [real(polyval(fliplr(P(1, :)), Thetas));
                   real(polyval(fliplr(P(2, :)), Thetas))];
               
Ws1 = [real(polyval(fliplr(Q(1, :)), Thetas));
                   real(polyval(fliplr(Q(2, :)), Thetas))];
               
Wuc =  [real(polyval(fliplr(P(1, :)), Thetas1));
                   real(polyval(fliplr(P(2, :)), Thetas1))];              
Wsc = [real(polyval(fliplr(Q(1, :)), Thetas1));
                   real(polyval(fliplr(Q(2, :)), Thetas1))];                 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f2_Wu1 = [real(polyval(fliplr(P_1(1, :)), Thetas));
                   real(polyval(fliplr(P_1(2, :)), Thetas))];
               
f2_Ws1 = [real(polyval(fliplr(Q_1(1, :)), Thetas));
                   real(polyval(fliplr(Q_1(2, :)), Thetas))];
               
f2_Wuc =  [real(polyval(fliplr(P_1(1, :)), Thetas1));
                   real(polyval(fliplr(P_1(2, :)), Thetas1))];              
f2_Wsc = [real(polyval(fliplr(Q_1(1, :)), Thetas1));
                   real(polyval(fliplr(Q_1(2, :)), Thetas1))]; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Homoclinic
               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 S = Wuc;
%  S1= Wsc;
 K = 4;
 iterates_S=zeros(2,NumR,K);
%  iterates_S1=zeros(2,NumR,K);
 iterates_S(:,:,1)= S;
%  iterates_S1(:,:,1)= S1;
 
 for j=2:K
    for i=1:NumR
       u0=iterates_S(:,i,j-1); %unstable 
%        v0=iterates_S1(:,i,j-1); %stable
       y =for_function(u0,alpha,beta);
%        x = back_function(v0,alpha,beta);
       iterates_S(:,i,j)=Newton_for_orbit(y,u0,alpha,beta,epsi);
%        iterates_S1(:,i,j)=Newton_back_function(x,v0,alpha,beta,epsi);
    end
 end   
iterates_S;
% iterates_S1;




figure
hold on
  plot(Wu1(1,:), Wu1(2,:), 'b')
  plot(Ws1(1,:), Ws1(2,:), 'r') 
  plot(Wuc(1,:), Wuc(2,:), '*')
  plot(Wsc(1,:), Wsc(2,:), 'r')   
  
  for i=2:K
     plot(iterates_S(1,:,i),iterates_S(2,:,i),'b')
%      plot(iterates_S1(1,:,i),iterates_S1(2,:,i),'*')
 end
 
plot(p0(1), p0(2), 'k*')  
hold off  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
 %%This is for the fixed point to fixed point where unstable meet
 % stable of other

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 S = f2_Wuc;
 S1= f2_Wsc;
 K = 10;
 iterates_S=zeros(2,NumR,K);
 iterates_S1=zeros(2,NumR,K);
 iterates_S(:,:,1)= S;
 iterates_S1(:,:,1)= S1;
 
 for j=2:K
    for i=1:NumR
       u0=iterates_S(:,i,j-1); %unstable 
%        v0=iterates_S1(:,i,j-1); %stable
       y =for_function(u0,alpha,beta);
%        x = back_function(v0,alpha,beta);
       iterates_S(:,i,j)=Newton_for_orbit(y,u0,alpha,beta,epsi);
%        iterates_S1(:,i,j)=Newton_back_function(x,v0,alpha,beta,epsi);
    end
 end   

figure
hold on
  plot(Wu1(1,:), Wu1(2,:), 'b')
  plot(Ws1(1,:), Ws1(2,:), 'r') 
  plot(Wuc(1,:), Wuc(2,:), 'b')
%   plot(Wsc(1,:), Wsc(2,:), '*') 

  plot(f2_Wu1(1,:), f2_Wu1(2,:), 'b')
  plot(f2_Ws1(1,:), f2_Ws1(2,:), 'r') 
  plot(f2_Wuc(1,:), f2_Wuc(2,:), 'b*')
  plot(f2_Wsc(1,:), f2_Wsc(2,:), 'r') 
  
  
  for i=2:K
     plot(iterates_S(1,:,i),iterates_S(2,:,i),'b*')
%      plot(iterates_S1(1,:,i),iterates_S1(2,:,i),'*')
 end
 
  plot(p0(1), p0(2), 'k*')
  plot(p_f2(1), p_f2(2),'m*')
hold off

