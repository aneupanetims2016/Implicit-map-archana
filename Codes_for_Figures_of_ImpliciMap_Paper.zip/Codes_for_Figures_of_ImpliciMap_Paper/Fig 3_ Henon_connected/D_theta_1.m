function D_theta_test = D_theta_1(P,N,theta)
P1 = P(:,2:end);

for k=1:N
    P1(:,k)= k*P1(:,k);
end   
 D_theta_test = [real(polyval(fliplr(P1(1, :)), theta));
                    real(polyval(fliplr(P1(2, :)), theta))];