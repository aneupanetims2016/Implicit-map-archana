function x= connected_newton(N,P,P2,theta,x1,x2,sigma,alpha,beta,epsi,K)
x=[theta;x1(1);x1(2);x2(1);x2(2);sigma;];
error=1;
 count=0;
 while(error>10^(-14))
     count=count+1     
    F= connect_function(K,P,P2,x,alpha,beta,epsi);
    DF=DF_connected(K,P,P2,x,alpha,beta,epsi,N);
    h=(-1)*linsolve(DF,F);
    error=norm(h)
    x=x+h;  
       
   
 end       

