function Fx= connect_function(K,P,Q,x0,alpha,beta,epsi)
x=x0;
K=2*(K+1);
F=zeros(K,1);
F(1,1)=real(polyval(fliplr(P(1, :)),x(1)))-x(2);
F(2,1)=real(polyval(fliplr(P(2, :)),x(1)))-x(3);
F(K-1,1)= x(K-2)-real(polyval(fliplr(Q(1, :)),1i*x(K)));
F(K,1) = x(K-1)-real(polyval(fliplr(Q(2, :)),1i*x(K)));
for i=1:(K-4)/2
    F(2*i+1,1)=x(2*i+2)-(1-alpha*x(2*i)^2+x(2*i+1)+epsi*x(2*i+2)^5);
    F(2*i+2,1)=x(2*i+3)-beta*x(2*i)+epsi*x(2*i+3)^5;    
end
Fx=F;

