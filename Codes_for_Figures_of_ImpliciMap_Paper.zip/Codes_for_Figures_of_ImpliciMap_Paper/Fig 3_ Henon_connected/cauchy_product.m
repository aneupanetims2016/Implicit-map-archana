function [P,Q]=  cauchy_product(P,Q,Df1,Df2,lambda,a,epsi,N)

 
for n = 2:N
     
%     %Compute the homological matrix:    
     A1=Df1 + lambda^n*Df2;
     
%     
%     %Compute the right hand side of the homological equatoin:
     temp_P1 = P(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum3 = a*sum(temp_P1.*temp_P2);    %a^2 %Cauchy Product    
          
     temp_Q1 = Q(1, 1:n+1);
     temp_Q1(1) = 0;
     temp_Q1(n+1) = 0;
     temp_Q2 = fliplr(temp_Q1); 
     
     sum1 = a*sum(temp_Q1.*temp_Q2);  %c^2  %Cauchy Product  
     
     

     
     sum2 = epsi*conv5(P(1, 1:n+1), n)*lambda^n;  %a^5
     

     sum4 = epsi*conv5(P(2, 1:n+1), n)*lambda^n;   %b^5
     
     

     sum5 = epsi*conv5(Q(1, 1:n+1), n)*lambda^n;  %c^5
     

     sum6 = epsi*conv5(Q(2, 1:n+1), n)*lambda^n;  %d^5
     
     sum7= -sum1+sum2;
     sum8= -sum4;
     sum9= -sum3+sum5;
     sum10= -sum6;
     
       
%     %Solve the homological equation:
    
     thisCoef=A1\[sum7;sum8;sum9;sum10];
    
%     %Assigna the Taylor coefficients:
     P(:, n+1) = thisCoef(1:2);
     Q(:, n+1) = thisCoef(3:4);
 end



end

