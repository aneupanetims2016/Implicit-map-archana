
%This work is for fixed to periodic connection.

clear
format long

alpha = 1.4;
beta = 0.3;
epsi=0.001;
N = 50;        %Polynomial approximation order
scale = 1.5;      %scaling/length of the eigenvector

%%Period points

p1 = [0; 1; 1;-1];

p_p = Imp_per2Newton(p1, alpha, beta,epsi);

%%Fixed points
p2 = [-3;3];
p_f1 = Newton_for_Henon_fixed_point(p2,alpha,beta,epsi);

p3=[1;3];
p_f2 = Newton_for_Henon_fixed_point(p3,alpha,beta,epsi);


p_p1 = p_p(1:2);
p_p2 = p_p(3:4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure
% hold on
% plot(p_p1(1), p_p1(2), 'k*')
% plot(p_p2(1), p_p2(2), 'b*')
% plot(p_f1(1), p_f1(2), 'r*')
% plot(p_f2(1), p_f2(2), 'm*')
% hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Working for periodic points%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Dfp1 = Imp_henonPer2Diff(p_p, alpha, beta,epsi);
[R_p, Sigma_p] = eigs(Dfp1);
lambda1 = Sigma_p(1,1);
v_1 = R_p(:,1);
lambda3=Sigma_p(3,3);
v_3 = R_p(:,3);
Df1 = [0,0,2*alpha*p_p(3),-1;0,0,-beta,0; 2*alpha*p_p(1),-1,0,0;-beta,0,0,0];
Df2 = [1-5*epsi*p_p(1)*p_p(1)*p_p(1)*p_p(1),0,0,0;...
    0,1+5*epsi*p_p(2)*p_p(2)*p_p(2)*p_p(2),0,0;...
    0,0,1-5*epsi*p_p(3)*p_p(3)*p_p(3)*p_p(3),0;...
    0,0,0,1+5*epsi*p_p(4)*p_p(4)*p_p(4)*p_p(4)];
P1 = zeros(2,N+1);
Q1 = zeros(2,N+1);
P2 = zeros(2,N+1);
Q2 = zeros(2,N+1);

P1(:, 1) = p_p1;
Q1(:, 1) = p_p2;
P2(:, 1) = p_p1;
Q2(:, 1) = p_p2;

S1= scale*v_1;
P1(:, 2)=S1(1:2);
Q1(:, 2)=S1(3:4);

S3= scale*v_3;
P2(:, 2)=S3(1:2);
Q2(:, 2)=S3(3:4);
 
[P1,Q1]= cauchy_product(P1,Q1,Df1,Df2,lambda1,alpha,epsi,N);
[P2,Q2]= cauchy_product(P2,Q2,Df1,Df2,lambda3,alpha,epsi,N);

numPoints = 20000;
mu=lambda1^(-1);
radii1=abs(mu)/800;
NumR=500;
 Thetas = linspace(-1,1, numPoints);
 Thetas11 = linspace(radii1,-1,NumR);
 Wu1 = [real(polyval(fliplr(P1(1, :)), Thetas));
                   real(polyval(fliplr(P1(2, :)), Thetas))];
     
 Wu2 = [real(polyval(fliplr(Q1(1, :)), 1i*Thetas));
                   real(polyval(fliplr(Q1(2, :)), 1i*Thetas))];
 
Ws1 = [real(polyval(fliplr(P2(1, :)), 1i*Thetas));
                   real(polyval(fliplr(P2(2, :)), 1i*Thetas))];
Ws2 = [real(polyval(fliplr(Q2(1, :)), Thetas));
                   real(polyval(fliplr(Q2(2, :)), Thetas))]; 
               
 Wsc1 = [real(polyval(fliplr(P2(1, :)), 1i*Thetas11));
                   real(polyval(fliplr(P2(2, :)), 1i*Thetas11))];  
                
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%               
%%For fixed Point%%%%This is fixed point we arae checking for
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[R,Sigma] = eigs(Diff_for_Eigen(p_f1,alpha,beta, epsi));
 P = zeros(2,N+1);
 Q = zeros(2,N+1);
 Lambda = Sigma(1,1);
 Tambda = Sigma(2,2);
 mu = Lambda^(-1);
 nu=Tambda^(-1);
 P(:,1) = p_f1;
 P(:,2) = scale*R(:,1);
 Q(:,1) =p_f1;
 Q(:,2)=scale*R(:,2);
 
[P,Q] =fixed_cauchy(P,Q,p_f1,mu,nu,alpha,beta,epsi,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 [R1,Sigma1] = eigs(Diff_for_Eigen(p_f2,alpha,beta, epsi));
 P_1 = zeros(2,N+1);
 Q_1 = zeros(2,N+1);
 Lambda_1 = Sigma1(1,1);
 Tambda_1 = Sigma1(2,2);
 mu_1 = Lambda_1^(-1);
 nu_1=Tambda_1^(-1);
 P_1(:,1) = p_f2;
 P_1(:,2) = scale*R1(:,1);
 Q_1(:,1) =p_f2;
 Q_1(:,2)=scale*R1(:,2);
 
[P_1,Q_1] =fixed_cauchy(P_1,Q_1,p_f2,mu_1,nu_1,alpha,beta,epsi,N);

NumR =500;
radii = abs(mu);
Thetas = linspace(-1,1, numPoints);
Thetas1 = linspace(radii,1,NumR);
f1_Wu1 = [real(polyval(fliplr(P(1, :)), Thetas));
                   real(polyval(fliplr(P(2, :)), Thetas))];
               
f1_Ws1 = [real(polyval(fliplr(Q(1, :)), Thetas));
                   real(polyval(fliplr(Q(2, :)), Thetas))];
               
f1_Wuc =  [real(polyval(fliplr(P(1, :)), Thetas1));
                   real(polyval(fliplr(P(2, :)), Thetas1))];              
f1_Wsc = [real(polyval(fliplr(Q(1, :)), Thetas1));
                   real(polyval(fliplr(Q(2, :)), Thetas1))]; 
               
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
   
 f2_Wu1 = [real(polyval(fliplr(P_1(1, :)), Thetas));
                   real(polyval(fliplr(P_1(2, :)), Thetas))];
               
f2_Ws1 = [real(polyval(fliplr(Q_1(1, :)), Thetas));
                   real(polyval(fliplr(Q_1(2, :)), Thetas))];
               
f2_Wuc =  [real(polyval(fliplr(P_1(1, :)), Thetas1));
                   real(polyval(fliplr(P_1(2, :)), Thetas1))];              
f2_Wsc = [real(polyval(fliplr(Q_1(1, :)), Thetas1));
                   real(polyval(fliplr(Q_1(2, :)), Thetas1))];   
   
   %For iterations of fixed point unstable
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 S = f1_Wuc;
 K=4; 
 iterates_S=zeros(2,NumR,K);
 iterates_S(:,:,1)= S;

 
 for j=2:K
    for i=1:NumR
       u0=iterates_S(:,i,j-1); %unstable 
       y =for_function(u0,alpha,beta);
       iterates_S(:,i,j)=Newton_for_orbit(y,u0,alpha,beta,epsi);
    end
 end   
iterates_S;


figure
hold on
  xlim([-2 2])
  ylim([-2 2])
  plot(f1_Wu1(1,:), f1_Wu1(2,:), 'b.')
  plot(f1_Ws1(1,:), f1_Ws1(2,:), 'r.') 
  plot(f1_Wuc(1,:), f1_Wuc(2,:), '.')
  plot(f1_Wsc(1,:), f1_Wsc(2,:), 'm.') 
  
%   plot(Wu1(1,:), Wu1(2,:), 'b')
%   plot(Wu2(1,:), Wu2(2,:), 'b')
  plot(Ws1(1,:), Ws1(2,:),'r.')
%   plot(Ws2(1,:), Ws2(2,:),'r')
   plot(Wsc1(1,:), Wsc1(2,:),'r.')
  
%   plot(f2_Wu1(1,:), f2_Wu1(2,:), 'b')
%   plot(f2_Ws1(1,:), f2_Ws1(2,:), 'r') 
%   plot(f2_Wuc(1,:), f2_Wuc(2,:), 'b')
%   plot(f2_Wsc(1,:), f2_Wsc(2,:), 'r')  
  
  
  for i=2:K
     plot(iterates_S(1,:,i),iterates_S(2,:,i),'k.')

 end
 
plot(p_p1(1), p_p1(2), 'g*')
plot(p_p2(1), p_p2(2), 'b*')
plot(p_f1(1), p_f1(2), 'r*')
plot(p_f2(1), p_f2(2), 'm*')
  K1=iterates_S(:,:,K);
  K2 = Wsc1;
  

%    plot(K1(1,:),K1(2,:),'k.')
%    plot(K2(1,:),K2(2,:),)
   
   % to  if I check more iteration to see intersection with unstable of
   % fixed point
%   return
 
d=norm(K1(:,1)-K2(:,1));
i=1; %ith position for unstable
j=1; %jth position for stable
for m=1:500
    for n=1:500
        d1=norm(K1(:,m)-K2(:,n));
        if d1<d
            d=d1;
            i=m;
            j=n;
        else 
        end
    end
end
d;
i;
j;

P_theta=f1_Wuc(:,i);
% plot(P_theta(1),P_theta(2),'k*')

x1=P_theta;
x2=iterates_S(:,i,2);
Q_sigma=Wsc1(:,j); 
% plot(Q_sigma(1),Q_sigma(2),'k*') 
theta=Thetas1(i);
sigma= Thetas11(j);
P_theta_test=[real(polyval(fliplr(P(1, :)), theta));
                   real(polyval(fliplr(P(2, :)), theta))];
Q_sigma_test=[real(polyval(fliplr(P2(1, :)), 1i*sigma));
                    real(polyval(fliplr(P2(2, :)), 1i*sigma))];           
  
 

   p =  connected_newton(N,P,P2,theta,x1,x2,sigma,alpha,beta,epsi,K);
   
   plot(P_theta_test(1),P_theta_test(2),'g.')
   plot(Q_sigma_test(1),Q_sigma_test(2),'g.')

plot(p(2),p(3),'k*')
plot(p(4),p(5),'k*')
 hold off
               