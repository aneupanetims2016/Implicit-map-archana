function T = implicitHenon_T(y,x, alpha, beta, epsilon)


x1 = x(1);
y1 = x(2);
x2 = y(1);
y2 = y(2);

T = [x2 - (1 - alpha*x1^2 + y1 + epsilon*x2^5);
     y2 - beta*x1 + epsilon*y2^5];
 
end