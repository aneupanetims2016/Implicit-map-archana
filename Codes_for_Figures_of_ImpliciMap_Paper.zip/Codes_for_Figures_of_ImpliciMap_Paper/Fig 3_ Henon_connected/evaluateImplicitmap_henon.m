function fx = evaluateImplicitmap_henon(u0, alpha, beta, eps)

y = for_function(u0,alpha,beta);
[fx, error] = Newton_for_orbit_2(y,u0,alpha,beta,eps);


if error > 10^(-6)
    fx = [-1;1]
end


end



 
% 
% if error <= 10^(-13)
%         fx_new = fx;
%     else
%     
%        numPoints = 500;
%        delta_s = 1/5;
%        epsi = 0;
%        
%        F= [y(1)-(1-alpha*u0(1)^2+u0(2)+epsi*y(1)^5); 
%            y(2)-beta*u0(1)+epsi*y(2)^5];
%        DxF= [1-5*epsi*y(1)^4,               0; 
%                            0, 1+5*epsi*y(2)^4];  
%        depsilonF = [-y(1)^5; 
%                      y(2)^5];
%        DF = [DxF, depsilonF];                
%                        
%        [U, S, V] = svd(DF);
%         
%         if V(3,3) >= 0
%             kernelVector = V(:, 3);
%         else
%             kernelVector = -V(:, 3);
%         end
%        
%         solutionVector = [y; 0];
%         newGuess = solutionVector + delta_s*kernelVector;
%        
%         theEpsilons = 0;
%         
%         for k = 1:numPoints
%             
%             solutionVector = newGuess;
%            
%             for m = 1:6
%                 y = solutionVector(1:2);
%                 epsi = solutionVector(3);
%             
%                 F= [y(1)-(1-alpha*u0(1)^2+u0(2)+epsi*y(1)^5); 
%                     y(2)-beta*u0(1)+epsi*y(2)^5];
%                 DxF= [1-5*epsi*y(1)^4,               0; 
%                                     0, 1+5*epsi*y(2)^4];  
%                 depsilonF = [-y(1)^5; 
%                               y(2)^5];
%                 L = [solutionVector' - newGuess']*kernelVector;
%                 G = [F;
%                      L];
%                 thisError = norm(G, inf);
%                  
%                 DG = [DxF, depsilonF;
%                       kernelVector'];
%             
%                 delta_sol = -DG\G;  
%                 solutionVector = solutionVector + delta_sol;
%             
%             end
%             
%              y = solutionVector(1:2);
%              epsi = solutionVector(3);
%             
%              thisError
%              theEpsilons = [theEpsilons; epsi]
%              
%              F= [y(1)-(1-alpha*u0(1)^2+u0(2)+epsi*y(1)^5); 
%                  y(2)-beta*u0(1)+epsi*y(2)^5];
%              DxF= [1-5*epsi*y(1)^4,               0; 
%                                  0, 1+5*epsi*y(2)^4];  
%              depsilonF = [-y(1)^5; 
%                            y(2)^5];
%              DF = [DxF, depsilonF];                
%                      
%              [U, S, V] = svd(DF);
%         
%              if kernelVector'*V(:,3) >= 0
%                 kernelVector = V(:, 3);
%              else
%                 kernelVector = -V(:, 3);
%              end
%    
%              newGuess = solutionVector + delta_s*kernelVector;
%                  
%             
%         end
%       
%         thisError
%          crashNow = crashHere
%     
%     end
% if error < 10^(-12)
%     fx = fx_new;
% else
%    fx = [-1, -1] 
% end
%     
%     
% 
% end



% 
% 
%  numSteps = 100;
%         epsilons = linspace(eps/100, eps, numSteps);
%         fx_old = for_function(u0,alpha,beta);
%     
%         for n = 1:numSteps
%             [fx_new, error] = ...
%                 Newton_for_orbit_2(fx_old,u0,alpha,beta,epsilons(n));
%             fx_old = fx_new;
%             
%         end