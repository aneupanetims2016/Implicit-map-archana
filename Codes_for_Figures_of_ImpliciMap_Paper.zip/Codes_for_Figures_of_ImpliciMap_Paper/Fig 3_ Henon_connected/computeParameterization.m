function P = computeParameterization(...
                 p0, xi, lambda, scale, alpha, beta, epsilon, N)
             
             
a0 = p0(1);
b0 = p0(2);
             
P = zeros(2, N+1);
P(:, 1) = p0;
P(:, 2) = scale*xi;

for n = 2:N
    
   lambda_n = lambda^n; 
    
   a11 = lambda_n + 2*alpha*a0 - 5*epsilon*(a0^4)*lambda_n;
   a12 = -1;
   a21 = -beta;
   a22 = 5*epsilon*(b0^4)*lambda_n + lambda_n;
   
   A = [a11, a12;
        a21, a22]; 
   
   S = [-alpha*conv_2(P(1, :), n) + epsilon*lambda_n*conv5(P(1, :), n);
        -epsilon*lambda_n*conv5(P(2, :), n)];
   
   thisCoeff = A\S;
  
   P(:, n+1) = thisCoeff;
    
end
                    
             