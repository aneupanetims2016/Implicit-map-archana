

clear
format long

a = 1.4;
b = 0.3;
epsi=0;
N = 50;        %Polynomial approximation order
scale = 2;      %scaling/length of the eigenvector



p1 =[-0.299748977995023;
   0.028803872448872;
   0.960129127891787;
  -0.008992469335735];
p = Imp_per2Newton(p1, a, b,epsi);

p0 = p(1:2);
q0 = p(3:4);

Dfp1 = Imp_henonPer2Diff(p, a, b,epsi);
[R, Sigma] = eigs(Dfp1);
lambda1 = Sigma(1,1);
v_1 = R(:,1);
lambda3=Sigma(3,3);
v_3 = R(:,3);

tic
Df1 = [0,0,2*a*p(3),-1;0,0,-b,0; 2*a*p(1),-1,0,0;-b,0,0,0];
Df2 = [1-5*epsi*p(1)*p(1)*p(1)*p(1),0,0,0;...
    0,1+5*epsi*p(2)*p(2)*p(2)*p(2),0,0;...
    0,0,1-5*epsi*p(3)*p(3)*p(3)*p(3),0;...
    0,0,0,1+5*epsi*p(4)*p(4)*p(4)*p(4)];
P1 = zeros(2,N+1);
Q1 = zeros(2,N+1);
P2 = zeros(2,N+1);
Q2 = zeros(2,N+1);
 
P1(:, 1) = p0;
Q1(:, 1) = q0;
P2(:, 1) = p0;
Q2(:, 1) = q0;
 

S1= scale*v_1;
P1(:, 2)=S1(1:2);
Q1(:, 2)=S1(3:4);

S3= scale*v_3;
P2(:, 2)=S3(1:2);
Q2(:, 2)=S3(3:4);
 
 


[P1,Q1]= cauchy_product(P1,Q1,Df1,Df2,lambda1,a,epsi,N);
[P2,Q2]= cauchy_product(P2,Q2,Df1,Df2,lambda3,a,epsi,N);





 manifoldComputeTime = toc
 
 
tic

 numPoints = 20000;
 Thetas = linspace(-1,1, numPoints);
 
 Wu1 = [real(polyval(fliplr(P1(1, :)), Thetas));
                   real(polyval(fliplr(P1(2, :)), Thetas))];
     
 Wu2 = [real(polyval(fliplr(Q1(1, :)), (-1i)*Thetas));
                   real(polyval(fliplr(Q1(2, :)), (-1i)*Thetas))];
 
Ws1 = [real(polyval(fliplr(P2(1, :)), (-1i)*Thetas));
                   real(polyval(fliplr(P2(2, :)), (-1i)*Thetas))];
Ws2 = [real(polyval(fliplr(Q2(1, :)), Thetas));
                   real(polyval(fliplr(Q2(2, :)), Thetas))];              
               
%%%%%%%%
        
              
figure
hold on
  plot(Wu1(1,:), Wu1(2,:), 'b')
  plot(Wu2(1,:), Wu2(2,:), 'b')
  plot(Ws1(1,:), Ws1(2,:),'r')
  plot(Ws2(1,:),Ws2(2,:),'r')
 
plot(p0(1), p0(2), 'k*')
plot(q0(1), q0(2), 'g*')
txt = {' A Henon map','When epsilon=0'};
text(-.85,1.5,txt)