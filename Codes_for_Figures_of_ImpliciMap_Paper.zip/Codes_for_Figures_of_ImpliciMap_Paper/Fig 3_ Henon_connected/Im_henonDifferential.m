function DFz =Im_henonDifferential(x, a, b, epsi)

% DFz = [2*a*x(1), -1,1-5*epsi*x(3)*x(3)*x(3)*x(3),0; 
%                -b,0, 0,1+5*epsi*x(4)*x(4)*x(4)*x(4);
%                1-5*epsi*x(1)*x(1)*x(1)*x(1),0,2*a*x(3),-1;
%                0,1+5*epsi*x(2)*x(2)*x(2)*x(2),-b,0];
               
DFz=[1-5*epsi*x(1)*x(1)*x(1)*x(1),0,2*a*x(3),-1;
        0,1+5*epsi*x(2)*x(2)*x(2)*x(2),-b,0;
        2*a*x(1), -1,1-5*epsi*x(3)*x(3)*x(3)*x(3),0; 
        -b,0, 0,1+5*epsi*x(4)*x(4)*x(4)*x(4); ];     
