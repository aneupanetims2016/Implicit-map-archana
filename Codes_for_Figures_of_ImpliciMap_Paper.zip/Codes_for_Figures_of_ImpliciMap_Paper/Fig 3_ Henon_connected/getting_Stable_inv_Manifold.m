
%1D manifold for stable

clear
format long

a = 1.4;
b = 0.3;
epsi=0;


N = 50;        %Polynomial approximation order
scale = 10;      %scaling/length of the eigenvector



p1 =[-0.299748977995023;
   0.028803872448872;
   0.960129127891787;
  -0.008992469335735];
p = Imp_per2Newton(p1, a, b,epsi);

p0 = p(1:2);
q0 = p(3:4);

Dfp1 = Imp_henonPer2Diff(p, a, b,epsi);
[R, Sigma] = eigs(Dfp1);
lambda = Sigma(4,4);


tic
Df1 = [0,0,2*a*p(3),-1;0,0,-b,0; 2*a*p(1),-1,0,0;-b,0,0,0];
Df2 = [1-5*epsi*p(1)*p(1)*p(1)*p(1),0,0,0;...
    0,1+5*epsi*p(2)*p(2)*p(2)*p(2),0,0;...
    0,0,1-5*epsi*p(3)*p(3)*p(3)*p(3),0;...
    0,0,0,1+5*epsi*p(4)*p(4)*p(4)*p(4)];
P = zeros(2,N+1);
Q = zeros(2,N+1);
P(:, 1) = p0;
Q(:, 1) = q0;

S= scale*R(:,4);
P(:, 2)=S(1:2);
Q(:, 2)=S(3:4);


 for n = 2:N
     
%     %Compute the homological matrix:    
     A=Df1+lambda^n*Df2;
%     
%     %Compute the right hand side of the homological equatoin:
     temp_P1 = P(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum3 = a*sum(temp_P1.*temp_P2);     %Cauchy Product    
          
     temp_Q1 = Q(1, 1:n+1);
     temp_Q1(1) = 0;
     temp_Q1(n+1) = 0;
     temp_Q2 = fliplr(temp_Q1);   
     
     sum1 = a*sum(temp_Q1.*temp_Q2);    %Cauchy Product
     
     
     
     sum2 = epsi*conv5(P(1, 1:n+1), n)*lambda^n;  %a^5
     

     sum4 = epsi*conv5(P(2, 1:n+1), n)*lambda^n;   %b^5
     
     

     sum5 = epsi*conv5(Q(1, 1:n+1), n)*lambda^n;  %c^5
     

     sum6 = epsi*conv5(Q(2, 1:n+1), n)*lambda^n;  %d^5
     
     
     sum7= -sum1+sum2;
     sum8= -sum4;
     sum9= -sum3+sum5;
     sum10= -sum6;
     
       
%     %Solve the homological equation:
    % thisCoef =  A\[sum1; 0; sum3; 0];
     
     thisCoef=A\[sum7;sum8;sum9;sum10];
    
%     %Assigna the Taylor coefficients:
     P(:, n+1) = thisCoef(1:2);
     Q(:, n+1) = thisCoef(3:4);
 end


 manifoldComputeTime = toc
 
 
tic
% 
 coefAxis = linspace(0, N, N+1);
 theNorms_u1 = zeros(1, N+1);
  for n = 0:N
      theNorms_u1(n+1) = norm(abs(P(:, n+1)), inf);
  end
%  
%  
 theNorms_u2 = zeros(1, N+1);
  for n = 0:N
      theNorms_u2(n+1) = norm(abs(Q(:, n+1)), inf);
  end
 figure 
  hold on
  plot(coefAxis, log(theNorms_u1)/log(10), 'b'); 
  plot(coefAxis, log(theNorms_u2)/log(10), 'm');
  
  
 numPoints = 20000
 Thetas = linspace(-0.3,0.3, numPoints);
 
 Wu1 = [real(polyval(fliplr(P(1, :)), (1i)*Thetas));
                   real(polyval(fliplr(P(2, :)), (1i)*Thetas))];
     
 Wu2 = [real(polyval(fliplr(Q(1, :)), Thetas));
                   real(polyval(fliplr(Q(2, :)), Thetas))]; 


        
              
figure
hold on
plot(Wu1(1,:), Wu1(2,:), 'r.')
plot(Wu2(1,:), Wu2(2,:), 'r.')
plot(p0(1), p0(2), 'k*')
plot(q0(1), q0(2), 'k*')
 txt = {'Stable Manifold','\epsilon=0','scale=10','N=50th power'};
 text(-0.5,3,txt)