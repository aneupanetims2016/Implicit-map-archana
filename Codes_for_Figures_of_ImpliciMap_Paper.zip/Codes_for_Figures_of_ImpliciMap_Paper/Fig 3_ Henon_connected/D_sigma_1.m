function D_sigma_test = D_sigma_1(P,N,sigma)
P1 = P(:,2:end);

for k=1:N
    P1(:,k)= 1i*k*P1(:,k);
end   
 D_sigma_test = [real(polyval(fliplr(P1(1, :)), 1i*sigma));
                    real(polyval(fliplr(P1(2, :)), 1i*sigma))];