% Connected orbit from periodic point to fixed point for Figure 3
clear
format long

alpha = 1.4;
beta = 0.3;
epsi=0.04;
N = 60;        %Polynomial approximation order
scale = 0.5;  %  
              %epsi = 0.001       -- scale_u = 1.2
              %epsi = 0.1         -- scale_u = 

scale_s = 12; %scaling/length of the eigenvector
              %epsi = 0.001        -- scale_s = 12



%%Period points

% p1 = [0; 1; 1;-1];


p1 =[-0.299748977995023;
   0.028803872448872;
   0.960129127891787;
  -0.008992469335735];


p_p = Imp_per2Newton(p1, alpha, beta,epsi)


% This is one Fixed point
p2 = [-3;3];
p_f1 = Newton_for_Henon_fixed_point(p2,alpha,beta,epsi);
%This is another Fixed point
p3=[1;3];
p_f2 = Newton_for_Henon_fixed_point(p3,alpha,beta,epsi);


p_p1 = p_p(1:2);
p_p2 = p_p(3:4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
hold on
plot(p_p1(1), p_p1(2), 'k*')
plot(p_p2(1), p_p2(2), 'b*')
 plot(p_f1(1), p_f1(2), 'r*')
 plot(p_f2(1), p_f2(2), 'm*')
hold off
% return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Working for periodic points%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Dfp1 = Imp_henonPer2Diff(p_p, alpha, beta,epsi);
[R_p, Sigma_p] = eigs(Dfp1);
lambda1 = Sigma_p(1,1);
v_1 = R_p(:,1);
lambda3=Sigma_p(3,3);
v_3 = R_p(:,3);
% return
Df1 = [0,0,2*alpha*p_p(3),-1;0,0,-beta,0; 2*alpha*p_p(1),-1,0,0;-beta,0,0,0];
Df2 = [1-5*epsi*p_p(1)*p_p(1)*p_p(1)*p_p(1),0,0,0;...
    0,1+5*epsi*p_p(2)*p_p(2)*p_p(2)*p_p(2),0,0;...
    0,0,1-5*epsi*p_p(3)*p_p(3)*p_p(3)*p_p(3),0;...
    0,0,0,1+5*epsi*p_p(4)*p_p(4)*p_p(4)*p_p(4)];
P1 = zeros(2,N+1);
Q1 = zeros(2,N+1);
P2 = zeros(2,N+1);
Q2 = zeros(2,N+1);

P1(:, 1) = p_p1;
Q1(:, 1) = p_p2;
P2(:, 1) = p_p1;
Q2(:, 1) = p_p2;

S1= scale*v_1;
P1(:, 2)=S1(1:2);
Q1(:, 2)=S1(3:4);

S3= scale_s*v_3;
P2(:, 2)=S3(1:2);
Q2(:, 2)=S3(3:4);
 
[P1,Q1]= cauchy_product(P1,Q1,Df1,Df2,lambda1,alpha,epsi,N);%unstable
[P2,Q2]= cauchy_product(P2,Q2,Df1,Df2,lambda3,alpha,epsi,N);%stable




 coefAxis = linspace(0, N, N+1);
 figure 
 hold on 
 plot(coefAxis, log(max(abs(P2)))/log(10), 'b')
 plot(coefAxis, log(max(abs(Q2)))/log(10), 'g')
 
 
 
 coefAxis = linspace(0, N, N+1);
 figure 
 hold on 
 plot(coefAxis, log(max(abs(P1)))/log(10), 'b')
 plot(coefAxis, log(max(abs(Q1)))/log(10), 'g')
 

numPoints = 1000;
mu =lambda1^(-1);
radii1= (abs(mu));
NumR=500;
 Thetas = linspace(-1,1, numPoints);
 Thetas11 = linspace(radii1,1,NumR);
 Thetas12 = linspace(-1, -radii1, NumR);
 Wu1 = [real(polyval(fliplr(P1(1, :)), Thetas));
                   real(polyval(fliplr(P1(2, :)), Thetas))];
     
 Wu2 = [real(polyval(fliplr(Q1(1, :)), (-1i)*Thetas));
                   real(polyval(fliplr(Q1(2, :)), (-1i)*Thetas))];
 
Ws1 = [real(polyval(fliplr(P2(1, :)), (1i)*Thetas));
                   real(polyval(fliplr(P2(2, :)), (1i)*Thetas))];
Ws2 = [real(polyval(fliplr(Q2(1, :)), Thetas));
                   real(polyval(fliplr(Q2(2, :)), Thetas))]; 
               
  Wu1c = [real(polyval(fliplr(P1(1, :)), Thetas12));
                   real(polyval(fliplr(P1(2, :)), Thetas12))];               

  Wu2c = [real(polyval(fliplr(Q1(1, :)), (1i)*Thetas12));
                   real(polyval(fliplr(Q1(2, :)), (1i)*Thetas12))];               

 Wu3c = [real(polyval(fliplr(P1(1, :)), Thetas11));
                   real(polyval(fliplr(P1(2, :)), Thetas11))]; 
 Wu4c = [real(polyval(fliplr(Q1(1, :)), (1i)*Thetas11));
                   real(polyval(fliplr(Q1(2, :)), (1i)*Thetas11))];

   S = Wu1c; % to extend the unstable manofold of periodic orbit
   S1= Wu2c; % to extend
   S2= Wu3c;
   S3= Wu4c;
 iteration = 2;
 k=3;
 iterates_S=zeros(2,NumR,k);
 iterates_S1=zeros(2,NumR,iteration);
 iterates_S2=zeros(2,NumR,iteration);
 iterates_S3=zeros(2,NumR,iteration); 
 iterates_S(:,:,1)= S;
 iterates_S1(:,:,1)= S1;
 iterates_S2(:,:,1)=S2;
 iterates_S3(:,:,1)=S3;
 %return
 for j=2:k
    for i=1:NumR
       u0=iterates_S(:,i,j-1); %unstable 
       y1 =for_function(u0,alpha,beta);
       iterates_S(:,i,j)=Newton_for_orbit(y1,u0,alpha,beta,epsi);
    end
 end
for j=2:iteration
    for i=1:NumR
       %u0=iterates_S(:,i,j-1); %unstable 
       v0=iterates_S1(:,i,j-1); 
       w0=iterates_S2(:,i,j-1); %unstable 
       t0=iterates_S3(:,i,j-1); 

%        y1 =for_function(u0,alpha,beta);
       x1 = for_function(v0,alpha,beta);
       y2 =back_function(w0,alpha,beta);
       x2 = back_function(t0,alpha,beta);

       %iterates_S(:,i,j)=Newton_for_orbit(y1,u0,alpha,beta,epsi);
       iterates_S1(:,i,j)=Newton_for_orbit(x1,v0,alpha,beta,epsi);
       iterates_S2(:,i,j)=Newton_back_function(y2,w0,alpha,beta,epsi);
       iterates_S3(:,i,j)=Newton_back_function(x2,t0,alpha,beta,epsi);
    end
end

               
               
 figure
 hold on
  
plot(Ws1(1,:), Ws1(2,:),'r', 'LineWidth', 2)
plot(Ws2(1,:), Ws2(2,:),'r', 'LineWidth', 2)
 
           
plot(Wu1(1,:), Wu1(2,:), 'b', 'LineWidth', 2)
plot(Wu2(1,:), Wu2(2,:), 'b', 'LineWidth', 2)
plot(S(1,:), S(2,:), 'c', 'LineWidth', 2)
plot(S1(1,:), S1(2,:), 'm', 'LineWidth', 2)
plot(S2(1,:), S2(2,:), 'k', 'LineWidth', 2)
plot(S3(1,:), S3(2,:), 'y', 'LineWidth', 2)

  for i=2:iteration
      %plot(iterates_S(1,:,i),iterates_S(2,:,i),'c','LineWidth', 2)
      plot(iterates_S1(1,:,i),iterates_S1(2,:,i),'m','LineWidth', 2)
      plot(iterates_S2(1,:,i),iterates_S2(2,:,i),'k','LineWidth', 2)
      plot(iterates_S3(1,:,i),iterates_S3(2,:,i),'y','LineWidth', 2)
  end
  for i=2:k
      plot(iterates_S(1,:,i),iterates_S(2,:,i),'c','LineWidth', 2)
  end

plot(p_p1(1), p_p1(2), 'k*')
plot(p_p2(1), p_p2(2), 'k*') 
axis([-1.5 1.5 -1.4 1.4])
xlabel('Times')
ylabel('Manifolds')
legend('periodic stable','periodic stable','periodic unstable','periodic unstable','unstable iterated','unstable iterated','unstable iterated','unstable iterated','location','south west') 
title('Chaos of connected orbit') 
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


                      %0.04 -- A ``hole'' in the attractor...
N     = 75;        %Polynomial approximation order
scale_u = 0.6;       %epsi = 0     -- scale_u = 10 
                   %epsi = 0.001  -- scale_u = 1.3
                   %epsi = 0.01   -- scale_u = 1
                   %epsi = 0.031  -- scale_u = 0.85
                   %epsi = 0.4    -- scale_u = 0.6
                   %
scale_s = 15;      %epsi = 0      -- scale_s = 62
                   %epsi = 0.001  -- scale_s = 25
                   %epsi = 0.01   -- scale_s = 22
                   %epsi = 0.031  -- scale_s = 18
                   %epsi = 0.4    -- scale_s = 15




%  x0 = [-3;3];
p3=[1;2];
p_3= Newton_for_Henon_fixed_point(p3,alpha,beta,epsi);

p2 = [-3;3];
p_f1 = Newton_for_Henon_fixed_point(p2,alpha,beta,epsi);


%Fixed Point of Henon Imp
x0 =[1;1];
p0 = Newton_for_Henon_fixed_point(x0,alpha,beta,epsi);

x1 = p0(1)
y1 = p0(2)
test_p01 = x1 - (1 - alpha*x1^2 + y1 + epsi*x1^5) 
test_p02 = y1 - beta*x1 + epsi*y1^5




figure
hold on
plot(p_f1(1),p_f1(2),'r*')
plot(p0(1),p0(2),'k*')
plot(p_3(1),p_3(2),'g*')
hold off
%return
%Eigenvalues and Eigen Vectors
[R,Sigma] = eigs(Diff_for_Eigen(p0, alpha, beta, epsi));


% For manifold nearby fixed point
 
 Lambda = Sigma(1,1);
 Tambda = Sigma(2,2);
 
 
 

% [P,Q]=fixed_cauchy(P,Q,p0,mu,nu,alpha,beta,epsi,N); 

D1T = [1-5*epsi*p0(1)^4,                0;
                      0, 1+5*epsi*p0(2)^4]; 
                  
D2T = [2*alpha*p0(1),   -1;
                 -beta,  0];
                  
DF_test = -inv(D1T)*D2T;
[E_test, Sigma_test] = eigs(DF_test)

errorTest = norm(Diff_for_Eigen(p0, alpha, beta, epsi) - DF_test, inf) 

P = computeParameterization(...
                 p0, E_test(:,1), Sigma_test(1,1), scale_u, alpha, beta, epsi, N);
 

        
 Q = computeParameterization(...
                 p0, E_test(:,2), Sigma_test(2,2), scale_s, alpha, beta, epsi, N);
             
                          
             
             
theta = -abs(Lambda)^(-1);
P_theta = evaluateParm_2(theta, P, N);
P_lambdaTheta = evaluateParm_2(Lambda*theta, P, N);
             
test_1 = norm(implicitHenon_T(P_lambdaTheta, P_theta, alpha, beta, epsi), inf)            


fx = evaluateImplicitmap_henon(P_theta, alpha, beta, epsi);

test_1_impMap = norm(fx - P_lambdaTheta)


theta = 1
Q_theta = evaluateParm_2(theta, Q, N);
Q_tambdaTheta = evaluateParm_2(Tambda*theta, Q, N);
             
test_2 = norm(implicitHenon_T(Q_tambdaTheta, Q_theta, alpha, beta, epsi), inf)            


     
             
             
%error = norm(P - P_test, inf)            
         


 coefAxis = linspace(0, N, N+1);
 figure 
 hold on 
 plot(coefAxis, log(max(abs(P)))/log(10))
 
 figure 
 hold on 
 plot(coefAxis, log(max(abs(Q)))/log(10))
 
 
 
numPoints = 20000;
NumR =500;

Thetas = linspace(-1,1, numPoints);

 
%  Wu = [real(polyval(fliplr(P_test(1, :)), Thetas));
%         real(polyval(fliplr(P_test(2, :)), Thetas))];
%                 
   
% 
 Wu = [real(polyval(fliplr(P(1, :)), Thetas));
        real(polyval(fliplr(P(2, :)), Thetas))];
%                  
%    
   
Ws = [real(polyval(fliplr(Q(1, :)), Thetas));
       real(polyval(fliplr(Q(2, :)), Thetas))];
  
   
% Wuc =  [real(polyval(fliplr(P(1, :)), Thetas1));
%                    real(polyval(fliplr(P(2, :)), Thetas1))];              
% Wsc = [real(polyval(fliplr(Q(1, :)), Thetas1));
%                    real(polyval(fliplr(Q(2, :)), Thetas1))];                 
               


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

figure
hold on
  plot(Wu(1,:), Wu(2,:), 'b','LineWidth',2)
  plot(Ws(1,:), Ws(2,:), 'r','LineWidth',2) 
  plot(p0(1),p0(2),'k*')
 


figure
hold on
  plot(Wu(1,:), Wu(2,:), 'b','LineWidth',2)
  plot(Ws(1,:), Ws(2,:), 'r','LineWidth',2) 
  plot(p0(1),p0(2),'k*')
  axis([-5 5 -5 5])
 
 
  
  
  
  
  
  
%================== LAST BLOCK ============================================


                      %0.04 -- A ``hole'' in the attractor...
N     = 75;        %Polynomial approximation order
scale_u = 0.15;       %epsi = 0     -- scale_u = 10 
                   %epsi = 0.001  -- scale_u = 1.3
                   %epsi = 0.01   -- scale_u = 1
                   %epsi = 0.031  -- scale_u = 0.85
                   %epsi = 0.4    -- scale_u = 0.6
                   %
scale_s = 25;      %epsi = 0      -- scale_s = 62
                   %epsi = 0.001  -- scale_s = 25
                   %epsi = 0.01   -- scale_s = 22
                   %epsi = 0.031  -- scale_s = 18
                   %epsi = 0.4    -- scale_s = 15




%  x0 = [-3;3];
p3=[1;2];
p_3= Newton_for_Henon_fixed_point(p3,alpha,beta,epsi);

p2 = [-3;3];
p0= Newton_for_Henon_fixed_point(p2,alpha,beta,epsi);

test = norm(p0-evaluateImplicitmap_henon(p0, alpha, beta, epsi))

x1 = p0(1)
y1 = p0(2)
test_p01 = x1 - (1 - alpha*x1^2 + y1 + epsi*x1^5) 
test_p02 = y1 - beta*x1 + epsi*y1^5




figure
hold on
plot(p_f1(1),p_f1(2),'r*')
plot(p0(1),p0(2),'k*')
plot(p_3(1),p_3(2),'g*')
hold off
%return
%Eigenvalues and Eigen Vectors
[R,Sigma] = eigs(Diff_for_Eigen(p0, alpha, beta, epsi));


% For manofold nearby fixed point
 
 Lambda = Sigma(1,1);
 Tambda = Sigma(2,2);
 

% [P,Q]=fixed_cauchy(P,Q,p0,mu,nu,alpha,beta,epsi,N); 

D1T = [1-5*epsi*p0(1)^4,                0;
                      0, 1+5*epsi*p0(2)^4]; 
                  
D2T = [2*alpha*p0(1),   -1;
                 -beta,  0];
                  
DF_test = -inv(D1T)*D2T;
[E_test, Sigma_test] = eigs(DF_test)

errorTest = norm(Diff_for_Eigen(p0, alpha, beta, epsi) - DF_test, inf) 

P = computeParameterization(...
                 p0, E_test(:,1), Sigma_test(1,1), scale_u, alpha, beta, epsi, N)
 

        
 Q = computeParameterization(...
                 p0, E_test(:,2), Sigma_test(2,2), scale_s, alpha, beta, epsi, N)
             
                          
             
             
theta = -abs(Lambda)^(-1);
P_theta = evaluateParm_2(theta, P, N);
P_lambdaTheta = evaluateParm_2(Lambda*theta, P, N);
             
test_1 = norm(implicitHenon_T(P_lambdaTheta, P_theta, alpha, beta, epsi), inf)            


fx = evaluateImplicitmap_henon(P_theta, alpha, beta, epsi);

test_1_impMap = norm(fx - P_lambdaTheta)


theta = 1
Q_theta = evaluateParm_2(theta, Q, N);
Q_tambdaTheta = evaluateParm_2(Tambda*theta, Q, N);
             
test_2 = norm(implicitHenon_T(Q_tambdaTheta, Q_theta, alpha, beta, epsi), inf)            
   
             
             
%error = norm(P - P_test, inf)            
         


 coefAxis = linspace(0, N, N+1);
 figure 
 hold on 
 plot(coefAxis, log(max(abs(P)))/log(10))
 
 figure 
 hold on 
 plot(coefAxis, log(max(abs(Q)))/log(10))
 
 
 
numPoints = 20000;
NumR =500;

Thetas = linspace(-1,1, numPoints);

 
%  Wu = [real(polyval(fliplr(P_test(1, :)), Thetas));
%         real(polyval(fliplr(P_test(2, :)), Thetas))];
%                 
   
% 
 Wu_p = [real(polyval(fliplr(P(1, :)), Thetas));
        real(polyval(fliplr(P(2, :)), Thetas))];
%                  
%    
   
Ws_p = [real(polyval(fliplr(Q(1, :)), Thetas));
       real(polyval(fliplr(Q(2, :)), Thetas))];
  
   
  
figure
hold on

 plot(Ws1(1,:), Ws1(2,:),'r', 'LineWidth', 2)
plot(Ws2(1,:), Ws2(2,:),'r', 'LineWidth', 2)
           
 plot(Wu1(1,:), Wu1(2,:), 'b', 'LineWidth', 2)
plot(Wu2(1,:), Wu2(2,:), 'b', 'LineWidth', 2)
 
           

  plot(Ws(1,:), Ws(2,:), 'c','LineWidth',5) 
  plot(Wu(1,:), Wu(2,:), 'g','LineWidth',5)
  
  
  plot(Ws_p(1,:), Ws_p(2,:), 'c','LineWidth',5) 
  plot(Wu_p(1,:), Wu_p(2,:), 'g','LineWidth',5)
  for i=2:iteration
     plot(iterates_S(1,:,i),iterates_S(2,:,i),'b','LineWidth', 2)
     
  end
  plot(p_p1(1), p_p1(2), 'k*')
  plot(p_p2(1), p_p2(2), 'k*') 
  plot(p0(1),p0(2),'m*')
  plot(p_3(1),p_3(2),'m*')
  axis([-2 2 -6 6])  
  
  xlabel('Times')
  ylabel('Manifolds')
  %legend('periodic stable','periodic stable','periodic unstable','periodic unstable',...
   %  'fixed point stable','fixed point unstable','fixed point stable','fixed point unstable','connected','location','southwest'  )
  title('Connected orbit from periodic point manifolds to fixed point manifolds')


figure
 hold on
  
P1 = plot(Ws1(1,:), Ws1(2,:),'r', 'LineWidth', 2)
plot(Ws2(1,:), Ws2(2,:),'r', 'LineWidth', 2)
 
           
P2 = plot(Wu1(1,:), Wu1(2,:), 'b', 'LineWidth', 2)
plot(Wu2(1,:), Wu2(2,:), 'b', 'LineWidth', 2)

P3 = plot(Ws(1,:), Ws(2,:), 'c','LineWidth',5) 
P4 = plot(Wu(1,:), Wu(2,:), 'g','LineWidth',5)
  
  
plot(Ws_p(1,:), Ws_p(2,:), 'c','LineWidth',5) 
plot(Wu_p(1,:), Wu_p(2,:), 'g','LineWidth',5)

P5 = plot(S(1,:), S(2,:), 'MarkerFaceColor','[0.4940 0.1840 0.5560]', 'LineWidth', 2)
P6 = plot(S1(1,:), S1(2,:), 'm', 'LineWidth', 2)
P7 = plot(S2(1,:), S2(2,:), 'k', 'LineWidth', 2)
P8 = plot(S3(1,:), S3(2,:), 'y', 'LineWidth', 2)

  for i=2:iteration
      %plot(iterates_S(1,:,i),iterates_S(2,:,i),'c','LineWidth', 2)
      plot(iterates_S1(1,:,i),iterates_S1(2,:,i),'m','LineWidth', 2)
      plot(iterates_S2(1,:,i),iterates_S2(2,:,i),'k','LineWidth', 2)
      plot(iterates_S3(1,:,i),iterates_S3(2,:,i),'y','LineWidth', 2)
  end
  for i=2:k
      plot(iterates_S(1,:,i),iterates_S(2,:,i),'MarkerFaceColor','[0.4940 0.1840 0.5560]','LineWidth', 2)
  end

 P9=plot(p_p1(1), p_p1(2), 'k*')
  plot(p_p2(1), p_p2(2), 'k*') 
P10=  plot(p0(1),p0(2),'m*')
  plot(p_3(1),p_3(2),'m*')
axis([-2 2 -1.4 1.4])
% %xlabel('Times')
% %ylabel('Manifolds')
% lgd =legend([P1,P2,P3,P4,P5,P6,P7,P8,P9,P10],{'periodic stable','periodic unstable',...
%         'fixed point stable', 'fixed point unstable','unstable iterated',...
%         'unstable iterated','unstable iterated','unstable iterated',...
%         'periodic point','fixed point'},'location','south west') 
% lgd.FontSize = 7;
% title('Chaos of connected orbits') 
 return











