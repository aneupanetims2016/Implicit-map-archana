function Px = evaluateParm(theta, P, N)

Px = [0;
      0];
  
for n = 0:N
  Px = Px + P(:, n+1)*theta^n;  
end