function P = evaluatePoly2D_complexCase(s,t,l1,l2, PMN, M, N)

P = [0;0;0];

for n = 0:N
    for m = 0:n
        n1 = n-m;
        n2 = m;
        thisCoef = ...
            [PMN(n1+1, n2+1,1); PMN(n1+1, n2+1,2); PMN(n1+1, n2+1,3)];
        P = P + thisCoef*(l1*(s + 1i*t))^(n1)*(l2*(s - 1i*t))^(n2);
    end
end


%for m = 0:N
%    for n = 0:N
%        P = P + PMN(m+1, n+1,:)*(s + i*t)^m*(s - i*t)^n;
%    end
%end


end