
%2D 4_periodic  points Manifold 

clear all
format long
a=0.5;
b=-0.5;
c=1;
tau=1.333333333;
rho=0.344444444;
N=5;
M=4;

%       epsi=0;
        epsi=0.001;

 alpha=1;
 beta=1;
 gamma=1;
 

x0=[-0.62;
  -0.55;
  -0.71;
  -0.77;
  -0.62;
  -0.55;
  -0.71;
  -0.77;
  -0.62;
  -0.55;
  -0.71;
  -0.77;];


 
 
 scale=0.5;
%4 periodic points are
p= Nperiod4_newton(M,x0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
[R,Sigma]=eig(Derivative_for_eigen(M,p,tau,a,b,c,epsi,alpha,beta,gamma));
 lambda1 = Sigma(1,1);
lambda2 = Sigma(2,2);
abs(lambda1) %unstable eigen values
S1=scale*R(:, 1);
S2=scale*R(:, 2);
P=cell(M,1);
u=cos(pi/M)+1i*sin(pi/M);
for k1=1:M
    
    P{k1}=zeros(N,N,3);
       
end
for k1=1:M
     
 P{k1}(1, 1,:) = p(3*k1-2:3*k1);
 P{k1}(2, 1,:) = S1(3*k1-2:3*k1);
 P{k1}(1, 2,:) = S2(3*k1-2:3*k1);
 
end

s=zeros(3*M,1);
sum=zeros(M,4);

[DT1,DT2]=Per_deriv_2D(M,p,tau,a,b,c,epsi,alpha,beta,gamma);
    for n1 = 2:N-1
    n1;
    for n=0:n1
        m=n1-n;
        
        B=ones(m+1,n+1);
        B(1,1)=0;
        B(m+1,n+1)=0;
        L=(lambda1)^m*(lambda2)^n;
        %for homological equation
        DT= DT1+L*DT2;
      for r=1:M
        sum(r,:)=0;
      for k1 = 0:m
      for k2= 0:n
     sum(r,1) = sum(r,1) + ...
              B(k1+1,k2+1)*(a*P{r}(k1+1,k2+1, 1)*P{r}(m-k1+1,n-k2+1, 1)+...
              b*P{r}(k1+1,k2+1,1)*P{r}(m-k1+1,n-k2+1,2)+...
              c*P{r}(k1+1,k2+1,2)*P{r}(m-k1+1,n-k2+1,2)); 
       for j1=0:k1
       for j2=0:k2
       for t1=0:j1
       for t2=0:j2
       for q1=0:t1 
       for q2=0:t2
      sum(r,2)= sum(r,2)+ B(k1+1,k2+1)*(epsi*alpha*P{r}(q1+1,q2+1,2)*P{r}(t1-q1+1,t2-q2+1,2)*...
               P{r}(j1-t1+1,j2-t2+1,2)*P{r}(k1-j1+1,k2-t2+1,2)*P{r}(m-k1+1,n-k2+1,2));
      sum(r,3)= sum(r,3)+ B(k1+1,k2+1)*(epsi*beta*P{r}(q1+1,q2+1,3)*P{r}(t1-q1+1,t2-q2+1,3)*...
               P{r}(j1-t1+1,j2-t2+1,3)*P{r}(k1-j1+1,k2-t2+1,3)*P{r}(m-k1+1,n-k2+1,3));
      sum(r,4)= sum(r,4)+ B(k1+1,k2+1)*(epsi*gamma*P{r}(q1+1,q2+1,3)*P{r}(t1-q1+1,t2-q2+1,3)*...
               P{r}(j1-t1+1,j2-t2+1,3)*P{r}(k1-j1+1,k2-t2+1,3)*P{r}(m-k1+1,n-k2+1,3));   
          
         
         
       end
       end    
       end
       end    
       end
       end   
      
     
         
      end
      end
      end
    
       s(1:3,1)=[sum(M,1)-(sum(1,2)+sum(1,3))*L;-1*sum(1,3)*L;0] ;
       for j=1:M-1
        
     s(3*j+1:3*j+3,1)=[sum(j,1)-(sum(j,2)+sum(j,3))*L;-1*sum(j,3)*L;0] ; 
    end
     thisCoef =linsolve(DT,s);
     for l=1:M
     % Coefficients are
    P{l}(m+1,n+1,:) = thisCoef(3*l-2:3*l);
    
     end
    end
    end
    
    numRadii = 20;
numThetas = 100;
radii = linspace(0,0.4, numRadii);
Thetas = linspace(0, 2*pi, numThetas);

W=cell(M,1);
thisPoint=zeros(3,M);

for j=1:M
    
  thisPoint(:,j)=[0;0;0];
  W{l} = zeros(numRadii*numThetas, 3);
  
end

index = 1;

for j = 1:numRadii
    
    for k=1:numThetas
        
    s = radii(j)*cos(Thetas(k));
    t = radii(j)*sin(Thetas(k));
    for k=1:M
    
    thisPoint(:,k) = evaluatePoly2D_complexCase(s,t, P{k}, M, N-1);
    W{k}(index, :) = real(thisPoint(:,k));
       
    end
    
    index = index + 1;
    
    
    end

end




figure
hold on

for j=1:M
plot3(real(W{j}(:, 1)), real(W{j}(:, 2)), real(W{j}(:, 3)))

plot3(p(3*j-2), p(3*j-1),p(3*j), 'k*')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%for stable%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

y0 = [-0.656895102009547;
      -0.782254899860955;
      -0.682087827451866];


  u1=y0;
      
            
 u2= Newton2_back_orbit(back_function(u1,rho,tau,a,b,c),u1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 u3= Newton2_back_orbit(back_function(u2,rho,tau,a,b,c),u2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 u4=Newton2_back_orbit(back_function(u3,rho,tau,a,b,c),u3,rho,tau,a,b,c,epsi,alpha,beta,gamma);

 p1=[u1;u2;u3;u4];
 p2= Nperiod4_newton(M,p1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 
 [R1,Sigma1]=eig(Derivative_for_eigen(M,p2,tau,a,b,c,epsi,alpha,beta,gamma));
 Lambda1 = Sigma1(2,2);
Lambda2 = Sigma1(3,3);
abs(Lambda1) % for stable manoifold


z1=scale*R1(:, 2);
z2=scale*R1(:, 3);
P1=cell(M,1);
u=cos(pi/M)+1i*sin(pi/M);
for k1=1:M
    
    P1{k1}=zeros(N,N,3);
       
end
for k1=1:M
     
 P1{k1}(1, 1,:) = p2(3*k1-2:3*k1);
 P1{k1}(2, 1,:) = z1(3*k1-2:3*k1);
 P1{k1}(1, 2,:) = z2(3*k1-2:3*k1);
 
end

s1=zeros(3*M,1);
sum1=zeros(M,4);

[DT11,DT22]=Per_deriv_2D(M,p2,tau,a,b,c,epsi,alpha,beta,gamma);
    for n1 = 2:N-1
    n1;
    for n=0:n1
        m=n1-n;
        
        B=ones(m+1,n+1);
        B(1,1)=0;
        B(m+1,n+1)=0;
        L1=(Lambda1)^m*(Lambda2)^n;
        DT3= DT11+L1*DT22;
      for r=1:M
        sum1(r,:)=0;
      for k1 = 0:m
      for k2= 0:n
     sum1(r,1) = sum1(r,1) + ...
              B(k1+1,k2+1)*(a*P1{r}(k1+1,k2+1, 1)*P1{r}(m-k1+1,n-k2+1, 1)+...
              b*P1{r}(k1+1,k2+1,1)*P1{r}(m-k1+1,n-k2+1,2)+...
              c*P1{r}(k1+1,k2+1,2)*P1{r}(m-k1+1,n-k2+1,2)); 
       for j1=0:k1
       for j2=0:k2
       for t1=0:j1
       for t2=0:j2
       for q1=0:t1 
       for q2=0:t2
      sum1(r,2)= sum1(r,2)+ B(k1+1,k2+1)*(epsi*alpha*P1{r}(q1+1,q2+1,2)*P1{r}(t1-q1+1,t2-q2+1,2)*...
               P1{r}(j1-t1+1,j2-t2+1,2)*P1{r}(k1-j1+1,k2-t2+1,2)*P1{r}(m-k1+1,n-k2+1,2));
      sum1(r,3)= sum1(r,3)+ B(k1+1,k2+1)*(epsi*beta*P1{r}(q1+1,q2+1,3)*P1{r}(t1-q1+1,t2-q2+1,3)*...
               P1{r}(j1-t1+1,j2-t2+1,3)*P1{r}(k1-j1+1,k2-t2+1,3)*P1{r}(m-k1+1,n-k2+1,3));
      sum1(r,4)= sum1(r,4)+ B(k1+1,k2+1)*(epsi*gamma*P1{r}(q1+1,q2+1,3)*P1{r}(t1-q1+1,t2-q2+1,3)*...
               P1{r}(j1-t1+1,j2-t2+1,3)*P1{r}(k1-j1+1,k2-t2+1,3)*P1{r}(m-k1+1,n-k2+1,3));   
          
         
         
       end
       end    
       end
       end    
       end
       end   
      
     
         
      end
      end
      end
    
       s1(1:3,1)=[sum1(M,1)-(sum1(1,2)+sum1(1,3))*L1;-1*sum1(1,3)*L1;0] ;
      for j=1:M-1
        
     s1(3*j+1:3*j+3,1)=[sum1(j,1)-(sum1(j,2)+sum1(j,3))*L1;-1*sum1(j,3)*L1;0] ; 
       end
     thisCoef1 =linsolve(DT3,s1);
     for l=1:M
    P1{l}(m+1,n+1,:) = thisCoef1(3*l-2:3*l);
    
      end
    end
    end
    
    numRadii = 20;
numThetas = 100;
radii = linspace(0,0.4, numRadii);
Thetas = linspace(0, 2*pi, numThetas);

W1=cell(M,1);
thisPoint1=zeros(3,M);

for j=1:M
    
  thisPoint1(:,j)=[0;0;0];
  W1{l} = zeros(numRadii*numThetas, 3);
  
end

index = 1;

for j = 1:numRadii
    
    for k=1:numThetas
        
    s = radii(j)*cos(Thetas(k));
    t = radii(j)*sin(Thetas(k));
    for l=1:M
    
    thisPoint1(:,l) = evaluatePoly2D_complexCase(s,t, P1{l}, M, N-1);
    W1{l}(index, :) = real(thisPoint1(:,l));
       
    end
    
    index = index + 1;
    
    
    end

end




figure
hold on


for j=1:M
plot3(real(W{j}(:, 1)), real(W{j}(:, 2)), real(W{j}(:, 3)))

plot3(p(3*j-2), p(3*j-1),p(3*j), 'k*')
end

for j=1:M
plot3(real(W1{j}(:, 1)), real(W1{j}(:, 2)), real(W1{j}(:, 3)))

plot3(p2(3*j-2), p2(3*j-1),p2(3*j), 'k*')
end
    
    

