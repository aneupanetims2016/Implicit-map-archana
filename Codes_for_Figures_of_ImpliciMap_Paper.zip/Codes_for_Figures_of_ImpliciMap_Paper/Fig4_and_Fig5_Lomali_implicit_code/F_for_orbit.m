function F = F_for_orbit(x,u0,rho,tau,a,b,c,epsi,alpha,beta,gamma)
F=[x(1)-rho-tau*u0(1)-u0(3)-a*u0(1).^2-b*u0(1)*u0(2)-c*u0(2).^2+epsi*alpha*x(2).^5+...
    epsi*beta*x(3).^5;x(2)-u0(1)+epsi*gamma*x(3).^5;x(3)-u0(2);];
end

