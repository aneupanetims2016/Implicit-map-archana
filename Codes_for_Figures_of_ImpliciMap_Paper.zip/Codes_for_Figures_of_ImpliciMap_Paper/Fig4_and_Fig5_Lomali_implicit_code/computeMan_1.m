function SM_1=computeMan_1(Q,D1_T_1,D2_T_1,K_1,K_2,N,a,b,c,epsi,alpha,beta,gamma)

coeffDecay=zeros(1,N+1);
coeffDecay(1)=norm(Q(:,1),inf);
coeffDecay(2)=max([norm(reshape(Q(1,2,:),[3,1]),inf),...
                   norm(reshape(Q(2,1,:),[3,1]),inf)]);
 for order = 2:N
 
 order;
 theseAbs = [];
 
 for vader = 0:order
     n1=order-vader;
     n2=vader;
     K=(K_1.^n1*K_2.^n2); 
     A=D1_T_1 +K*D2_T_1;
     sum1=0;
     sum2=0;
     sum3=0;
     sum4=0;
     sum5=0;
     for k1= 0:n1
     for k2= 0:n2
         
     sum1 = sum1+ Q(n1-k1+1, n2-k2+1,1)*Q(k1+1,k2+1,1);
     sum2=  sum2+ Q(n1-k1+1,n2-k2+1,1)*Q(k1+1,k2+1,2);
     sum3=  sum3+Q(n1-k1+1, n2-k2+1,2)*Q(k1+1,k2+1,2);
     for j1=0:k1
     for j2=0:k2
     for t1=0:j1
     for t2=0:j2
     for q1=0:t1 
     for q2=0:t2
     sum4= sum4+Q(n1-k1+1,n2-k2+1,2)*Q(k1-j1+1,k2-j2+1,2)*Q(j1-t1+1,j2-t2+1,2)*Q(t1-q1+1,t2-q2+1,2)*Q(q1+1,q2+1,2);
     sum5= sum5+Q(n1-k1+1,n2-k2+1,3)*Q(k1-j1+1,k2-j2+1,3)*Q(j1-t1+1,j2-t2+1,3)*Q(t1-q1+1,t2-q2+1,3)*Q(q1+1,q2+1,3);
     end
     end    
     end
     end    
     end
     end     
     
     end
     end
     sum1=sum1-2*Q(n1+1,n2+1,1)*Q(1,1,1);
     sum2=sum2-Q(n1+1,n2+1,1)*Q(1,1,2)-Q(1,1,1)*Q(n1+1,n2+1,2);
     sum3=sum3-2*Q(n1+1,n2+1,2)*Q(1,1,2);
     sum4=(sum4-5*Q(n1+1,n2+1,2)*Q(1,1,2).^4)*K;
     sum5=(sum5-5*Q(n1+1,n2+1,3)*Q(1,1,3).^4)*K;
     
     sum7=a*sum1+b*sum2+c*sum3-epsi*alpha*sum4-epsi*beta*sum5;
     sum8=-epsi*gamma*sum5;
     sum9=0;
     
     Rmn= [sum7;sum8;sum9;];
     Q(n1+1,n2+1,:)= linsolve(A,Rmn);
     
     theseAbs = [theseAbs,...
     norm(reshape(Q(n1+1, n2+1,:),[3,1]),inf)];
     end
     coeffDecay(order+1) = max(theseAbs);
     end
  SM_1 = Q;
  
         
  figure
  hold on
  plot(0:N, log(coeffDecay)/log(10))
     
     
     
     
     
     
     
     
                  
