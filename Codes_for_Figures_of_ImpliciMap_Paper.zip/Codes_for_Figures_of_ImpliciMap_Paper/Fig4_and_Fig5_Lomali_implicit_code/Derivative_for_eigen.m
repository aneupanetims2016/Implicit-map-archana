function Df = Derivative_for_eigen(M,x,tau,a,b,c,epsi,alpha,beta,gamma)
A=zeros(3*M,3*M);
A(1:3, 3*M-2:3*M)=Diff_F(x(3*M-2:3*M),x(1:3),tau,a,b,c,epsi,alpha,beta,gamma);

for j=0:M-2
    A(3*j+4:3*j+6, 3*j+1:3*j+3)=Diff_F(x(3*j+1:3*j+3),x(3*j+4:3*j+6),tau,a,b,c,epsi,alpha,beta,gamma);    
end
Df=A;
