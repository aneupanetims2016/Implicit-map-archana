function varargout = MTPwrite_pointCloud(fid, dataCloud, rad, color)

%===============================================================
%
%This function writes an (N X 3)-matlab matrix to a PovRay file.  
%The matrix will be interprited as a list of row-vectors, and 
%each row-vector will be rendered as a PovRay sphere.
%
%Color:  The color Vectors are RGB in povray.  Then
%         Red = <1, 0, 0>
%        Blue = <0, 0, 1>
%and so on.
%
%===============================================================

fprintf(fid, '%s\n', '#declare RAD =',  num2str(rad), ';');


  numPoints = size(dataCloud, 1);

  
  fprintf(fid, '%s\n', 'union {');
  for n = 1:numPoints
 		outstr = [ '    sphere{ <', num2str(dataCloud(n,1)), ',', num2str(dataCloud(n,2)), ',', ...
                     num2str(dataCloud(n,3)), '> ' 'RAD' '}' ];
 		fprintf(fid, '%s \n', outstr);
 		if mod(n,1000) == 0; disp([num2str(n) '	'	outstr]), end
  end
  
  outstr = ['pigment { color rgb <', num2str(color(1)),  ',', num2str(color(2)), ',', num2str(color(3)), '> }'];
  fprintf(fid, '%s \n', outstr); 
  fprintf(fid, '%s\n', 'finish { phong 0.8 }'); 
  fprintf(fid, '%s\n', '}');
  fprintf(fid, '%s\n', '    ');
  fprintf(fid, '%s\n', '    ');

varargout(1,1) = {1};

return