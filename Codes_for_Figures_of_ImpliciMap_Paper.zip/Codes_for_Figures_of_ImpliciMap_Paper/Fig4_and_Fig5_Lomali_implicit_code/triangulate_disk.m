
function [TRI, D_domain, W_TRI] = triangulate_disk(...
    D, A, B, C, N);



%Pov Ray Graphics:======================================================== 
  


%==========================================================================
%Produce the local stable parameter set, and their images.
%==========================================================================
 

D = unique(D, 'rows');

%==========================================================================
%Triangulate the parameter domain:
%==========================================================================

x = D(:,1);
y = D(:,2);

triCheck_in = 1;
TRI = delaunay(x, y);
triCheck_out = 1;
figure
hold on
triplot(TRI, D(:,1),  D(:,2), 'red');


%==========================================================================
%Compute the phase space triangulation of the local manifold,
%in PovRay ready format.
%==========================================================================


tempSizeVect = size(TRI);
sizeTri = tempSizeVect(1,1);
vertices = zeros(sizeTri, 9);

for (k = 1:sizeTri)
  k;
  sizeTri;
  
  x1 = x(TRI(k, 1)); 
  y1 = y(TRI(k, 1));
  
  x2 = x(TRI(k, 2)); 
  y2 = y(TRI(k, 2));
  
  x3 = x(TRI(k, 3)); 
  y3 = y(TRI(k, 3));
  
  p1 = evaluate_complexCase(x1, y1, A, B, C, N)';
  p2 = evaluate_complexCase(x2, y2, A, B, C, N)';
  p3 = evaluate_complexCase(x3, y3, A, B, C, N)';
  
  vertices(k, 1:3) = p1; 
  vertices(k, 4:6) = p2;
  vertices(k, 7:9) = p3;

end

W_TRI = vertices;
D_domain = D;

%varargout(1,1)={TRI};
%varargout(2,1)={W_triang};