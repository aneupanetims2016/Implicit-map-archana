function Domain=makeDomain(R, num_angle_divisions, num_radial_divisions)

m = num_radial_divisions;
n = num_angle_divisions;

r_step = R/m;
theta_step = 2*pi/n;

pointNum = 1;

for i = 1:m
   this_r = i*r_step;
    for j = 1:n
       thisRay = [cos((j-1)*theta_step), sin((j-1)*theta_step)]; 
       D(pointNum, :) = this_r*thisRay;
       pointNum = pointNum+1;
   end    
end    


Domain = D;
