function T_1 = partial_diff_1(x,tau,a,b,c)
T_1=[-tau-2*a*x(1)-b*x(2),-b*x(1)-2*c*x(2),-1;-1,0,0;0,-1,0;];
end

