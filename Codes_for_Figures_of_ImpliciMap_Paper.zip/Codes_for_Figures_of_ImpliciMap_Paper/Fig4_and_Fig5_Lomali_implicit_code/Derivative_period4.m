function DT = Derivative_period4(M,x,tau,a,b,c,epsi,alpha,beta,gamma)
A=zeros(3*M,3*M);
A(3*M-2:3*M,1:3)=partial_diff_2(x(1:3),epsi,alpha,beta,gamma);
for j=0:M-1
A(3*j+1:3*j+3,3*j+1:3*j+3)=partial_diff_1(x(3*j+1:3*j+3),tau,a,b,c);

end
for j=0:M-2
    A(3*j+1:3*j+3,3*j+4:3*j+6)= partial_diff_2(x(3*j+4:3*j+6),epsi,alpha,beta,gamma);
    
end
DT=A;