function varargout = MTPwrite_surfTriangulation(fid, vertices, color, trans_factor)

%===============================================================
%
%This function writes an (N X 9)-matlab matrix into a PovRay 
%file for rendering.  A row of the matrix is interpreted as
%a triangle in R^3, with every row representing a triangle, and
%every three columns representing a triangle vertex.
%
%Color:  The color Vectors are RGB in povray.  Then
%         Red = <1, 0, 0>
%        Blue = <0, 0, 1>
%and so on.
%
%trans_factor: The degree to which the surface transmits light
%              or `transparency'.
%
%===============================================================



tempSizeVect = size(vertices)
sizeTri = tempSizeVect(1,1)

fprintf(fid, '%s\n', '    ');   
 fprintf(fid, '%s\n', 'union {');
 for n = 1:sizeTri
 		outstr = [ '  triangle { <', num2str(vertices(n,1)), ',', num2str(vertices(n,2)), ',', num2str(vertices(n,3)), '>, ', ...
                                '<', num2str(vertices(n,4)), ',', num2str(vertices(n,5)), ',', num2str(vertices(n,6)), '>, ' , ...
                                '<', num2str(vertices(n,7)), ',', num2str(vertices(n,8)), ',', num2str(vertices(n,9)), '> ', ...
                                '}' ];
  		fprintf(fid, '%s \n', outstr);
  		if mod(n,1000) == 0; disp([num2str(n) ' triangles ']), end
 end
 
  outstr = ['pigment { color rgb <', num2str(color(1)),  ',', num2str(color(2)), ',', num2str(color(3)), '> ', ...
            'transmit ', num2str(trans_factor), '}'];

  fprintf(fid, '%s \n', outstr); 
  fprintf(fid, '%s\n', 'finish { ');
  fprintf(fid, '%s\n', 'reflection 0.1'); 
  fprintf(fid, '%s\n', 'refraction 0.7'); 
  fprintf(fid, '%s\n', 'phong 1.0'); 
  fprintf(fid, '%s\n', '}'); 
  fprintf(fid, '%s\n', '}');

varargout(1,1) = {1};

return
