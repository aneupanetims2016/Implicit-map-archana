function F= Lomali_fixedp(x,rho,tau,a,b,c,epsi,alpha,beta,gamma)

F=[x(1)-rho-tau*x(1)-x(3)-a*x(1)*x(1)-b*x(1)*x(2)-c*x(2)*x(2)+epsi*alpha*x(2).^5+epsi*beta*x(3).^5;...
    x(2)-x(1)+epsi*gamma*x(3).^5;x(3)-x(2);];

end

