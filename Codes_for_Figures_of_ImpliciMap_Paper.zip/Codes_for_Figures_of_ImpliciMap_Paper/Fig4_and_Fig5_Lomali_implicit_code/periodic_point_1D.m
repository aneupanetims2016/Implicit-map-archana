
%1D 4_periodic Manifold

clear all
format long
a=0.5;
b=-0.5;
c=1;
tau=1.333333333;
rho=0.344444444;
N=20;
M=4;

%       epsi=0;
        epsi=0.001;

 alpha=1;
 beta=1;
 gamma=1;
 

 
x0=[-0.62;
  -0.55;
  -0.71;
  -0.77;
  -0.62;
  -0.55;
  -0.71;
  -0.77;
  -0.62;
  -0.55;
  -0.71;
  -0.77;];


 
 
 scale=0.5;
%for 4 periodic points the newton function is
p0= Nperiod4_newton(M,x0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
% to get eigenvalues
[V,Sigma]=eig(Derivative_for_eigen(M,p0,tau,a,b,c,epsi,alpha,beta,gamma));
 s=V(:,1) %eigen vector
 L=Sigma(1,1) %eigen values
 norm=abs(L) %unstable/stable depends on norm
 
 P=zeros(3*N,M);

 u=cos(pi/M)+1i*sin(pi/M);
for j=1:M
     
 P(1:3, j) = p0(3*j-2:3*j);
 P(4:6, j) =scale* s(3*j-2:3*j);
 
 
end

s=zeros(3*M,1);

sum=zeros(M,4);
%this derivative is for homological equation
[A,B]=Per_deriv(M,P,tau,a,b,c,epsi,alpha,beta,gamma);


for n=2:N
    
    for j=1:M
        sum(j,:)=0;
        
   end 
    
    DT= A+L.^n*B;
    
    
    for j=1:M  
    for k = 2:n
       
        
           sum(j,1) = sum(j,1)+a*P(3*k-2,j)*P(3*(n-k+2)-2,j)+b*P(3*k-2,j)*P(3*(n-k+2)-1,j)+c*P(3*k-1,j)*P(3*(n-k+2)-1,j);
           
                 
     for t=2:k 
     for s=2:t 
     for z=2:s    
           sum(j,2)=sum(j,2)+epsi*alpha* P(3*z-1,j)*P(3*(s-z+2)-1,j)*P(3*(t-s+2)-1,j)*P(3*(k-t+2)-1,j)*P(3*(n-k+2)-1,j);
           sum(j,3)=sum(j,3)+epsi*beta*P(3*z,j)*P(3*(s-z+2),j)*P(3*(t-s+2),j)*P(3*(k-t+2),j)*P(3*(n-k+2),j);     
           sum(j,4)=sum(j,4)+epsi*gamma*P(3*z,j)*P(3*(s-z+2),j)*P(3*(t-s+2),j)*P(3*(k-t+2),j)*P(3*(n-k+2),j);  
           
     end      
           
           
     end      
     end     
     end     
     end
     
  
  
     s(1:3,1)=[sum(M,1)-(sum(1,2)+sum(1,3))*L.^n;-1*sum(1,3)*L.^n;0;] ;
     
    
    for j=1:M-1
        
     s(3*j+1:3*j+3,1)=[sum(j,1)-(sum(j,2)+sum(j,3))*L.^n;-1*sum(j,3)*L.^n;0;] ; 
     
    end
thisCoef =linsolve(DT,s);


for j=1:M
     P(3*n+1:3*n+3, j) = thisCoef(3*j-2:3*j);
    
end

end
% pn coefficients are
P;

numPoints = 100;
Thetas = linspace(-1,1, numPoints);
Wu = zeros(numPoints, 3, M);


for k = 1:numPoints
    thisTheta = Thetas(k);
    
        
    for j=1:M 
        
        thisPoint = zeros(3,1);
        %power series
        for m = 0:N             
        thisPoint = thisPoint + P(3*m+1:3*m+3, j)*((u^j)*thisTheta).^m;
        
        end
        
        Wu(k, :, j) = thisPoint;
       
        
    end
    
        
end


figure
hold on
%stable/unstable invariant manifold for periodic points.
for j=1:M
plot3(real(Wu(:, 1, j)), real(Wu(:,2, j)), real(Wu(:,3,j)),'b.')


plot3(p0(3*j-2), p0(3*j-1),p0(3*j), 'k*')
end





      