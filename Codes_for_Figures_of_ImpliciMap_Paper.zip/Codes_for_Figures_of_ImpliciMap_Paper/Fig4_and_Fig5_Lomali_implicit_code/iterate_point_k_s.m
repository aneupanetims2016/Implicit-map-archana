function iterates_S_final= iterate_point_k_s(p,rho,tau,a,b,c,epsi,alpha,beta,gamma)
u0=p;
% x=back_function(u0,rho,tau,a,b,c);
x=for_function(u0,rho,tau,a,b,c);
iterate_p=Newton_for_orbit(x,u0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
%   end
iterates_S_final=iterate_p;

% function p = iterate_point_k_s(p0, n, tau, ...
%                            alpha, beta, delta, ... 
%                            gamma, zeta, epsilon)
% tspan = linspace(0, -n*tau, 3);
% IC = p0;
% 
% options=odeset('RelTol',1e-13,'AbsTol',1e-13);
%     [t, orbit] = ode45('aizawaField', tspan, ...
%                            IC, options, flag, ...
%                            alpha, beta, delta, ...
%                            gamma, zeta, epsilon);
%                                              
% p = orbit(end, :);    
