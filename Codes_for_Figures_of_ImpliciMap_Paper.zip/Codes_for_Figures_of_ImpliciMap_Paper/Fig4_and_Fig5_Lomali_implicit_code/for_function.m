function f = for_function(u0,rho,tau,a,b,c)
f=[rho+u0(3)+tau*u0(1)+a*u0(1).^2+b*u0(1)*u0(2)-c*u0(2).^2;u0(1);u0(2);];
end

