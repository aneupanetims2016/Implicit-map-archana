function u = Newton2_back_orbit(x0,w0,rho,tau,a,b,c,epsi,alpha,beta,gamma)
x=x0;
for i=1:4
F= F2_for_orbit(x,w0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
DF= partial_diff_1(x,tau,a,b,c);
h=(-1)*linsolve(DF,F);
x=x+h;    
end
u=x;
F2_for_orbit(u,w0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
