function T_2 = partial_diff_2(x,epsi,alpha,beta,gamma)
T_2=[1,5*epsi*alpha*x(2).^4,5*epsi*beta*x(3).^4;0,1,5*epsi*gamma*x(3).^4;0,0,1];
end

