function f = back_function(u0,rho,tau,a,b,c)
f=[u0(2);u0(3);-rho-tau*u0(2)-a*u0(2).^2-b*u0(2)*u0(3)-c*u0(3).^2+u0(1);];
end

