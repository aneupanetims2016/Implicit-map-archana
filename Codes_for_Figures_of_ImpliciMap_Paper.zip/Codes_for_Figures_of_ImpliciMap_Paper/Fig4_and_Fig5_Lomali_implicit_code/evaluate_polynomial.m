function Ws = evaluate_polynomial(P,N,numR,numTheta,the_theta,the_rs)
pointNum=1;
for m = 1:numR
    m;
    numR;
for n =1:numTheta
        this_r=the_rs(m);
       
        
        this_theta=the_theta(n);
        sigma1= this_r*cos(this_theta);
        sigma2= this_r*sin(this_theta);        
        
        
thisPoint=[0;0;0;];
  for order = 0:N
            for vader=0:order
                m1 = order-vader;
                m2 = vader;
                thisPoint = thisPoint+...
                    reshape (P(m1+1,m2+1,:),[3,1])*...
                    ((sigma1+1i*sigma2)^m1)*((sigma1-1i*sigma2)^m2);
            end
  end
        W(:, pointNum) = real(thisPoint);
        
        pointNum = pointNum +1;
        
end
end
Ws=W;