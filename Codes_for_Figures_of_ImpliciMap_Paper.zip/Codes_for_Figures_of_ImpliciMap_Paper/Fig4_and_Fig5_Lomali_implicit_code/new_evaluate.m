function W = new_evaluate(Q,Thetas)
W= [real(polyval(fliplr(Q(1, :)),Thetas));...
         real(polyval(fliplr(Q(2, :)), Thetas));real(polyval(fliplr(Q(3, :)), Thetas));];
end

