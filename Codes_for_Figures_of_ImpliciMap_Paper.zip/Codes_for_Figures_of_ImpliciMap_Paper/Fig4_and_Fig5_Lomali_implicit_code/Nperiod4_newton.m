function p = Nperiod4_newton(M,x0,rho,tau,a,b,c,epsi,alpha,beta,gamma)
x=x0;

for i=1:20

  F=Period4_function(M,x,rho,tau,a,b,c,epsi,alpha,beta,gamma);
  DF=Derivative_period4(M,x,tau,a,b,c,epsi,alpha,beta,gamma);
  
  h=linsolve(-1*DF,F);
  x=x+h;

end

p=x;
Period4_function(M,p,rho,tau,a,b,c,epsi,alpha,beta,gamma);