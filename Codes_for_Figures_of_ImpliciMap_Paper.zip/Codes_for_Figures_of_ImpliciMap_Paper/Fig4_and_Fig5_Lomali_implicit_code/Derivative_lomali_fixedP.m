function DF = Derivative_lomali_fixedP(x,tau,a,b,c,epsi,alpha,beta,gamma)
DF = [1-tau-2*a*x(1)-b*x(2), -b*x(1)-2*c*x(2)+5*epsi*alpha*x(2).^4,-1+5*epsi*beta*x(3).^4;...
   -1,1,5*epsi*gamma*x(3).^4;0,-1,1;] ;

end

