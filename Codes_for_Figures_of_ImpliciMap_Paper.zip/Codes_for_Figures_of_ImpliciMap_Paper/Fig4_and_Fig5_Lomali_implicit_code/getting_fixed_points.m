
%1D Manifold for Lomali Map of fixed points
clear all
format long
a=0.5;
b=-0.5;
c=1;
tau=1.333333333;
rho=0.344444444;
N=20;

%       epsi=0;
       epsi=0.001;

 alpha=.09;
 beta=1.86;
 gamma=.0019;
 
 x0_1=[1;1;1;];
 x0_2=[-1.5;-1;-1;];
 
 scale=0.5;

p0= Lomali_NewF_P(x0_1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
% p0= Lomali_NewF_P(x0_2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 
  
 [R,Sigma]=eig(diff_fixedP(p0,tau,a,b,c,epsi,alpha,beta,gamma));
 P=zeros(3,N+1);
  
 Lambda=Sigma(1,1) %unstable
 P(:,1)=p0;
 P(:,2)=scale*R(:,1)
%  Lambda=Sigma(1,1);
%  P(:,1)=p0(:,2);
%  P(:,2)=scale*R(:,1);
  
  tic
  
 for n = 2:N
      
      %Compute the homological matrix:    
    A =partial_diff_1(p0,tau,a,b,c)+Lambda.^n*partial_diff_2(p0,epsi,alpha,beta,gamma);
    
% %     %Compute the right hand side of the homological equatoin:
      temp_P1 = P(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum1 = a*sum(temp_P1.*temp_P2);     %Cauchy Product    
           
      temp_P2 = P(2, 1:n+1);
      temp_P2(1) = 0;
      temp_P2(n+1) = 0;
      temp_P21 = fliplr(temp_P2);   
     
     sum3 = c*sum(temp_P2.*temp_P21);    %Cauchy Product
      
      sum2 = b*sum(temp_P1.*temp_P21);
      

        sum4=epsi*alpha*conv5(P(2, 1:n+1),n)*Lambda.^n; 

      

        sum5=epsi*beta*conv5(P(3,1:n+1),n)*Lambda.^n;
      
      
      sum6= sum1+sum2+sum3-sum4-sum5;
      sum7= (-1)*epsi*gamma*conv5(P(3,1:n+1),n)*Lambda.^n;
      
     S=[sum6;sum7;0];  
%      
      thisCoef= linsolve(A,S);
     
% %     %Assigna the Taylor coefficients:
     P(:, n+1) = thisCoef;
     
     
%      
%      
  end
 
  P;
  
  manifoldComputeTime = toc
  
%  
%  
   coefAxis = linspace(0, N, N+1);
   theNorms_u1 = zeros(1, N+1);
    for n = 0:N
        theNorms_u1(n+1) = norm(abs(P(:, n+1)), inf);
   end
%  
%  
    figure 
     hold on
     plot(coefAxis, log(theNorms_u1)/log(10), 'b'); 
% %   
%    
   numPoints = 20000;
   Thetas = linspace(-1,1, numPoints);
   Thetas1=linspace(-1,-2,numPoints);
   Thetas2=linspace(1,2,numPoints);
%   
  Wu1= new_evaluate(P,Thetas);
  Wu12=new_evaluate(P,Thetas1);
  Wu13=new_evaluate(P,Thetas2);
  
     
     
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
 t0= Lomali_NewF_P(x0_2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 
  
 [K,sigma]=eig(diff_fixedP(t0,tau,a,b,c,epsi,alpha,beta,gamma));
 Q=zeros(3,N+1); 
 
 lambda=sigma(3,3); %stable
 Q(:,1)=t0;
 Q(:,2)=scale*K(:,3);
  
  tic
  
 for n = 2:N
      
      %Compute the homological matrix:    
    B =partial_diff_1(t0,tau,a,b,c)+lambda.^n*partial_diff_2(t0,epsi,alpha,beta,gamma);
    
% %     %Compute the right hand side of the homological equatoin:
      temp_P1 = Q(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum1 = a*sum(temp_P1.*temp_P2);     %Cauchy Product    
           
      temp_P2 = Q(2, 1:n+1);
      temp_P2(1) = 0;
      temp_P2(n+1) = 0;
      temp_P21 = fliplr(temp_P2);   
     
     sum3 = c*sum(temp_P2.*temp_P21);    %Cauchy Product
      
      sum2 = b*sum(temp_P1.*temp_P21);
      
%       temp_P3=temp_P2.*temp_P21;
%       temp_P3(1)=0;
%       temp_P3(n+1)=0;
%       temp_P4=fliplr(temp_P3);
%       temp_P5= temp_P3.*temp_P4;
%       temp_P5(1)=0;
%       temp_P5(n+1)=0;
      sum4=epsi*alpha*conv5(Q(2, 1:n+1),n)*lambda.^n;
      
%       temp_P7=Q(3,1:n+1);
%       temp_P7(1)=0;
%       temp_P7(n+1)=0;
%       temp_P8=fliplr(temp_P7);
%       temp_P9= temp_P7.*temp_P8;
%       temp_P9(1)=0;
%       temp_P9(n+1)=0;
%       temp_P10=fliplr(temp_P9);
%       temp_P11= temp_P9.*temp_P10;
%       temp_P11(1)=0;
%       temp_P11(n+1)=0;
    %  sum5=epsi*beta*sum(temp_P11.*temp_P7)*lambda.^n;
      sum5= epsi*beta*conv5(Q(3,1:n+1),n)*lambda.^n;
      sum6= sum1+sum2+sum3-sum4-sum5;
      sum7= (-1)*epsi*gamma*conv5(Q(3,1:n+1),n)*lambda.^n;
      
     T=[sum6;sum7;0];  
%      
      thisCoef1= linsolve(B,T);
     
% %     %Assigna the Taylor coefficients:
     Q(:, n+1) = thisCoef1;
%      
%      
  end
%  return
  Q;
  manifoldComputeTime = toc
  
%  
%  
   coefAxis = linspace(0, N, N+1);
   theNorms_u1 = zeros(1, N+1);
    for n = 0:N
        theNorms_u1(n+1) = norm(abs(Q(:, n+1)), inf);
   end
%  
%  
    figure 
     hold on
     plot(coefAxis, log(theNorms_u1)/log(10), 'b'); 
% %   
%    
   numPoints = 20000;
   Thetas = linspace(-1,1, numPoints);
   
   
%   
  Mu1= new_evaluate(Q,Thetas);
  Mu12=new_evaluate(Q,Thetas2);
  Mu13=new_evaluate(Q,Thetas1);
     K=6;
     u=zeros(3,K);
    u0= Mu1(:,1);
    u(:,1)=u0;
    w=zeros(3,K);
    w0= Wu1(:,1);
    w(:,1)=w0;
    
    for k=1:K        
        x0=for_function(u(:,k),rho,tau,a,b,c);
        y0=back_function(w(:,k),rho,tau,a,b,c); 
        u(:,k+1)= Newton_for_orbit(x0,u(:,k),rho,tau,a,b,c,epsi,alpha,beta,gamma);
        w(:,k+1)= Newton2_back_orbit(y0,w(:,k),rho,tau,a,b,c,epsi,alpha,beta,gamma);            
        
    end
    
    orbit=u;
    orbit_1=w;
   
   
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
  figure
  hold on
   plot3(Wu1(1,:),Wu1(2,:),Wu1(3,:), 'r.') %unstable
   plot3(Mu1(1,:),Mu1(2,:),Mu1(3,:),'b.')%stable
   plot3(u(1,:),u(2,:),u(3,:),'k*')
   plot3(w(1,:),w(2,:),w(3,:),'m*')
   plot3(t0(1),t0(2),t0(3),  'g*')
  plot3(p0(1),p0(2),p0(3),  'k*')
 plot3(Wu12(1,:),Wu12(2,:),Wu12(3,:), 'k.')
plot3(Wu13(1,:),Wu13(2,:),Wu13(3,:), 'g.')
 plot3(Mu12(1,:),Mu12(2,:),Mu12(3,:), 'k.')
plot3(Mu13(1,:),Mu13(2,:),Mu13(3,:), 'b.')
  
  