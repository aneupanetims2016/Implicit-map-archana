function df = diff_fixedP(x,tau,a,b,c,epsi,alpha,beta,gamma)
df=(-1)*linsolve(partial_diff_2(x,epsi,alpha,beta,gamma),partial_diff_1(x,tau,a,b,c));
end

