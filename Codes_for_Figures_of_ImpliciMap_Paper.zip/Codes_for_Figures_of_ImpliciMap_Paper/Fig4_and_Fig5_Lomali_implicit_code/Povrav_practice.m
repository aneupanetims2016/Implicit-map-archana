
%2D Manifold for Lomali Map of fixed points
clear all
format long
a=0.5;
b=-0.5;
c=1;
tau=1.333333333;
rho=0.344444444;
N=20;

%        epsi=0;
        epsi=0.01;

 alpha=1;
 beta=1;
 gamma=1;
 
 x0_1=[1;1;1;];
%   x0_2=[-1.5;-1;-1;];
  x0_2=[-1;-1;-1.5];
 
 scale=0.35;
 
%Two fixed points of Implicit Lomali systems
p0= Lomali_NewF_P(x0_1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
p1= Lomali_NewF_P(x0_2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 
 %Eigen values and eigen vector according as fixed points 
 [R,Sigma]=eig(diff_fixedP(p0,tau,a,b,c,epsi,alpha,beta,gamma));
 [T,Uigma]=eig(diff_fixedP(p1,tau,a,b,c,epsi,alpha,beta,gamma));
 
 P=zeros(N+1,N+1,3);
 Q=zeros(N+1,N+1,3);
  
 Lambda_u=Sigma(1,1); 
 x1_u=scale*R(:,1);
 L_1=Sigma(2,2); %stable eigenvalues
 L_2=Sigma(3,3);
 
norm = abs(L_1)
 v_1=scale*R(:,2);
 v_2=scale*R(:,3);
P(1,1,:)=p0;
P(2,1,:)=v_1;
P(1,2,:)=v_2;

Lambda_u_1=Uigma(3,3); 
 K1_s=scale*T(:,3);
 K_1=Uigma(1,1);  %unstable eigenvalues
 K_2=Uigma(2,2);
 norm1 = abs(K_1)
 
 % these are  different radii for extension of manifold
 radii2=min(abs(L_1),abs(L_2));
 radii1=1/max(abs(K_1),abs(K_2));
 radii=min(radii1,radii2);
 
 w_1=scale*T(:,1);
 w_2=scale*T(:,2);
Q(1,1,:)=p1;
Q(2,1,:)=w_1;
Q(1,2,:)=w_2;
% homological equations

D1_T=partial_diff_1(p0,tau,a,b,c);
D2_T=partial_diff_2(p0,epsi,alpha,beta,gamma);

D1_T_1=partial_diff_1(p1,tau,a,b,c);
D2_T_2=partial_diff_2(p1,epsi,alpha,beta,gamma);

% % testing
% p=[0.1;0.1;0.1];
% numR = 1;
% numTheta = 20;
% numPoints = 18;
% %   tic
%  iterates_S=zeros(3,numPoints);
%  iterates_S(:,1)=p;
%   for i=1:numPoints
% u0=iterates_S(:,i);
% x=back_function(u0,rho,tau,a,b,c);
% iterates_S(:,i+1)=Newton2_back_orbit(x,u0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
%   end


% these SM and SM_1 gives coefficients

SM = computeMan_1(P,D1_T,D2_T,L_1,L_2,N,a,b,c,epsi,alpha,beta,gamma);
SM_1=computeMan_1(Q,D1_T_1,D2_T_2,K_1,K_2,N,a,b,c,epsi,alpha,beta,gamma);
SM;
SM_1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%================== Triangulate the Local Manifold ========================

% Au = SM(:, :, 1);
% Bu = SM(:, :, 2);
% Cu = SM(:, :, 3);
% 
% numTheta = 50;
% numRad = 25;
% Du = makeDomain(1, numTheta, numRad);
% Du = unique(Du, 'rows');          
%           
%  figure         
%  plot(Du(:,1), Du(:,2), 'b.')
%  
% x = Du(:,1);
% y = Du(:,2);
% 
% figure
% hold on
% TRI_u = delaunay(x, y);
% triplot(TRI_u, Du(:,1),  Du(:,2), 'blue');
% 
% triNum = 100;
% 
% plot(x(TRI_u(triNum,1)), y(TRI_u(triNum,1)), 'k*');
% plot(x(TRI_u(triNum,2)), y(TRI_u(triNum,2)), 'k*');
% plot(x(TRI_u(triNum,3)), y(TRI_u(triNum,3)), 'k*');
% 
% %================== Storage =========================================
% 
% tempSizeVect = size(TRI_u);
% sizeTri = tempSizeVect(1,1);
% 
% 
% vertices_u = zeros(sizeTri, 9);
% 
% for (k = 1:sizeTri)
%   x1 = x(TRI_u(k, 1)); 
%   y1 = y(TRI_u(k, 1));
%   
%   x2 = x(TRI_u(k, 2)); 
%   y2 = y(TRI_u(k, 2));
%   
%   x3 = x(TRI_u(k, 3)); 
%   y3 = y(TRI_u(k, 3));
%   
%   p1 = evaluate_complexCase(x1, y1, Au, Bu, Cu, N)';
%   p2 = evaluate_complexCase(x2, y2, Au, Bu, Cu, N)';
%   p3 = evaluate_complexCase(x3, y3, Au, Bu, Cu, N)';
%   
%   vertices_u(k, 1:3) = p1; 
%   vertices_u(k, 4:6) = p2;
%   vertices_u(k, 7:9) = p3;
% 
% end    
% 
% 
% figure
% hold on 
% 
% plot3(vertices_u(:,1), vertices_u(:,2), vertices_u(:,3), 'b.');
% plot3(vertices_u(:,4), vertices_u(:,5), vertices_u(:,6), 'b.');
% plot3(vertices_u(:,7), vertices_u(:,8), vertices_u(:,9), 'b.');
% 
% 
%  fid = fopen('Lomelli_stable_local.pov', 'w');
% 
%  
% tempSizeVect = size(vertices_u)
% sizeTri = tempSizeVect(1,1)
% 
% %=========================================================================
% %Write stable Cap Triangulation to File:
% %=========================================================================
%  
% fprintf(fid, '%s\n', '    ');   
%  fprintf(fid, '%s\n', 'union {');
%  for n = 1:sizeTri
%  		outstr = [ '  triangle { <', num2str(vertices_u(n,1)), ',', num2str(vertices_u(n,2)), ',', num2str(vertices_u(n,3)), '>, ', ...
%                                 '<', num2str(vertices_u(n,4)), ',', num2str(vertices_u(n,5)), ',', num2str(vertices_u(n,6)), '>, ' , ...
%                                 '<', num2str(vertices_u(n,7)), ',', num2str(vertices_u(n,8)), ',', num2str(vertices_u(n,9)), '> ', ...
%                                 '}' ];
%   		fprintf(fid, '%s \n', outstr);
%   		if mod(n,1000) == 0; disp([num2str(n) ' stable cap triangles ']), end
%  end
%  
%  
% 
%  fprintf(fid, '%s\n', 'pigment { color rgb <1, 0, 0> }');
%  fprintf(fid, '%s\n', 'finish { phong 0.8 }'); 
%  fprintf(fid, '%s\n', '}');
% 
% 
% return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%=================== Triangulate a fundemental domain

Au = SM_1(:, :, 1);
Bu = SM_1(:, :, 2);
Cu = SM_1(:, :, 3);

numTheta = 50;
numRad = 25;
Du = makeDomain(1, numTheta, numRad);
Du = unique(Du, 'rows');          
          
 figure         
 plot(Du(:,1), Du(:,2), 'b.')
 
xFD = Du(:,1);
yFD = Du(:,2);

figure
hold on
TRI_sFD = delaunay(xFD, yFD);
triplot(TRI_sFD, Du(:,1),  Du(:,2), 'blue');

tempSizeVect = size(TRI_sFD)
sizeTri = tempSizeVect(1,1)

%============================ Build FD ====================================


vertices_uFD = zeros(sizeTri, 9);


for (k = 1:sizeTri)
  x1 = xFD(TRI_sFD(k, 1)); 
  y1 = yFD(TRI_sFD(k, 1));
  
  x2 = xFD(TRI_sFD(k, 2)); 
  y2 = yFD(TRI_sFD(k, 2));
  
  x3 = xFD(TRI_sFD(k, 3)); 
  y3 = yFD(TRI_sFD(k, 3));
  
  p1 = evaluate_complexCase(x1, y1, Au, Bu, Cu, N)';
  p2 = evaluate_complexCase(x2, y2, Au, Bu, Cu, N)';
  p3 = evaluate_complexCase(x3, y3, Au, Bu, Cu, N)';
  
  vertices_uFD(k, 1:3) = p1; 
  vertices_uFD(k, 4:6) = p2;
  vertices_uFD(k, 7:9) = p3;

end    

figure 
hold on
plot3(vertices_uFD(:, 1), vertices_uFD(:, 2), vertices_uFD(:, 3), 'b.')

K=15;

S1=vertices_uFD(1:sizeTri, 1:3)';
S2=vertices_uFD(1:sizeTri, 4:6)';
S3=vertices_uFD(1:sizeTri, 7:9)';

iterates_S1=zeros(3,sizeTri,K);
iterates_S2=zeros(3,sizeTri,K);
iterates_S3=zeros(3,sizeTri,K);

iterates_S1(:,:,1)=S1;
iterates_S2(:,:,1)=S2;
iterates_S3(:,:,1)=S3;

 for j=2:K
    for i=1:sizeTri
        u1=iterates_S1(:,i,j-1);
        u2=iterates_S2(:,i,j-1);
        u3=iterates_S3(:,i,j-1);

        x1=for_function(u1,rho,tau,a,b,c);
        x2=for_function(u2,rho,tau,a,b,c);
        x3=for_function(u3,rho,tau,a,b,c);
       
        iterates_S1(:,i,j)=Newton_for_orbit(x1,u1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
        iterates_S2(:,i,j)=Newton_for_orbit(x2,u2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
        iterates_S3(:,i,j)=Newton_for_orbit(x3,u3,rho,tau,a,b,c,epsi,alpha,beta,gamma);
     end
 end
 
 figure
 hold on
 for i=2:K
     plot3(iterates_S1(1,:,i),iterates_S1(2,:,i),iterates_S1(3,:,i),'b.')
 end

 figure
 hold on
 for i=2:K
     plot3(iterates_S2(1,:,i),iterates_S2(2,:,i),iterates_S2(3,:,i),'g.')
 end

 figure
 hold on
 for i=2:K
     plot3(iterates_S3(1,:,i),iterates_S3(2,:,i),iterates_S3(3,:,i),'r.')
 end

return
%Write the global manifold:
Wu_vertices = zeros(K*sizeTri, 9);

for i=1:K
    Wu_vertices((i-1)*sizeTri+1:i*sizeTri,1:3) = iterates_S1(:,:,i)';
    Wu_vertices((i-1)*sizeTri+1:i*sizeTri,4:6) = iterates_S2(:,:,i)';
    Wu_vertices((i-1)*sizeTri+1:i*sizeTri,7:9) = iterates_S3(:,:,i)';
end
    
% figure 
% hold on 
% plot3(Ws_vertices(:, 1), Ws_vertices(:, 2), Ws_vertices(:, 3), 'b.')
% 
% figure 
% hold on 
% plot3(Ws_vertices(:, 4), Ws_vertices(:, 5), Ws_vertices(:, 6), 'g.')
% 
% figure 
% hold on 
% plot3(Ws_vertices(:, 7), Ws_vertices(:, 8), Ws_vertices(:, 9), 'r.')

pointRadius = 0.05
 fid = fopen('Lomelli_unstable_global.pov', 'w');
 fprintf(fid, '%s\n', '#declare RAD =',  num2str(pointRadius), ';');
 
counter = K*sizeTri+1;

 fprintf(fid, '%s\n', 'union {');
 for n = 1:counter-1
 	outstr = [ '  triangle { <', num2str(Wu_vertices(n,1)), ',',...
                                 num2str(Wu_vertices(n,2)), ',', num2str(Wu_vertices(n,3)), '>, ', ...
                            '<', num2str(Wu_vertices(n,4)), ',', ...
                                 num2str(Wu_vertices(n,5)), ',', num2str(Wu_vertices(n,6)), '>, ' , ...
                            '<', num2str(Wu_vertices(n,7)), ',', ...
                                 num2str(Wu_vertices(n,8)), ',', num2str(Wu_vertices(n,9)), '> ', ...
                            '}' ];
 	fprintf(fid, '%s \n', outstr);
 	if mod(n,1000) == 0; disp([num2str(n) ' stable global triangles ']), end
 end
  
 fprintf(fid, '%s\n', 'pigment { color rgb <0, 0, 1> }');
 fprintf(fid, '%s\n', 'finish { phong 0.8 }'); 
 fprintf(fid, '%s\n', '}');
 
 fclose(fid);

 disp('Done.')