function f=evaluate_manifold_on_set(D, N, A, B, C)

tempSize = size(D);
numPoints = tempSize(1);

place = 1;
i = sqrt(-1);
PD = zeros(numPoints, 3);

for n = 1:numPoints
    s = D(n, 1);
    t = D(n, 2);
    PD(n, 1:3) = evaluate_complexCase(s, t, A, B, C, N); 
end

f = PD;