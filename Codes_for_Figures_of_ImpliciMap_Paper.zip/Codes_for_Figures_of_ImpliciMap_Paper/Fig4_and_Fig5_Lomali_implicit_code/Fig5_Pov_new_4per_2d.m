
%2D 4_periodic  points Manifold 

clear all
format long
a=0.5;
b=-0.5;
c=1;
tau=1.333333333;
rho=0.344444444;
N=10;
M=4;

          %epsi=0;
         epsi=0.001;

 alpha=1;
 beta=1;
 gamma=1;
 

x0=[-0.62;
  -0.55;
  -0.71;
  -0.77;
  -0.62;
  -0.55;
  -0.71;
  -0.77;
  -0.62;
  -0.55;
  -0.71;
  -0.77;];


 
 
 scale=0.25;
%4 periodic points are
%%%%%%% for unstable %%%%%%%%%%%%%
p= Nperiod4_newton(M,x0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
[R,Sigma]=eig(Derivative_for_eigen(M,p,tau,a,b,c,epsi,alpha,beta,gamma));
 lambda1 = Sigma(1,1);
lambda2 = Sigma(2,2);
abs(lambda1) %unstable eigen values
S1=scale*R(:, 1);
S2=scale*R(:, 2);
P=cell(M,1);

for k1=1:M
    
    P{k1}=zeros(N,N,3);
       
end
for k1=1:M
     
 P{k1}(1, 1,:) = p(3*k1-2:3*k1);
 P{k1}(2, 1,:) = S1(3*k1-2:3*k1);
 P{k1}(1, 2,:) = S2(3*k1-2:3*k1);
 
end

s=zeros(3*M,1);
sum=zeros(M,4);

[DT1,DT2]=Per_deriv_2D(M,p,tau,a,b,c,epsi,alpha,beta,gamma);
    for n1 = 2:N-1
    n1;
    for n=0:n1
        m=n1-n;
        
        B=ones(m+1,n+1);
        B(1,1)=0;
        B(m+1,n+1)=0;
        L=(lambda1)^m*(lambda2)^n;
        %for homological equation
        DT= DT1+L*DT2;
      for r=1:M
        sum(r,:)=0;
      for k1 = 0:m
      for k2= 0:n
     sum(r,1) = sum(r,1) + ...
              B(k1+1,k2+1)*(a*P{r}(k1+1,k2+1, 1)*P{r}(m-k1+1,n-k2+1, 1)+...
              b*P{r}(k1+1,k2+1,1)*P{r}(m-k1+1,n-k2+1,2)+...
              c*P{r}(k1+1,k2+1,2)*P{r}(m-k1+1,n-k2+1,2)); 
       for j1=0:k1
       for j2=0:k2
       for t1=0:j1
       for t2=0:j2
       for q1=0:t1 
       for q2=0:t2
      sum(r,2)= sum(r,2)+ B(k1+1,k2+1)*(epsi*alpha*P{r}(q1+1,q2+1,2)*P{r}(t1-q1+1,t2-q2+1,2)*...
               P{r}(j1-t1+1,j2-t2+1,2)*P{r}(k1-j1+1,k2-t2+1,2)*P{r}(m-k1+1,n-k2+1,2));
      sum(r,3)= sum(r,3)+ B(k1+1,k2+1)*(epsi*beta*P{r}(q1+1,q2+1,3)*P{r}(t1-q1+1,t2-q2+1,3)*...
               P{r}(j1-t1+1,j2-t2+1,3)*P{r}(k1-j1+1,k2-t2+1,3)*P{r}(m-k1+1,n-k2+1,3));
      sum(r,4)= sum(r,4)+ B(k1+1,k2+1)*(epsi*gamma*P{r}(q1+1,q2+1,3)*P{r}(t1-q1+1,t2-q2+1,3)*...
               P{r}(j1-t1+1,j2-t2+1,3)*P{r}(k1-j1+1,k2-t2+1,3)*P{r}(m-k1+1,n-k2+1,3));   
          
         
         
       end
       end    
       end
       end    
       end
       end   
      
     
         
      end
      end
      end
    
       s(1:3,1)=[sum(M,1)-(sum(1,2)+sum(1,3))*L;-1*sum(1,3)*L;0] ;
    for j=1:M-1
        
     s(3*j+1:3*j+3,1)=[sum(j,1)-(sum(j,2)+sum(j,3))*L;-1*sum(j,3)*L;0] ; 
    end
     thisCoef =linsolve(DT,s);
     for k3=1:M
     % Coefficients are
    P{k3}(m+1,n+1,:) = thisCoef(3*k3-2:3*k3);
    
     end
    end
    end
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%for stable%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
y0 = [-0.656895102009547;
      -0.782254899860955;
      -0.682087827451866];


  u1=y0;
      
            
 u2= Newton2_back_orbit(back_function(u1,rho,tau,a,b,c),u1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 u3= Newton2_back_orbit(back_function(u2,rho,tau,a,b,c),u2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 u4=Newton2_back_orbit(back_function(u3,rho,tau,a,b,c),u3,rho,tau,a,b,c,epsi,alpha,beta,gamma);
%%%Initial assumtion%%%%%%
 p1=[u1;u2;u3;u4];
 p2= Nperiod4_newton(M,p1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 
 [R1,Sigma1]=eig(Derivative_for_eigen(M,p2,tau,a,b,c,epsi,alpha,beta,gamma));
 Lambda1 = Sigma1(2,2);
Lambda2 = Sigma1(3,3);
abs(Lambda1) % for stable manoifold


z1=scale*R1(:, 2);
z2=scale*R1(:, 3);
P1=cell(M,1);
u=cos(pi/M)+1i*sin(pi/M);
for k1=1:M
    
    P1{k1}=zeros(N,N,3);
       
end
for k1=1:M
     
 P1{k1}(1, 1,:) = p2(3*k1-2:3*k1);
 P1{k1}(2, 1,:) = z1(3*k1-2:3*k1);
 P1{k1}(1, 2,:) = z2(3*k1-2:3*k1);
 
end

s1=zeros(3*M,1);
sum1=zeros(M,4);

[DT11,DT22]=Per_deriv_2D(M,p2,tau,a,b,c,epsi,alpha,beta,gamma);
    for n1 = 2:N-1
    n1;
    for n=0:n1
        m=n1-n;
        
        B=ones(m+1,n+1);
        B(1,1)=0;
        B(m+1,n+1)=0;
        L1=(Lambda1)^m*(Lambda2)^n;
        DT3= DT11+L1*DT22;
      for r=1:M
        sum1(r,:)=0;
      for k1 = 0:m
      for k2= 0:n
     sum1(r,1) = sum1(r,1) + ...
              B(k1+1,k2+1)*(a*P1{r}(k1+1,k2+1, 1)*P1{r}(m-k1+1,n-k2+1, 1)+...
              b*P1{r}(k1+1,k2+1,1)*P1{r}(m-k1+1,n-k2+1,2)+...
              c*P1{r}(k1+1,k2+1,2)*P1{r}(m-k1+1,n-k2+1,2)); 
       for j1=0:k1
       for j2=0:k2
       for t1=0:j1
       for t2=0:j2
       for q1=0:t1 
       for q2=0:t2
      sum1(r,2)= sum1(r,2)+ B(k1+1,k2+1)*(epsi*alpha*P1{r}(q1+1,q2+1,2)*P1{r}(t1-q1+1,t2-q2+1,2)*...
               P1{r}(j1-t1+1,j2-t2+1,2)*P1{r}(k1-j1+1,k2-t2+1,2)*P1{r}(m-k1+1,n-k2+1,2));
      sum1(r,3)= sum1(r,3)+ B(k1+1,k2+1)*(epsi*beta*P1{r}(q1+1,q2+1,3)*P1{r}(t1-q1+1,t2-q2+1,3)*...
               P1{r}(j1-t1+1,j2-t2+1,3)*P1{r}(k1-j1+1,k2-t2+1,3)*P1{r}(m-k1+1,n-k2+1,3));
      sum1(r,4)= sum1(r,4)+ B(k1+1,k2+1)*(epsi*gamma*P1{r}(q1+1,q2+1,3)*P1{r}(t1-q1+1,t2-q2+1,3)*...
               P1{r}(j1-t1+1,j2-t2+1,3)*P1{r}(k1-j1+1,k2-t2+1,3)*P1{r}(m-k1+1,n-k2+1,3));   
          
         
         
       end
       end    
       end
       end    
       end
       end   
      
     
         
      end
      end
      end
    
       s1(1:3,1)=[sum1(M,1)-(sum1(1,2)+sum1(1,3))*L1;-1*sum1(1,3)*L1;0] ;
      for j=1:M-1
        
     s1(3*j+1:3*j+3,1)=[sum1(j,1)-(sum1(j,2)+sum1(j,3))*L1;-1*sum1(j,3)*L1;0] ; 
       end
     thisCoef1 =linsolve(DT3,s1);
     for l=1:M
    P1{l}(m+1,n+1,:) = thisCoef1(3*l-2:3*l);
    
      end
    end
    end

    
    
    
  numRad = 25;
numTheta = 100;

Du = makeDomain(1, numTheta, numRad);
Ds = makeDomain(1, numTheta, numRad);




Wu1_loc2D = evaluate_manifold_on_set(...
    Du, N-1, P{1}(:, :, 1), P{1}(:, :, 2), P{1}( :, :, 3));

Wu2_loc2D = evaluate_manifold_on_set(...
    Du, N-1, P{2}(:, :, 1), P{2}(:, :, 2), P{2}( :, :, 3));

Wu3_loc2D = evaluate_manifold_on_set(...
    Du, N-1, P{3}(:, :, 1), P{3}(:, :, 2), P{3}( :, :, 3));

Wu4_loc2D = evaluate_manifold_on_set(...
    Du, N-1, P{4}(:, :, 1), P{4}(:, :, 2), P{4}( :, :, 3));






Ws1_loc2D = evaluate_manifold_on_set(...
    Ds, N-1, P1{1}(:, :, 1), P1{1}(:, :, 2), P1{1}( :, :, 3));

Ws2_loc2D = evaluate_manifold_on_set(...
    Ds, N-1, P1{2}(:, :, 1), P1{2}(:, :, 2), P1{2}( :, :, 3));

Ws3_loc2D = evaluate_manifold_on_set(...
    Ds, N-1, P1{3}(:, :, 1), P1{3}(:, :, 2), P1{3}( :, :, 3));

Ws4_loc2D = evaluate_manifold_on_set(...
    Ds, N-1, P1{4}(:, :, 1), P1{4}(:, :, 2), P1{4}( :, :, 3));


  
 figure
hold on
plot3(Wu1_loc2D(:, 1), Wu1_loc2D(:, 2), Wu1_loc2D(:, 3), 'b.')
plot3(Wu2_loc2D(:, 1), Wu2_loc2D(:, 2), Wu2_loc2D(:, 3), 'g.')
plot3(Wu3_loc2D(:, 1), Wu3_loc2D(:, 2), Wu3_loc2D(:, 3), 'c.')
plot3(Wu4_loc2D(:, 1), Wu4_loc2D(:, 2), Wu4_loc2D(:, 3), 'm.')
   

plot3(Ws1_loc2D(:, 1), Ws1_loc2D(:, 2), Ws1_loc2D(:, 3), 'b.')
plot3(Ws2_loc2D(:, 1), Ws2_loc2D(:, 2), Ws2_loc2D(:, 3), 'g.')
plot3(Ws3_loc2D(:, 1), Ws3_loc2D(:, 2), Ws3_loc2D(:, 3), 'c.')
plot3(Ws4_loc2D(:, 1), Ws4_loc2D(:, 2), Ws4_loc2D(:, 3), 'm.')

%%%%%%%Triangulation %%%%%%%
    
 [Du1_TRI, Du1_domain, Wu1_TRI] = ...
    triangulate_disk(...
    Du, P{1}(:, :, 1), P{1}(:, :, 2), P{1}( :, :, 3), ...
    N-1);





[Du2_TRI, Du2_domain, Wu2_TRI] = ...
    triangulate_disk(...
    Du, P{2}(:, :, 1), P{2}(:, :, 2), P{2}( :, :, 3), ...
    N-1);


[Du3_TRI, Du3_domain, Wu3_TRI] = ...
    triangulate_disk(...
    Du, P{3}(:, :, 1), P{3}(:, :, 2), P{3}( :, :, 3), ...
    N-1);


[Du4_TRI, Du4_domain, Wu4_TRI] = ...
    triangulate_disk(...
    Du, P{4}(:, :, 1), P{4}(:, :, 2), P{4}( :, :, 3), ...
    N-1);




[Ds1_TRI, Ds1_domain, Ws1_TRI] = ...
    triangulate_disk(...
    Ds, P1{1}(:, :, 1), P1{1}(:, :, 2), P1{1}( :, :, 3), ...
    N-1);


[Ds2_TRI, Ds2_domain, Ws2_TRI] = ...
    triangulate_disk(...
    Ds, P1{2}(:, :, 1), P1{2}(:, :, 2), P1{2}( :, :, 3), ...
    N-1);


[Ds3_TRI, Ds3_domain, Ws3_TRI] = ...
    triangulate_disk(...
    Ds, P1{3}(:, :, 1), P1{3}(:, :, 2), P1{3}( :, :, 3), ...
    N-1);


[Ds4_TRI, Ds4_domain, Ws4_TRI] = ...
    triangulate_disk(...
    Ds, P1{4}(:, :, 1), P1{4}(:, :, 2), P1{4}( :, :, 3), ...
    N-1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



   fid = fopen('povPerManifolds_Wu1.pov', 'w');
[retVal] = MTPwrite_surfTriangulation(fid, Wu1_TRI, [0 0 1], 0.0);
fclose(fid); 



fid = fopen('povPerManifolds_Wu2.pov', 'w');
[retVal] = MTPwrite_surfTriangulation(fid, Wu2_TRI, [0 0 1], 0.0);
fclose(fid); 



fid = fopen('povPerManifolds_Wu3.pov', 'w');
[retVal] = MTPwrite_surfTriangulation(fid, Wu3_TRI, [0 0 1], 0.0);
fclose(fid); 



fid = fopen('povPerManifolds_Wu4.pov', 'w');
[retVal] = MTPwrite_surfTriangulation(fid, Wu4_TRI, [0 0 1], 0.0);
fclose(fid); 




fid = fopen('povPerManifolds_Ws1.pov', 'w');
[retVal] = MTPwrite_surfTriangulation(fid, Ws1_TRI, [1 0 0], 0.0);
fclose(fid); 



fid = fopen('povPerManifolds_Ws2.pov', 'w');
[retVal] = MTPwrite_surfTriangulation(fid, Ws2_TRI, [1 0 0], 0.0);
fclose(fid); 


fid = fopen('povPerManifolds_Ws3.pov', 'w');
[retVal] = MTPwrite_surfTriangulation(fid, Ws3_TRI, [1 0 0], 0.0);
fclose(fid); 


fid = fopen('povPerManifolds_Ws4.pov', 'w');
[retVal] = MTPwrite_surfTriangulation(fid, Ws4_TRI, [1 0 0], 0.0);
fclose(fid); 




fid = fopen('povManifolds_per4Point_p1_3.pov', 'w');
[retVal] = MTPwrite_pointCloud(fid, p1(10:12)', 0.025, [0,0,1])
fclose(fid);
% 
% 

    
figure
hold on
plot3(Wu1_TRI(:, 1), Wu1_TRI(:, 2), Wu1_TRI(:, 3), 'b.')
plot3(Wu2_TRI(:, 1), Wu2_TRI(:, 2), Wu2_TRI(:, 3), 'g.')
plot3(Wu3_TRI(:, 1), Wu3_TRI(:, 2), Wu3_TRI(:, 3), 'c.')
plot3(Wu4_TRI(:, 1), Wu4_TRI(:, 2), Wu4_TRI(:, 3), 'm.')    
    
    
plot3(Ws1_TRI(:, 1), Ws1_TRI(:, 2), Ws1_TRI(:, 3), 'b.')
plot3(Ws2_TRI(:, 1), Ws2_TRI(:, 2), Ws2_TRI(:, 3), 'g.')
plot3(Ws3_TRI(:, 1), Ws3_TRI(:, 2), Ws3_TRI(:, 3), 'c.')
plot3(Ws4_TRI(:, 1), Ws4_TRI(:, 2), Ws4_TRI(:, 3), 'm.')   
    
    
    
    
    
    
    
    
    
    
%     numRadii = 20;
% numThetas = 100;
% radii = linspace(0,0.4, numRadii);
% radii1 = linspace(0.1,0.4,numRadii);
% Thetas = linspace(0, 2*pi, numThetas);
% 
% W=cell(M,1);
% W_1=cell(M,1);
% thisPoint=zeros(3,M);
% thisPoint1=zeros(3,M);
% 
% for j=1:M
%     
%   thisPoint(:,j)=[0;0;0];
%   W{j} = zeros(numRadii*numThetas, 3);
%   W_1{j} = zeros(numRadii*numThetas, 3);
%   
% end
% 
% index = 1;
% 
% for j = 1:numRadii
%     
%     for k=1:numThetas
%         
%     s = radii(j)*cos(Thetas(k));
%     t = radii(j)*sin(Thetas(k));
%     
%     s1 = radii1(j)*cos(Thetas(k));
%     t1 = radii1(j)*sin(Thetas(k));
%     for k=1:M
%     
%     thisPoint(:,k) = evaluatePoly2D_complexCase(s,t, P{k}, M, N-1);
%     thisPoint1(:,k) = evaluatePoly2D_complexCase(s1,t1, P{k}, M, N-1);
%     
%     W{k}(index, :) = real(thisPoint(:,k));
%     W_1{k}(index, :) = real(thisPoint1(:,k));
%        
%     end
%     
%     index = index + 1;
%     
%     
%     end
% 
% end
% 
% 
% 
% 
% figure
% hold on
% %%%unstable%%
% for j=1:M
% plot3(real(W{j}(:, 1)), real(W{j}(:, 2)), real(W{j}(:, 3)))
% plot3(real(W_1{j}(:, 1)), real(W_1{j}(:, 2)), real(W_1{j}(:, 3)))
% 
% plot3(p(3*j-2), p(3*j-1),p(3*j), 'k*')
% end
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%for stable%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% y0 = [-0.656895102009547;
%       -0.782254899860955;
%       -0.682087827451866];
% 
% 
%   u1=y0;
%       
%             
%  u2= Newton2_back_orbit(back_function(u1,rho,tau,a,b,c),u1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
%  u3= Newton2_back_orbit(back_function(u2,rho,tau,a,b,c),u2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
%  u4=Newton2_back_orbit(back_function(u3,rho,tau,a,b,c),u3,rho,tau,a,b,c,epsi,alpha,beta,gamma);
% 
%  p1=[u1;u2;u3;u4];
%  p2= Nperiod4_newton(M,p1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
%  
%  [R1,Sigma1]=eig(Derivative_for_eigen(M,p2,tau,a,b,c,epsi,alpha,beta,gamma));
%  Lambda1 = Sigma1(2,2);
% Lambda2 = Sigma1(3,3);
% abs(Lambda1) % for stable manoifold
% 
% 
% z1=scale*R1(:, 2);
% z2=scale*R1(:, 3);
% P1=cell(M,1);
% u=cos(pi/M)+1i*sin(pi/M);
% for k1=1:M
%     
%     P1{k1}=zeros(N,N,3);
%        
% end
% for k1=1:M
%      
%  P1{k1}(1, 1,:) = p2(3*k1-2:3*k1);
%  P1{k1}(2, 1,:) = z1(3*k1-2:3*k1);
%  P1{k1}(1, 2,:) = z2(3*k1-2:3*k1);
%  
% end
% 
% s1=zeros(3*M,1);
% sum1=zeros(M,4);
% 
% [DT11,DT22]=Per_deriv_2D(M,p2,tau,a,b,c,epsi,alpha,beta,gamma);
%     for n1 = 2:N-1
%     n1;
%     for n=0:n1
%         m=n1-n;
%         
%         B=ones(m+1,n+1);
%         B(1,1)=0;
%         B(m+1,n+1)=0;
%         L1=(Lambda1)^m*(Lambda2)^n;
%         DT3= DT11+L1*DT22;
%       for r=1:M
%         sum1(r,:)=0;
%       for k1 = 0:m
%       for k2= 0:n
%      sum1(r,1) = sum1(r,1) + ...
%               B(k1+1,k2+1)*(a*P1{r}(k1+1,k2+1, 1)*P1{r}(m-k1+1,n-k2+1, 1)+...
%               b*P1{r}(k1+1,k2+1,1)*P1{r}(m-k1+1,n-k2+1,2)+...
%               c*P1{r}(k1+1,k2+1,2)*P1{r}(m-k1+1,n-k2+1,2)); 
%        for j1=0:k1
%        for j2=0:k2
%        for t1=0:j1
%        for t2=0:j2
%        for q1=0:t1 
%        for q2=0:t2
%       sum1(r,2)= sum1(r,2)+ B(k1+1,k2+1)*(epsi*alpha*P1{r}(q1+1,q2+1,2)*P1{r}(t1-q1+1,t2-q2+1,2)*...
%                P1{r}(j1-t1+1,j2-t2+1,2)*P1{r}(k1-j1+1,k2-t2+1,2)*P1{r}(m-k1+1,n-k2+1,2));
%       sum1(r,3)= sum1(r,3)+ B(k1+1,k2+1)*(epsi*beta*P1{r}(q1+1,q2+1,3)*P1{r}(t1-q1+1,t2-q2+1,3)*...
%                P1{r}(j1-t1+1,j2-t2+1,3)*P1{r}(k1-j1+1,k2-t2+1,3)*P1{r}(m-k1+1,n-k2+1,3));
%       sum1(r,4)= sum1(r,4)+ B(k1+1,k2+1)*(epsi*gamma*P1{r}(q1+1,q2+1,3)*P1{r}(t1-q1+1,t2-q2+1,3)*...
%                P1{r}(j1-t1+1,j2-t2+1,3)*P1{r}(k1-j1+1,k2-t2+1,3)*P1{r}(m-k1+1,n-k2+1,3));   
%           
%          
%          
%        end
%        end    
%        end
%        end    
%        end
%        end   
%       
%      
%          
%       end
%       end
%       end
%     
%        s1(1:3,1)=[sum1(M,1)-(sum1(1,2)+sum1(1,3))*L1;-1*sum1(1,3)*L1;0] ;
%       for j=1:M-1
%         
%      s1(3*j+1:3*j+3,1)=[sum1(j,1)-(sum1(j,2)+sum1(j,3))*L1;-1*sum1(j,3)*L1;0] ; 
%        end
%      thisCoef1 =linsolve(DT3,s1);
%      for l=1:M
%     P1{l}(m+1,n+1,:) = thisCoef1(3*l-2:3*l);
%     
%       end
%     end
%     end
%     
% %     numRadii = 20;
% % numThetas = 100;
% % radii = linspace(0,0.4, numRadii);
% % Thetas = linspace(0, 2*pi, numThetas);
% 
% W1=cell(M,1);
% W1_2=cell(M,1);
% thisPoint1_2=zeros(3,M);
% thisPoint1_3=zeros(3,M);
% 
% for j=1:M
%     
%   thisPoint1_2(:,j)=[0;0;0];
%   thisPoint1_3(:,j)=[0;0;0];
%   W1{j} = zeros(numRadii*numThetas, 3);
%   W1_2{j} = zeros(numRadii*numThetas, 3);
%   
% end
% 
% index = 1;
% 
% for j = 1:numRadii
%     
%     for k=1:numThetas
%         
%     s = radii(j)*cos(Thetas(k));
%     t = radii(j)*sin(Thetas(k));
%     
%     s1 = radii1(j)*cos(Thetas(k));
%     t1 = radii1(j)*sin(Thetas(k));
%     for l=1:M
%     
%     thisPoint1_2(:,l) = evaluatePoly2D_complexCase(s,t, P1{l}, M, N-1);
%     thisPoint1_3(:,l) = evaluatePoly2D_complexCase(s1,t1, P1{l}, M, N-1);
%     W1{l}(index, :) = real(thisPoint1_2(:,l));
%     W1_2{l}(index, :) = real(thisPoint1_3(:,l));
%        
%        
%     end
%     
%     index = index + 1;
%     
%     
%     end
% 
% end
% K=100;
% S=cell(M,1);
% S1=cell(M,1);
% for i=1:M
% S{i}=W_1{i};%unstable
% S1{i}=W1_2{i};%stable
% end    
% iterates_S=cell(M,1);
% iterates_S1=cell(M,1);
% for i=1:M
% iterates_S{i}=zeros(3,2000,K);
% iterates_S1{i}=zeros(3,2000,K);
% end    
% for k=1:M
%  iterates_S{k}(:,:,1)=S{k}';%unstable
%  iterates_S1{k}(:,:,1)=S1{k}'; %stable  
%    
% 
% for j=2:K
%     for i=1:2000
%         u0{k}=iterates_S1{k}(:,i,j-1);%stable
%         w0{k}=iterates_S{k}(:,i,j-1);%unstable
%         x{k}=back_function(u0{k},rho,tau,a,b,c);
%         y{k}=for_function(w0{k},rho,tau,a,b,c);
% %        
%         iterates_S1{k}(:,i,j)=Newton2_back_orbit(x{k},u0{k},rho,tau,a,b,c,epsi,alpha,beta,gamma);
%         iterates_S{k}(:,i,j)=Newton_for_orbit(y{k},w0{k},rho,tau,a,b,c,epsi,alpha,beta,gamma);
%      end
% end
%  
% end
% figure
% hold on
% 
% 
% for j=1:M
% plot3(real(W{j}(:, 1)), real(W{j}(:, 2)), real(W{j}(:, 3)),'b')
% plot3(real(W_1{j}(:, 1)), real(W_1{j}(:, 2)), real(W_1{j}(:, 3)),'r')
% 
% plot3(p(3*j-2), p(3*j-1),p(3*j), 'k*')
% 
% %stable%%
% 
% plot3(real(W1{j}(:, 1))', real(W1{j}(:, 2))', real(W1{j}(:, 3))')
% plot3(real(W1_2{j}(:, 1))', real(W1_2{j}(:, 2))', real(W1_2{j}(:, 3))')
% 
% plot3(p2(3*j-2), p2(3*j-1),p2(3*j), 'k*')
% 
%     
% 
%  for i=1:K
%      plot3(iterates_S{j}(1,:,i),iterates_S{j}(2,:,i),iterates_S{j}(3,:,i),'b')
%      plot3(iterates_S1{j}(1,:,i),iterates_S1{j}(2,:,i),iterates_S1{j}(3,:,i),'r')
%  end
%  
%      
% end
