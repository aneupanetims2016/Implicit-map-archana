function [A,B] = Per_deriv_2D(M,p,tau,a,b,c,epsi,alpha,beta,gamma)
A=zeros(3*M,3*M);
B=zeros(3*M,3*M);
A(1:3,3*(M-1)+1:3*M)= partial_diff_1(p(10:12),tau,a,b,c);
for k=2:M
 A(3*k-2:3*k,3*(k-2)+1:3*(k-2)+3)= partial_diff_1(p(3*(k-2)+1:3*(k-2)+3),tau,a,b,c);
end
for k=1:M
 B(3*k-2:3*k,3*k-2:3*k)= partial_diff_2(p(3*k-2:3*k),epsi,alpha,beta,gamma);    
end
A;
B;
end

