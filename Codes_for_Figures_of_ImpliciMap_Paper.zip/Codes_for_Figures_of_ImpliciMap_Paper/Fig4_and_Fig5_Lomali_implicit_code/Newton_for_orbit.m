function u = Newton_for_orbit(x0,u0,rho,tau,a,b,c,epsi,alpha,beta,gamma)
x=x0;
for i=1:4
    F= F_for_orbit(x,u0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
    DF= partial_diff_2(x,epsi,alpha,beta,gamma);    
    h=(-1)*linsolve(DF,F);
    x=x+h;
    
end
u=x;
F_for_orbit(u,u0,rho,tau,a,b,c,epsi,alpha,beta,gamma);