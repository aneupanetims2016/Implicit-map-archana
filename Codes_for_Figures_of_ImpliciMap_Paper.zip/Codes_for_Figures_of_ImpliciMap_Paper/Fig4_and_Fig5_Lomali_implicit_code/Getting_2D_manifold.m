
%2D Manifold for Lomali Map of fixed points
clear all
format long
a=0.5;
b=-0.5;
c=1;
tau=1.333333333;
rho=0.344444444;
N=20;

%        epsi=0;
        epsi=0.001;

 alpha=1;
 beta=1;
 gamma=1;
 
 x0_1=[1;1;1;];
%   x0_2=[-1.5;-1;-1;];
  x0_2=[-1;-1;-1.5];
 
 scale=0.35;
 
%Two fixed points of Implicit Lomali systems
p0= Lomali_NewF_P(x0_1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
p1= Lomali_NewF_P(x0_2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 
 %Eigen values and eigen vector according as fixed points 
 [R,Sigma]=eig(diff_fixedP(p0,tau,a,b,c,epsi,alpha,beta,gamma));
 [T,Uigma]=eig(diff_fixedP(p1,tau,a,b,c,epsi,alpha,beta,gamma));
 
 P=zeros(N+1,N+1,3);
 Q=zeros(N+1,N+1,3);
  
 Lambda_u=Sigma(1,1); 
 x1_u=scale*R(:,1);
 L_1=Sigma(2,2); %stable eigenvalues
 L_2=Sigma(3,3);
 
norm= abs(L_1)
 v_1=scale*R(:,2);
 v_2=scale*R(:,3);
P(1,1,:)=p0;
P(2,1,:)=v_1;
P(1,2,:)=v_2;

Lambda_u_1=Uigma(3,3); 
 K1_s=scale*T(:,3);
 K_1=Uigma(1,1);  %unstable eigenvalues
 K_2=Uigma(2,2);
 norm1=abs(K_1)
 
 % these are  different radii for extension of manifold
 radii1=max(abs(L_1),abs(L_2));
 radii2=1/max(abs(K_1),abs(K_2));
 radii=max(radii1,radii2);
 
 w_1=scale*T(:,1);
 w_2=scale*T(:,2);
Q(1,1,:)=p1;
Q(2,1,:)=w_1;
Q(1,2,:)=w_2;
% homological equations

D1_T=partial_diff_1(p0,tau,a,b,c);
D2_T=partial_diff_2(p0,epsi,alpha,beta,gamma);

D1_T_1=partial_diff_1(p1,tau,a,b,c);
D2_T_2=partial_diff_2(p1,epsi,alpha,beta,gamma);

  tic
  
% these SM and SM_1 gives coefficients

SM = computeMan_1(P,D1_T,D2_T,L_1,L_2,N,a,b,c,epsi,alpha,beta,gamma);
SM_1=computeMan_1(Q,D1_T_1,D2_T_2,K_1,K_2,N,a,b,c,epsi,alpha,beta,gamma);
SM;
SM_1;
toc
numR = 100;
numTheta = 50;
% plotting in different radii
the_rs = linspace(0.001,1,numR);
the_rs1 = linspace(radii,1,numR);


the_theta = linspace(0,2*pi,numTheta);

numPoints = numR*numTheta;
Ws_loc   = zeros(3, numPoints);
Ws_loc1 = zeros(3,numPoints);


Ws_loc_1 = zeros(3, numPoints);
Ws_loc_12=zeros(3,numPoints);
pointNum = 1;
pointNum1=1;


pointNum_1= 1;
pointNum_12=1;
for m = 1:numR
    m;
    numR;
    for n =1:numTheta
        this_r=the_rs(m);
        this_r1=the_rs1(m);
        
        
        this_theta=the_theta(n);
        sigma1= this_r*cos(this_theta);
        sigma2= this_r*sin(this_theta);
        sigma11= this_r1*cos(this_theta);
        sigma21= this_r1*sin(this_theta);
        
        
        
        thisPoint=[0;0;0];
        thisPoint1=[0;0;0;];
        
        thisPoint_1=[0;0;0];
        thisPoint_12=[0;0;0;];
        
        
 
        for order = 0:N
            for vader=0:order
                m1 = order-vader;
                m2 = vader;
                thisPoint = thisPoint+...
                    reshape (SM(m1+1,m2+1,:),[3,1])*...
                    ((sigma1+1i*sigma2)^m1)*((sigma1-1i*sigma2)^m2);
                thisPoint1=thisPoint1+ reshape (SM(m1+1,m2+1,:),[3,1])*...
                    ((sigma11+1i*sigma21)^m1)*((sigma11-1i*sigma21)^m2);
                
               
                thisPoint_1 = thisPoint_1+...
                    reshape (SM_1(m1+1,m2+1,:),[3,1])*...
                    ((sigma1+1i*sigma2)^m1)*((sigma1-1i*sigma2)^m2);
                thisPoint_12=thisPoint_12+reshape (SM_1(m1+1,m2+1,:),[3,1])*...
                    ((sigma11+1i*sigma21)^m1)*((sigma11-1i*sigma21)^m2);
                
                
            end
        end
        Ws_loc(:, pointNum) = real(thisPoint);
        Ws_loc1(:,pointNum1)=real(thisPoint1);
       
        Ws_loc_1(:, pointNum_1) = real(thisPoint_1);
        Ws_loc_12(:,pointNum_12)=real(thisPoint_12);
        pointNum = pointNum +1;
        pointNum1=pointNum1+1;
        pointNum_1 = pointNum_1 +1;
        pointNum_12=pointNum_12+1;
        
    end
end
% To check convergence of fixed points in stable and unstable state
%  K=50;
%  u=zeros(3,K);
%  w=zeros(3,K);
%  u0=Ws_loc(:,300);% for stable
%  w0=Ws_loc_1(:,1000);%for unstable
%  u(:,1)=u0; % this goes forward
%  w(:,1)=w0; %this goes backward
%     
%     for k=1:K        
%   x0=for_function(u(:,k),rho,tau,a,b,c);
%   y0=back_function(w(:,k),rho,tau,a,b,c);
%             
%  u(:,k+1)= Newton_for_orbit(x0,u(:,k),rho,tau,a,b,c,epsi,alpha,beta,gamma);
%  w(:,k+1)= Newton2_back_orbit(y0,w(:,k),rho,tau,a,b,c,epsi,alpha,beta,gamma);
%     end   
%  orbit=u;
%  orbit_1=w;   

% figure
% hold on
% plot3(Ws_loc(1,:)',Ws_loc(2,:)', Ws_loc(3,:)','b')
% plot3(Ws_loc1(1,:)',Ws_loc1(2,:)',Ws_loc1(3,:)','b')
% 
% 
% 
% plot3(Ws_loc_1(1,:)',Ws_loc_1(2,:)', Ws_loc_1(3,:)','r')
% plot3(Ws_loc_12(1,:)',Ws_loc_12(2,:)',Ws_loc_12(3,:)','r')
% plot3(u(1,:),u(2,:),u(3,:),'k.')%forward
% plot3(w(1,:),w(2,:),w(3,:),'g.')%backward
% plot3(p0(1),p0(2),p0(3),'b*')
% plot3(p1(1),p1(2),p1(3),'r*')
% 
% figure
% plot3(Ws_loc(1,4950:5000)',Ws_loc(2,4950:5000)',Ws_loc(3,4952:5000)','k.')

            
% % To check convergence of fixed points in stable and unstable state
K=2;
S=Ws_loc1(:,4951:5000);
S1=Ws_loc_12(:,4951:5000);
iterates_S=zeros(3,50,K);
iterates_S1=zeros(3,50,K);
iterates_S(:,:,1)=S;
iterates_S1(:,:,1)=S1;
for j=2:K
    for i=1:50
       u0=iterates_S(:,i,j-1);
       w0=iterates_S1(:,i,j-1);
       x=back_function(u0,rho,tau,a,b,c);
       y=for_function(w0,rho,tau,a,b,c);
       
       iterates_S(:,i,j)=Newton2_back_orbit(x,u0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
       iterates_S1(:,i,j)=Newton_for_orbit(y,w0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
    end
end
       
iterates_S;
iterates_S1;



figure
hold on
plot3(Ws_loc(1,:)',Ws_loc(2,:)', Ws_loc(3,:)','b')
plot3(Ws_loc1(1,:)',Ws_loc1(2,:)',Ws_loc1(3,:)','b')


plot3(Ws_loc_1(1,:)',Ws_loc_1(2,:)', Ws_loc_1(3,:)','r')
plot3(Ws_loc_12(1,:)',Ws_loc_12(2,:)',Ws_loc_12(3,:)','r')
for i=1:K
    plot3(iterates_S(1,:,i)',iterates_S(2,:,i)',iterates_S(3,:,i)','b')
    plot3(iterates_S1(1,:,i)',iterates_S1(2,:,i)',iterates_S1(3,:,i)','r')
end


plot3(p0(1),p0(2),p0(3),'b*')
plot3(p1(1),p1(2),p1(3),'r*')

% %  figure
% %  plot3(Ws_loc(1,4500:5000)',Ws_loc(2,4500:5000)',Ws_loc(3,4500:5000)','k.')
%                 
%                 
%             
