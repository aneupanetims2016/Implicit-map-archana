function T = Period4_function(M,x,rho,tau,a,b,c,epsi,alpha,beta,gamma)
A=zeros(3*M,1);
A(3*M-2:3*M,1)= lomali_Im_funct(x(3*M-2:3*M),x(1:3),rho,tau,a,b,c,epsi,alpha,beta,gamma);
for j=0:M-2
   A(3*j+1:3*j+3)=lomali_Im_funct(x(3*j+1:3*j+3),x(3*j+4:3*j+6),rho,tau,a,b,c,epsi,alpha,beta,gamma);
   
end
T=A;


