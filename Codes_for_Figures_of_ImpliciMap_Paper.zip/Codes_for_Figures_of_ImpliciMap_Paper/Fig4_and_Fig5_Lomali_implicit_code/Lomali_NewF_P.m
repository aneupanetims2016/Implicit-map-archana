function x = Lomali_NewF_P(x0,rho,tau,a,b,c,epsi,alpha,beta,gamma)
x=x0;
   for i=1:10
F = Lomali_fixedp(x,rho,tau,a,b,c,epsi,alpha,beta,gamma);
DF = Derivative_lomali_fixedP(x,tau,a,b,c,epsi,alpha,beta,gamma);

   hn=(-1)*linsolve(DF,F);
   norm(hn);
   x= x+hn;
   end
Lomali_fixedp(x,rho,tau,a,b,c,epsi,alpha,beta,gamma);
end
