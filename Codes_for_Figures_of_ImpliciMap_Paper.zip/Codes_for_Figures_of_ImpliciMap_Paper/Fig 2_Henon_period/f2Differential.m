function df2=f2Differential(p, a, b,epsi)
df2 = -1*inv([1-5*epsi*p(1)*p(1)*p(1)*p(1),0;0,1+5*epsi*p(2)*p(2)*p(2)*p(2)])*[2*a*p(3), -1; 
              - b, 0];

