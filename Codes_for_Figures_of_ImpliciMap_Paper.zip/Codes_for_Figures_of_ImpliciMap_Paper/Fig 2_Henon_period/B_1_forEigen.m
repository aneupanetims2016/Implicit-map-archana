function B_1= B_1_forEigen(x, alpha,beta,epsi)
B_1 =( [1-5*epsi*x(1)^4,0; 0, 1+5*epsi*x(2)^4;]);
end

