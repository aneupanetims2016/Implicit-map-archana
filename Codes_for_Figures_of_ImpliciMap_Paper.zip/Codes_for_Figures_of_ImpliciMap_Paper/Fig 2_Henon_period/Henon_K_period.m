function t = Henon_K_period(x,y,a,b,e,K,N)

t=zeros(K,1)
    
for i=0:K-1
t(i+1)= x(mod(i+2,K)+1)-1+a*x(i+1)^2-y(i+1)+e*x(mod(i+2,K)+1)^5;
t(i+2)=y(mod(i+2,K)+1)-b*x(i+1)+e*y(mod(i+2,K)+1)^5;

end

