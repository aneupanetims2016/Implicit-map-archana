clear
format long

a = 1.4;
b = 0.3;
epsi=0.001;


N = 110;        %Polynomial approximation order
scale = 5;      %scaling/length of the eigenvector



p1 = [0; 1; 1;-1];
p = Imp_per2Newton(p1, a, b,epsi);

p0 = p(1:2);
q0 = p(3:4);

Dfp1 = Imp_henonPer2Diff(p, a, b,epsi);
[R, Sigma] = eigs(Dfp1);
lambda = Sigma(4,4);


tic
Df1 = [0,0,2*a*p(3),-1;0,0,-b,0; 2*a*p(1),-1,0,0;-b,0,0,0];
Df2 = [1-5*epsi*p(1)*p(1)*p(1)*p(1),0,0,0;...
    0,1+5*epsi*p(2)*p(2)*p(2)*p(2),0,0;...
    0,0,1-5*epsi*p(3)*p(3)*p(3)*p(3),0;...
    0,0,0,1+5*epsi*p(4)*p(4)*p(4)*p(4)];
P = zeros(2,N+1);
Q = zeros(2,N+1);
P(:, 1) = p0;
Q(:, 1) = q0;

S= scale*R(:,4);
P(:, 2)=S(1:2);
Q(:, 2)=S(3:4);


 for n = 2:N
     
%     %Compute the homological matrix:    
     A=Df1+lambda^n*Df2;
%     
%     %Compute the right hand side of the homological equatoin:
     temp_P1 = P(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum3 = a*sum(temp_P1.*temp_P2);     %Cauchy Product    
          
     temp_Q1 = Q(1, 1:n+1);
     temp_Q1(1) = 0;
     temp_Q1(n+1) = 0;
     temp_Q2 = fliplr(temp_Q1);   
     
     sum1 = a*sum(temp_Q1.*temp_Q2);    %Cauchy Product
     
     
     
     temp_P3 = temp_P1.*temp_P2;
     temp_P3(1)=0;
     temp_P3(n+1)=0;
     temp_P4=fliplr(temp_P3);
     temp_P5 = temp_P3.*temp_P4;
     temp_P5(1)=0;
     temp_P5(n+1)=0;
     sum2=epsi*sum(temp_P5.*temp_P2)*lambda^n;
     
     
     
     temp_P1_2=P(2, 1:n+1);
    temp_P1_2(1) = 0;
     temp_P1_2(n+1) = 0;
     temp_P2_2= fliplr(temp_P1_2);
     
     temp_P3_2= temp_P1_2.*temp_P2_2;
     temp_P3_2(1)=0;
     temp_P3_2(n+1)=0;
     temp_P4_2=fliplr(temp_P3_2);
     temp_P5_2= temp_P3_2.*temp_P4_2;
     temp_P5_2(1)=0;
     temp_P5_2(n+1)=0;
     sum4=epsi*sum(temp_P5_2.*temp_P2_2)*lambda^n;
     
     
     
      temp_Q3= temp_Q1.*temp_Q2;
      temp_Q3(1)=0;
      temp_Q3(n+1)=0;
     temp_Q4=fliplr(temp_Q3);
     temp_Q5 = temp_Q3.*temp_Q4;
     temp_Q5(1)=0;
     temp_Q5(n+1)=0;
     sum5=epsi*sum(temp_Q5.*temp_Q2)*lambda^n;
     
     
     temp_Q1_2=Q(2, 1:n+1);
    temp_Q1_2(1) = 0;
     temp_Q1_2(n+1) = 0;
     temp_Q2_2= fliplr(temp_Q1_2);
     
     temp_Q3_2 = temp_Q1_2.*temp_Q2_2;
     temp_Q3_2(1)=0;
     temp_Q3_2(n+1)=0;
     temp_Q4_2=fliplr(temp_Q3_2);
     temp_Q5_2= temp_Q3_2.*temp_Q4_2;
     temp_Q5_2(1)=0;
     temp_Q5_2(n+1)=0;
     sum6=epsi*sum(temp_Q5_2.*temp_Q2_2)*lambda^n;
     
     
     sum7= -sum1+sum2;
     sum8= -sum4;
     sum9=-sum3+sum5;
     sum10=-sum6;
     
       
%     %Solve the homological equation:
    % thisCoef =  A\[sum1; 0; sum3; 0];
     
     thisCoef=A\[sum7;sum8;sum9;sum10];
    
%     %Assigna the Taylor coefficients:
     P(:, n+1) = thisCoef(1:2);
     Q(:, n+1) = thisCoef(3:4);
 end


 manifoldComputeTime = toc
 
 
tic
% 
 coefAxis = linspace(0, N, N+1);
 theNorms_u1 = zeros(1, N+1);
  for n = 0:N
      theNorms_u1(n+1) = norm(abs(P(:, n+1)), inf);
  end
%  
%  
 theNorms_u2 = zeros(1, N+1);
  for n = 0:N
      theNorms_u2(n+1) = norm(abs(Q(:, n+1)), inf);
  end
 figure 
  hold on
  plot(coefAxis, log(theNorms_u1)/log(10), 'b'); 
  plot(coefAxis, log(theNorms_u2)/log(10), 'm');
  
  
 numPoints = 20000
 %Thetas = linspace(-0.3,0.3, numPoints);
 Thetas = linspace(-1,1, numPoints)
 
 Wu1 = [real(polyval(fliplr(P(1, :)), i*Thetas));
                   real(polyval(fliplr(P(2, :)), i*Thetas))];
     
 Wu2 = [real(polyval(fliplr(Q(1, :)), Thetas));
                   real(polyval(fliplr(Q(2, :)), Thetas))]; 


        
              
figure
hold on
plot(Wu1(1,:), Wu1(2,:), 'b')
plot(Wu2(1,:), Wu2(2,:), 'm')
plot(p0(1), p0(2), 'k*')
plot(q0(1), q0(2), 'g*')
%  txt = {'Stable Manifold ',' When epsilon=0.01'};
%  text(-0.5,5,txt)