format long

a = 1.4;
b = 0.3;
epsi=0.02
N = 110        %Polynomial approximation order
scale = 30      %scaling/length of the eigenvector



p1 = [0; 1; 1;-1];
p = Imp_per2Newton(p1, a, b,epsi);

p0 = p(1:2);
q0 = p(3:4);

Dfp1 = Imp_henonPer2Diff(p, a, b,epsi);
[R, Sigma] = eigs(Dfp1);
lambda1 = Sigma(1,1)
v_1 = R(:,1);
lambda3=Sigma(3,3)
v_3 = R(:,3);



tic
Df1 = [0,0,2*a*p(3),-1;0,0,-b,0; 2*a*p(1),-1,0,0;-b,0,0,0];
Df2 = [1-5*epsi*p(1)*p(1)*p(1)*p(1),0,0,0;...
    0,1+5*epsi*p(2)*p(2)*p(2)*p(2),0,0;...
    0,0,1-5*epsi*p(3)*p(3)*p(3)*p(3),0;...
    0,0,0,1+5*epsi*p(4)*p(4)*p(4)*p(4)];
P1 = zeros(2,N+1);
Q1 = zeros(2,N+1);
P2 = zeros(2,N+1);
Q2 = zeros(2,N+1);
 
P1(:, 1) = p0;
Q1(:, 1) = q0;
P2(:, 1) = p0;
Q2(:, 1) = q0;
 

S1= scale*v_1;
P1(:, 2)=S1(1:2);
Q1(:, 2)=S1(3:4);

S3= scale*v_3;
P2(:, 2)=S3(1:2);
Q2(:, 2)=S3(3:4);
 
 


[P1,Q1]= cauchy_product(Df1,Df2,p0,q0,lambda1,v_1,scale,a,b,epsi,N);
[P2,Q2]= cauchy_product(Df1,Df2,p0,q0,lambda3,v_3,scale,a,b,epsi,N);


 manifoldComputeTime = toc
 
 
tic
% 
 coefAxis = linspace(0, N, N+1);
 theNorms_u1 = zeros(1, N+1);
 s_theNorm_u1=zeros(1, N+1);
 
  for n = 0:N
      theNorms_u1(n+1) = norm(abs(P1(:, n+1)), inf);
    s_theNorms_u1(n+1) = norm(abs(P2(:, n+1)), inf);
  end
%  
%  
 theNorms_u2 = zeros(1, N+1);
 s_theNorms_u2 = zeros(1, N+1);
 
  for n = 0:N
      theNorms_u2(n+1) = norm(abs(Q1(:, n+1)), inf);
     s_theNorms_u2(n+1) = norm(abs(Q2(:, n+1)), inf);
      
  end
 figure 
  hold on
  plot(coefAxis, log(theNorms_u1)/log(10), 'b'); 
  plot(coefAxis, log(theNorms_u2)/log(10), 'm');
  figure 
  hold on
  plot(coefAxis, log(s_theNorms_u1)/log(10), 'b'); 
  plot(coefAxis, log(s_theNorms_u2)/log(10), 'm');
  
 numPoints = 20000;
 Thetas = linspace(-0.2,0.2, numPoints);
 
 Wu1 = [real(polyval(fliplr(P1(1, :)), Thetas));
                   real(polyval(fliplr(P1(2, :)), Thetas))];
     
 Wu2 = [real(polyval(fliplr(Q1(1, :)), 1i*Thetas));
                   real(polyval(fliplr(Q1(2, :)), 1i*Thetas))];
 
Ws1 = [real(polyval(fliplr(P2(1, :)), 1i*Thetas));
                   real(polyval(fliplr(P2(2, :)), 1i*Thetas))];
Ws2 = [real(polyval(fliplr(Q2(1, :)), Thetas));
                   real(polyval(fliplr(Q2(2, :)), Thetas))];              
               
%%%%%%%%
        
              
figure
hold on
  %plot(Wu1(1,:), Wu1(2,:),Wu2(1,:), Wu2(2,:), 'b')
 plot(Wu1(1,:), Wu1(2,:), 'k')
  plot(Wu2(1,:), Wu2(2,:), 'b')
  %plot(Ws1(1,:), Ws1(2,:),Ws2(1,:),Ws2(2,:),'m')
   plot(Ws1(1,:),Ws1(2,:),'m')
  plot(Ws2(1,:),Ws2(2,:),'r')
 
plot(p0(1), p0(2), 'k*')
plot(q0(1), q0(2), 'g*')
%txt = {'Chaos of A Henon map','When epsilon=0.001'};
%text(-.85,1.5,txt)


