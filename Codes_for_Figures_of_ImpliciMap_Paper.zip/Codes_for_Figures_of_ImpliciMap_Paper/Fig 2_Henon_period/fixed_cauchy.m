function [P,Q]=  fixed_cauchy(P,Q,p_f,mu,nu,alpha,beta,epsi,N)

 
for n = 2:N-1
      
      %Compute the homological matrix A:    
    A =  B_1_forEigen(p_f,alpha,beta,epsi)+(mu^n)*B_o_forEigen(p_f,alpha,beta,epsi);
    QB = B_1_forEigen(p_f,alpha,beta,epsi)+ (nu^n)*B_o_forEigen(p_f,alpha,beta,epsi);
    %     %Compute the right hand side of the homological equatoin:
    
    %for a^2 and a^5
     temp_P1 = P(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum1 = (-1)*alpha*sum(temp_P1.*temp_P2).*mu^n; 
     
%      temp_P3 = temp_P1.*temp_P2;
%      temp_P3(1) = 0;
%      temp_P3(n+1) = 0;
%      temp_P4 = fliplr(temp_P3);
%      temp_P5 = temp_P3.*temp_P4;
%      temp_P5(1) = 0;
%      temp_P5(n+1) = 0;
%      sum2 = epsi*sum(temp_P5.*temp_P2);
     
     sum2_test = epsi*conv5(P(1, 1:n+1), n);
     
     
     %      
%       if n == 2
%          sum2
%          sum2_test
%           
%          crashNow = crashHere 
%       end
     
     
     
     %for b^5
%       temp_P_2 = P(2, 1:n+1);
%       temp_P_2(1) = 0;
%       temp_P_2(n+1) = 0;
%       temp_P21 = fliplr(temp_P_2); 
%       temp_P6 = temp_P_2.*temp_P21;
%       temp_P6(1) = 0;
%       temp_P6(n+1) = 0;
%       temp_P7 = fliplr(temp_P6);
%       temp_P8 = temp_P6.*temp_P7;
%       temp_P8(1) = 0;
%       temp_P8(n+1) = 0;
%       sum3 = (-1)*epsi*sum(temp_P8.*temp_P21);       
         
      sum3_test = (-1)*epsi*conv5(P(2, 1:n+1), n);
     
    
     
      sum4 = sum1 + sum2_test;
      %sum4 = sum1 +sum2;
      %S = [sum4;sum3;]; 
      S = [sum4; sum3_test];
      thisCoef = A\S;
     P(:, n+1) = thisCoef;
    
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    temp_Q1 = Q(1, 1:n+1);
     temp_Q1(1) = 0;
     temp_Q1(n+1) = 0;
     temp_Q2 = fliplr(temp_Q1);    
     Qsum1 = (-1)*alpha*sum(temp_Q1.*temp_Q2).*nu^n; 
     
    
%      temp_Q3 = temp_Q1.*temp_Q2;
%      temp_Q3(1) = 0;
%      temp_Q3(n+1) = 0;
%      temp_Q4 = fliplr(temp_Q3);
%      temp_Q5 = temp_Q3.*temp_Q4;
%      temp_Q5(1) = 0;
%      temp_Q5(n+1) = 0;
%      Qsum2 = epsi*sum(temp_Q5.*temp_Q2);
     

     
     Qsum2_test = epsi*conv5(Q(1, 1:n+1), n);
     
     
%       temp_Q_2 = Q(2, 1:n+1);
%       temp_Q_2(1) = 0;
%       temp_Q_2(n+1) = 0;
%       temp_Q21 = fliplr(temp_Q_2); 
%       temp_Q6 = temp_Q_2.*temp_Q21;
%       temp_Q6(1) = 0;
%       temp_Q6(n+1) = 0;
%       temp_Q7 = fliplr(temp_Q6);
%       temp_Q8 = temp_Q6.*temp_Q7;
%       temp_Q8(1) = 0;
%       temp_Q8(n+1) = 0;
%       Qsum3 = (-1)*epsi*sum(temp_Q8.*temp_Q21);       
         
      Qsum3_test = -epsi*conv5(Q(2, 1:n+1), n);
       
      Qsum4 = Qsum1 + Qsum2_test;
      QS = [Qsum4;Qsum3_test;];      
      QthisCoef = QB\QS;
      Q(:, n+1) = QthisCoef;      
     
end
end
