function B_0 = B_o_forEigen(x,alpha,beta,epsi)

B_0=[2*alpha*x(1),-1; -beta*1,0;];
end

