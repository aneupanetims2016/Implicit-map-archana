function p = Imp_per2Newton(p0, a, b,epsi)

p = p0;
for n = 1:110
   p = p - inv(Im_henonDifferential(p, a, b, epsi))*Imp_henonPer2(p, a, b,epsi);
   error = norm(Imp_henonPer2(p, a, b,epsi), inf);
end

error