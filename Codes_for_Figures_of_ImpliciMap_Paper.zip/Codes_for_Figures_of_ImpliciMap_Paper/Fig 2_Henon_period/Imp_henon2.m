function z = Imp_henon2(x, a, b,epsi)


z = zeros(2, 1);

z(1) =x(1)- (1 - a*x(3)*x(3) + x(4)+epsi*x(1)*x(1)*x(1)*x(1)*x(1));
z(2) =x(2)- b*x(3)+epsi*x(2)*x(2)*x(2)*x(2)*x(2);
