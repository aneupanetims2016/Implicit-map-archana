function p = Imp_henon_per_K_Newton(p0,a,b,K,epsi)
p0=zeros(1,2*K);
p = p0;
for n = 1:110
   p = p - inv(Im_henonK_Differential(p, a, b,K, epsi))*Imp_henonPerK(p, a, b,K,epsi);
   error = norm(Imp_henonPerK(p, a, b,K,epsi), inf);
end



