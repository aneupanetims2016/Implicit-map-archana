function p = evaluateParm(s, A)

p = [real(polyval(fliplr(A(1, :)), s));
     real(polyval(fliplr(A(2, :)), s))];

end