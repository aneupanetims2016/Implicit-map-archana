% %  syms x;
% % a=-5:0.1:5;
% % b=-5:0.1:5;
% % [A,B]=meshgrid(a,b);
% % y1=0;
% % w1=0;
% % y2=0;
% % w2=0;
% % for n=1:21
% % y1=y1+P(1,n)*(A).^(n-1);
% % w1=w1+P(2,n)*(A).^(n-1);
% % y2=y2+Q(1,n)*(A).^(n-1);
% % w2=w2+Q(2,n)*(A).^(n-1);
% % end
% % y1;
% % w1;
% % y2;
% % w2;
% % 
% % 
% %  surf(a,b,abs(y1));
% %  hold on
% %  surf(a,b,abs(w1));
% % 
% % 
% % surf(a,b,abs(y2));
% % hold on
% % surf(a,b,abs(w2));
% %               
%  
%   X=-1:0.0001:1;
%   Y1=zeros(size(X));
%   Z1=zeros(size(X));
%  Y2=Y1;
%  Z2=Z1;
%  Y3=Y1;
%  Z3=Z1;
%  Y4=Y1;
%  Z4=Z1;
%  
%   for n=1:length(P(1,:))
%      Y1 = Y1 + X.^(n-1)*real(P(1,n));
%      Z1 = Z1 + X.^(n-1)*imag(P(1,n));
%      Y2 = Y2 + X.^(n-1)*real(P(2,n));
%      Z2 = Z2 + X.^(n-1)*imag(P(2,n));
%      Y3 = Y1 + X.^(n-1)*real(Q(1,n));
%      Z3 = Z1 + X.^(n-1)*imag(Q(1,n));
%      Y4 = Y2 + X.^(n-1)*real(Q(2,n));
%      Z4 = Z2 + X.^(n-1)*imag(Q(2,n));
%  end
%   figure
%   hold on
%    plot3(X,Y1,Z1); 
%  plot3(X,Y2,Z2);
%  plot3(X,Y3,Z3); 
%  plot3(X,Y4,Z4);
%  xlabel('input')
%  ylabel('real')
%  zlabel('imaginary')
% 