function z = henon(x, a, b,epsi)


z = zeros(2, 1);

z(1) = x(3)-1 - a*x(1)*x(1) + x(2)-epsi*x(3)^5;
z(2) =x(4)- b*x(1)+epsi*x(4)^5;

