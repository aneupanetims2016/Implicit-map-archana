function [P,Q]= cauchy_product(Df1,Df2,p0,q0,lambda,v,scale,a,b,epsi,N)
P = zeros(2,N+1);
Q = zeros(2,N+1);
 
P(:, 1) = p0;
Q(:, 1) = q0;
 

S1= scale*v;
P(:, 2) = S1(1:2);
Q(:, 2) = S1(3:4);

for n = 2:N
     
     %Compute the homological matrix:    
     A1=Df1+lambda^n*Df2;
     
     
     %Compute the right hand side of the homological equatoin:

     sum3 = a*conv_2(P(1, 1:n+1), n); %a^2
          
 
     
     sum1 = a*conv_2(Q(1, 1:n+1), n);  %c^2  %Cauchy Product   
     
     

     sum2 = epsi*conv5(P(1, 1:n+1), n)*lambda^n;  %a^5   
     
     

     sum4 = epsi*conv5(P(2, 1:n+1), n)*lambda^n;   %b^5   
     
     

     sum5 = epsi*conv5(Q(1, 1:n+1), n)*lambda^n;  %c^5
     
     

     sum6 = epsi*conv5(Q(2, 1:n+1), n)*lambda^n;  %d^5
     
     
     sum7= -sum1 + sum2;   %-c^2 + a^5
     sum8= -sum4;           %-b^5
     sum9= -sum3 + sum5;    %-a^2+ c^5
     sum10= -sum6;          %-d^5
     
       
    %Solve the homological equation:
    % thisCoef =  A\[sum1; 0; sum3; 0];
     
     thisCoef = linsolve(A1,[sum7;sum8;sum9;sum10]);
    
     %Assigna the Taylor coefficients:
     P(:, n+1) = thisCoef(1:2);
     Q(:, n+1) = thisCoef(3:4);
 end



end

