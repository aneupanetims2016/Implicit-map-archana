
%1D Manifold for Lomali Map of fixed point testing
clear all
format long
a=0.5;
b=-0.5;
c=1;
tau=1.333333333;
rho=0.344444444;
N=40;

%       epsi=0;
       epsi=0.001;

 alpha=.09;
 beta=1.86;
 gamma=.0019;
 
 x0_1=[1;1;1;];
%  x0_2=[-1.5;-1;-1;];
 
 scale=0.05;
 scale1=0.5;

p0= Lomali_NewF_P(x0_1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
% p0= Lomali_NewF_P(x0_2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 
  
 [R,Sigma]=eig(diff_fixedP(p0,tau,a,b,c,epsi,alpha,beta,gamma));
 P=zeros(3,N+1);
 Q=zeros(3,N+1);
  
 Lambda=Sigma(1,1); %unstable
 P(:,1)=p0;
 P(:,2)=scale1*R(:,1);
 Tambda=Sigma(2,2);
 Q(:,1)=p0;
 Q(:,2)=scale*R(:,2); 
  
  tic
 for n = 2:N
      
      %Compute the homological matrix:    
    A =partial_diff_1(p0,tau,a,b,c)+Lambda.^n*partial_diff_2(p0,epsi,alpha,beta,gamma);   
% %     %Compute the right hand side of the homological equatoin:
     temp_P1 = P(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum1 = a*sum(temp_P1.*temp_P2);     %Cauchy Product    
           
      temp_P2 = P(2, 1:n+1);
      temp_P2(1) = 0;
      temp_P2(n+1) = 0;
      temp_P21 = fliplr(temp_P2);   
     
     sum3 = c*sum(temp_P2.*temp_P21);    %Cauchy Product      
     sum2 = b*sum(temp_P1.*temp_P21);

     sum4=epsi*alpha*conv5(P(2, 1:n+1),n)*Lambda.^n;    

     sum5=epsi*beta*conv5(P(3,1:n+1),n)*Lambda.^n;
           
     sum6= sum1+sum2+sum3-sum4-sum5;
     sum7= (-1)*epsi*gamma*conv5(P(3,1:n+1),n)*Lambda.^n;      
     S=[sum6;sum7;0]; %      
    thisCoef= linsolve(A,S);
     
 %     %Assigna the Taylor coefficients:
     P(:, n+1) = thisCoef;  
     
    
      
  end
 
  P; %unstable     
  toc   
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      

  tic
  
 for n = 2:N
      
      %Compute the homological matrix:    
    B =partial_diff_1(p0,tau,a,b,c)+Tambda.^n*partial_diff_2(p0,epsi,alpha,beta,gamma);
    
% %     %Compute the right hand side of the homological equatoin:
     temp_P1 = Q(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum1 = a*sum(temp_P1.*temp_P2);     %Cauchy Product    
           
      temp_P2 = Q(2, 1:n+1);
      temp_P2(1) = 0;
      temp_P2(n+1) = 0;
      temp_P21 = fliplr(temp_P2);   
     
      sum3 = c*sum(temp_P2.*temp_P21);    %Cauchy Product
      
      sum2 = b*sum(temp_P1.*temp_P21);     

      sum4=epsi*alpha*conv5(Q(2, 1:n+1),n)*Tambda.^n;
      

      sum5= epsi*beta*conv5(Q(3,1:n+1),n)*Tambda.^n;
      sum6= sum1+sum2+sum3-sum4-sum5;
      sum7= (-1)*epsi*gamma*conv5(Q(3,1:n+1),n)*Tambda.^n;      
      T=[sum6;sum7;0];  
%      
     thisCoef1= linsolve(B,T);     
% 
     Q(:, n+1) = thisCoef1;     
      
  end
  
  Q; %stable
toc
    numPoints = 100;
    Thetas = linspace(-1,1, numPoints);
    Thetas1 = linspace(-1/abs(Lambda),1/abs(Lambda), numPoints);
   
   
   
  Q_N_Theta= new_evaluate(Q,Thetas);
  Q_N_Tambda_Theta = new_evaluate(Q,Tambda*Thetas);
  
  P_N_Theta= new_evaluate(P,Thetas1);
  P_N_Lambda_Theta = new_evaluate(P,Lambda*Thetas1);
  
  
  
   D=zeros(3,100);
   error=zeros(1,100);
  for i=1:100
    x1 = Q_N_Theta(:,i); 
    x2= Q_N_Tambda_Theta(:,i);
    D(:,i) = lomali_Im_funct(x1,x2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
    error(i) = norm(D(:,i),inf);
  end  
    error;
   Stable_error_max_S = max(error) %stable error
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Q_N_Tambda_Theta;    
    K=2;
 iterates_S1=zeros(3,numPoints,K); 
 iterates_S1(:,:,1)= Q_N_Tambda_Theta;
  for j=2:K
    for i=1:numPoints
       v0=iterates_S1(:,i,j-1); %unstable        
       y = back_function(v0,rho,tau,a,b,c);
       iterates_S1(:,i,j)= Newton2_back_orbit(y,v0,rho,tau,a,b,c,epsi,alpha,beta,gamma); 
    end
 end   
    S3=iterates_S1(:,:,2);
    S4=Q_N_Theta;
    error_2=zeros(1,numPoints);
    for i=1:numPoints
    error_2(i)=norm(S3(:,i)-S4(:,i),inf);   
    end
   Stable_error_max_F_S = max(error_2)  %P(theta)= f^(-1)(p(lambda theta)) error stable
   
   %unstable error
   D_U=zeros(3,100);
   error_U=zeros(1,100);
  for i=1:100
    x1 = P_N_Theta(:,i); 
    x2= P_N_Lambda_Theta(:,i);
    D_U(:,i) = lomali_Im_funct(x1,x2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
    error_U(i) = norm(D_U(:,i),inf);
  end  
    error;
   UnStable_error_max_U = max(error_U) %unstable error
   
   
   P_N_Theta;    
    K=2;
 iterates_S1_U=zeros(3,numPoints,K); 
 iterates_S1_U(:,:,1)= P_N_Theta;
  for j=2:K
    for i=1:numPoints
       v0=iterates_S1_U(:,i,j-1); %unstable        
       y = for_function(v0,rho,tau,a,b,c);
       iterates_S1_U(:,i,j)= Newton_for_orbit(y,v0,rho,tau,a,b,c,epsi,alpha,beta,gamma); 
    end
 end   
    S3_U=iterates_S1_U(:,:,2);
    S4_U=P_N_Lambda_Theta;
    error_2_U=zeros(1,numPoints);
    for i=1:numPoints
    error_2_U(i)=norm(S3_U(:,i)-S4_U(:,i),inf);   
    end
   UnStable_error_max_F_U = max(error_2_U)  %f(P(theta))= P(lambda theta) error unstable
   
    
  
  
  
  
  
     
    
    
   

  
  