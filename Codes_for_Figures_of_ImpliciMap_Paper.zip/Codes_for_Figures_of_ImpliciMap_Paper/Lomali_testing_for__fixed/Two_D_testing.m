
%2D Manifold for Lomali Map of fixed points
clear all
format long
a=0.5;
b=-0.5;
c=1;
tau=1.333333333;
rho=0.344444444;
N=25;

%        epsi=0;
        epsi=0.03;

 alpha=1;
 beta=1;
 gamma=1;
 
 x0_1=[1;1;1;];
%   x0_2=[-1.5;-1;-1;];
  x0_2=[-1;-1;-1.5];
 
 scale=0.25;
 
%Two fixed points of Implicit Lomali systems
p0= Lomali_NewF_P(x0_1,rho,tau,a,b,c,epsi,alpha,beta,gamma);
p1= Lomali_NewF_P(x0_2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
 
 %Eigen values and eigen vector according as fixed points 
 [R,Sigma]=eig(diff_fixedP(p0,tau,a,b,c,epsi,alpha,beta,gamma));
 [T,Uigma]=eig(diff_fixedP(p1,tau,a,b,c,epsi,alpha,beta,gamma));
 
 P=zeros(N+1,N+1,3);
 Q=zeros(N+1,N+1,3);
  
 Lambda_u=Sigma(1,1); 
 x1_u=scale*R(:,1);
 
 
 
 L_1=Sigma(2,2); %stable eigenvalues
 L_2=Sigma(3,3);
 

 v_1=scale*R(:,2);
 v_2=scale*R(:,3);
P(1,1,:)=p0;
P(2,1,:)=v_1;
P(1,2,:)=v_2;

Lambda_u_1=Uigma(3,3); 
 K1_s=scale*T(:,3);
 
 
 K_1=Uigma(1,1);  %unstable eigenvalues
 K_2=Uigma(2,2);

 
 % these are  different radii for extension of manifold
  radii1=max(abs(L_1),abs(L_2));
  radii2=max( 1/abs(K_1),1/abs(K_2));
  radii=max(radii1,radii2);
 
 w_1=scale*T(:,1);
 w_2=scale*T(:,2);
Q(1,1,:)=p1;
Q(2,1,:)=w_1;
Q(1,2,:)=w_2;
% homological equations

D1_T=partial_diff_1(p0,tau,a,b,c);
D2_T=partial_diff_2(p0,epsi,alpha,beta,gamma);

D1_T_1=partial_diff_1(p1,tau,a,b,c);
D2_T_2=partial_diff_2(p1,epsi,alpha,beta,gamma);

  tic
  
% these SM and SM_1 gives coefficients

SM = computeMan_1(P,D1_T,D2_T,L_1,L_2,N,a,b,c,epsi,alpha,beta,gamma);
SM_1=computeMan_1(Q,D1_T_1,D2_T_2,K_1,K_2,N,a,b,c,epsi,alpha,beta,gamma);
SM;
SM_1;
toc
numR = 20;
numTheta = 10;
% plotting in different radii
the_rs = linspace(0.001,1,numR);%stable

the_rs1 = linspace(0.001,radii2,numR);%unstable


the_theta = linspace(0,2*pi,numTheta);

numPoints = numR*numTheta;
Ws_loc   = zeros(3, numPoints); %stable
Ws_loc_L   = zeros(3, numPoints);

Ws_loc_1  = zeros(3, numPoints); %unstable
Ws_loc_1_K = zeros(3,numPoints);

pointNum = 1;
pointNum_1 = 1;

for m = 1:numR
    m;
    numR;
    for n =1:numTheta
        this_r = the_rs(m);
        this_r1 = the_rs1(m);       
        
        this_theta = the_theta(n); %stable
        sigma1 = this_r*cos(this_theta);
        sigma2 = this_r*sin(this_theta);
        
        sigma1_L = this_r*cos(this_theta);
        sigma2_L = this_r*sin(this_theta);
        
      
        
        sigma11 = this_r1*cos(this_theta); %unstable
        sigma21 = this_r1*sin(this_theta);    
        
        sigma11_K =  this_r1*cos(this_theta);
        sigma21_K =  this_r1*sin(this_theta);  
        
        
        thisPoint = [0;0;0]; %for stable
        thisPoint_L = [0;0;0];        
        
        
        thisPoint_1 = [0;0;0]; %for unstable
        thisPoint_1_K = [0;0;0];
        
        
        
 
        for order = 0:N
            for vader = 0:order
                m1 = order-vader;
                m2 = vader;
                thisPoint = thisPoint+...
                    reshape (SM(m1+1,m2+1,:),[3,1])*...
                    ((sigma1+1i*sigma2)^m1)*((sigma1-1i*sigma2)^m2);
                
                thisPoint_L = thisPoint_L+...                    
                        reshape (SM(m1+1,m2+1,:),[3,1])*...
                    ((L_1*(sigma1_L+1i*sigma2_L))^m1)*((L_2*(sigma1_L-1i*sigma2_L))^m2);            
                
                
               
                thisPoint_1 = thisPoint_1+...
                    reshape (SM_1(m1+1,m2+1,:),[3,1])*...
                    ((sigma11+1i*sigma21)^m1)*((sigma11-1i*sigma21)^m2);
                thisPoint_1_K = thisPoint_1_K+...
                    reshape (SM_1(m1+1,m2+1,:),[3,1])*...
                    ((K_1*(sigma11_K+1i*sigma21_K))^m1)*((K_2*(sigma11_K-1i*sigma21_K))^m2);              
                
                
                
            end
        end
        Ws_loc(:, pointNum) = real(thisPoint);
        Ws_loc_L(:, pointNum) = real(thisPoint_L);        
       
       
        Ws_loc_1(:, pointNum_1) = real(thisPoint_1);
        Ws_loc_1_K(:,pointNum_1)= real(thisPoint_1_K);
        pointNum = pointNum +1;       
        pointNum_1 = pointNum_1+1;
       
        
    end
end

P_N_Theta = Ws_loc;
P_N_Lambda_Theta = Ws_loc_L;

Q_N_Theta = Ws_loc_1;
Q_N_Lambda_Theta = Ws_loc_1_K;

D=zeros(3,numPoints);
error= zeros(1,numPoints);
for k=1:numPoints
    x1= P_N_Theta(:,k);
    x2= P_N_Lambda_Theta(:,k);
    D(:,k)= lomali_Im_funct(x1,x2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
    error(k)=norm(D(:,k),inf);
end 
error;
 Stable_error_max_S = max(error)
% return
%P_N_Theta
            
% % To test error of fixed points in stable 
 K=2;
 S=P_N_Lambda_Theta;
 iterates_S=zeros(3,numPoints,K);
 iterates_S(:,:,1)=S;

 for j=2:K
     for i=1:numPoints
        u0 = iterates_S(:,i,j-1);
        x = back_function(u0,rho,tau,a,b,c);
        iterates_S(:,i,j) = Newton2_back_orbit(x,u0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
       
     end
 end
    S3=iterates_S(:,:,2);
    S4=P_N_Theta;
    error_2=zeros(1,numPoints);
    for i=1:numPoints
    error_2(i)=norm(S3(:,i)-S4(:,i),inf);   
    end
   Stable_error_max_f_S = max(error_2) %P(theta)= f^(-1)(p(lambda theta)) error stable

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
D_U=zeros(3,numPoints);
error_U= zeros(1,numPoints);
for k=1:numPoints
    x1= Q_N_Theta(:,k);
    x2= Q_N_Lambda_Theta(:,k);
    D_U(:,k)= lomali_Im_funct(x1,x2,rho,tau,a,b,c,epsi,alpha,beta,gamma);
    error_U(k)=norm(D_U(:,k),inf);
end 
error;
 UnStable_error_max_U = max(error_U)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 K=2;
 S1=Q_N_Theta;
 iterates_S1=zeros(3,numPoints,K);
 iterates_S1(:,:,1)=S1;

 for j=2:K
     for i=1:numPoints        
       w0=iterates_S1(:,i,j-1);
       y=for_function(w0,rho,tau,a,b,c);  
       iterates_S1(:,i,j)=Newton_for_orbit(y,w0,rho,tau,a,b,c,epsi,alpha,beta,gamma);
     end
 end
    S3_U = iterates_S1(:,:,2);
    S4_U = Q_N_Lambda_Theta;
    error_2_U=zeros(1,numPoints);
    for i=1:numPoints
    error_2_U(i) = norm(S3_U(:,i)-S4_U(:,i),inf);   
    end
   UnStable_error_max_f_U = max(error_2_U) %f(P(theta))= P(lambda theta) error unstable
