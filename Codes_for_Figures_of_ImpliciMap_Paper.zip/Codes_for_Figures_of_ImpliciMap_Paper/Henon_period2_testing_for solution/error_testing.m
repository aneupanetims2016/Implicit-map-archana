%stable and unstable manifold in period 2 henon error testing
clear
format long

a = 1.4;
b = 0.3;
epsi = 0.03;
N = 50;        %Polynomial approximation order
scale_U = 0.5; %10^(-10);%?????????????
scale_S = 0.5; % 10^(-10); %scaling/length of the eigenvector
% scale =0.5;

p1 =[-0.481693344976797;
   0.293142614418809;
   0.977214204242056;
  -0.144507373334196];

% p1 = [0; 1; 1; -1];
p = Imp_per2Newton(p1, a, b,epsi);



% return

p0 = p(1:2);
q0 = p(3:4);

Dfp1 = Imp_henonPer2Diff(p, a, b,epsi);


[R, Sigma] = eigs(Dfp1);
lambda1 = Sigma(1,1); %unstable
v_1 = R(:,1);
lambda3 = Sigma(3,3) %stable
v_3 = R(:,3)



tic
Df1 = [0,0,2*a*p(3),-1;0,0,-b,0; 2*a*p(1),-1,0,0;-b,0,0,0];
Df2 = [1-5*epsi*p(1)*p(1)*p(1)*p(1),0,0,0;...
    0,1+5*epsi*p(2)*p(2)*p(2)*p(2),0,0;...
    0,0,1-5*epsi*p(3)*p(3)*p(3)*p(3),0;...
    0,0,0,1+5*epsi*p(4)*p(4)*p(4)*p(4)];
 


[P1,Q1]= cauchy_product(Df1,Df2,p0,q0,lambda1,v_1,scale_U,a,b,epsi,N);%unstable

[P2,Q2]= cauchy_product(Df1,Df2,p0,q0,lambda3,v_3,scale_S,a,b,epsi,N); %stable

% return


 manifoldComputeTime = toc
 
 

  
 numPoints = 100;
 Thetas  = linspace(-1,1, numPoints);
%  mu = abs(lambda1^(-1));
 Thetas1 = linspace(-1/abs(lambda1), 1/abs(lambda1), numPoints);
 %unstable
 P_N_Theta_U = [real(polyval(fliplr(P1(1, :)), Thetas1));
                   real(polyval(fliplr(P1(2, :)), Thetas1))]; %%%
 P_N_Lambda_Theta_U = [real(polyval(fliplr(P1(1, :)), abs(lambda1)*Thetas1));
                   real(polyval(fliplr(P1(2, :)), abs(lambda1)*Thetas1))];              
     
 Q_N_Theta_U = [real(polyval(fliplr(Q1(1, :)), (-1i)*Thetas1));
                   real(polyval(fliplr(Q1(2, :)),(-1i)*Thetas1))];          %I changed here
 Q_N_Lambda_Theta_U = [real(polyval(fliplr(Q1(1, :)), abs(lambda1)*1i*Thetas1));
                   real(polyval(fliplr(Q1(2, :)), abs(lambda1)*1i*Thetas1))];  %%% 
               
               
               
               
 %stable
P_N_Theta_S = [real(polyval(fliplr(P2(1, :)), (-1i)*Thetas));
                   real(polyval(fliplr(P2(2, :)), (-1i)*Thetas))];         % I changed here
               
P_N_Lambda_Theta_S = [real(polyval(fliplr(P2(1, :)), abs(lambda3)*1i*Thetas));
                   real(polyval(fliplr(P2(2, :)), abs(lambda3)*1i*Thetas))];  %%%%%%
                              
               
Q_N_Theta_S = [real(polyval(fliplr(Q2(1, :)), Thetas));
                   real(polyval(fliplr(Q2(2, :)), Thetas))];  %%%%%%  

Q_N_Lambda_Theta_S = [real(polyval(fliplr(Q2(1, :)), abs(lambda3)*Thetas));
                   real(polyval(fliplr(Q2(2, :)), abs(lambda3)*Thetas))];               
               
%%%%%%%%
        
      %T(Q_N_Theta_S, P_N_lambda_Theta_S)=0
      %T(P_N_Theta_S, Q_N_lambdaa_Theta_S)=0

 D1= zeros(2,numPoints);
 D2= zeros(2,numPoints);
   error1= zeros(1,numPoints);
   error2= zeros(1,numPoints);
  for k=1:numPoints
    x = [P_N_Theta_S(:,k); Q_N_Lambda_Theta_S(:,k)]; %bad error
    y = [Q_N_Theta_S(:,k); P_N_Lambda_Theta_S(:,k)];  %good error
    D1(:,k) = Imp_henon1(x, a, b,epsi);
    D2(:,k) = Imp_henon1(y, a, b,epsi);
    error1(k) = norm(D1(:,k),inf);
    error2(k) = norm(D2(:,k),inf);
  end  
    error1;
    error2;
   Stable_error_max_S1 = max(error1) % bad error
   Stable_error_max_S2 = max(error2) %good error
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5555
%Unstable case
K1 = zeros(2,numPoints);
K2 = zeros(2,numPoints);
   error1_U=zeros(1,numPoints);
   error2_U= zeros(1,numPoints);
  for k=1:numPoints
    x = [P_N_Theta_U(:,k); Q_N_Lambda_Theta_U(:,k)];  %(x_1,y_1, x_2, y_2)c%good error
    y = [Q_N_Theta_U(:,k); P_N_Lambda_Theta_U(:,k)];   %bad error
    K1(:,k) = Imp_henon1(x, a, b,epsi);
    K2(:,k) = Imp_henon1(y, a, b,epsi);
    error1_U(k) = norm(K1(:,k),inf);
    error2_U(k) = norm(K2(:,k),inf);
  end  
    error1_U;
    error2_U;
   Unstable_error_max_U1 = max(error1_U) %good error %Unstable error
   Unstable_error_max_U2 = max(error2_U) %bad error
%  return
   %%%%%%%%%%%%%%%%%%%%%%5
 S1 = P_N_Theta_U;             %(x_2, y_2)
 K = 2;
 NumR = numPoints;
 iterates_U1 = zeros(2,NumR,K);
 iterates_U1(:,:,1) = S1;

 
 for j=2:K
    for k = 1:NumR
       u0 = iterates_U1(:,k,j-1); %(x_2,y_2)given unstable 
       y = for_function(u0,a,b); %(x_1,y_1) initial value
       iterates_U1(:,k,j)= Newton_for_orbit(y, u0, a, b, epsi); % we got (x_1,y_1)by Newton
    end
 end   
    S3 = iterates_U1(:,:,K);
    S4 = Q_N_Lambda_Theta_U;          %T(Q_N_Theta_U, P_N_Lambda_Theta)=0 
    error = zeros(1,numPoints);         % to check norm((x_1,y_1)- Q_N_Theta_U)
    for k = 1:numPoints
    error(k)= norm(S3(:,k)-S4(:,k),inf);   
    end
   UnStable_error_max_F1 = max(error)  
    
%     return
 S2 = Q_N_Lambda_Theta_U;             %(x_2, y_2)
 K = 2;
 NumR = numPoints;
 iterates_U2 = zeros(2,NumR,K);
 iterates_U2(:,:,1) = S2;

 
 for j=2:K
    for k = 1:NumR
       u0 = iterates_U2(:,k,j-1); 
       y = back_function(u0,a,b); 
       iterates_U2(:,k,j)= Newton_back_function(y, u0, a, b, epsi); 
    end
 end   
    S5 = iterates_U2(:,:,K);
    S6 = P_N_Theta_U;         
    error3 = zeros(1,numPoints);         % to check norm((x_1,y_1)- Q_N_Theta_U)
    for k = 1:numPoints
    error3(k)= norm(S5(:,k)-S6(:,k),inf);   
    end
   UnStable_error_max_F2 = max(error3) 
   
   
 S_3 = P_N_Lambda_Theta_U;             %(x_2, y_2)
 K = 2;
 NumR = numPoints;
 iterates_U3 = zeros(2,NumR,K);
 iterates_U3(:,:,1) = S_3;
 
 for j=2:K
    for k = 1:NumR
       u0 = iterates_U3(:,k,j-1); %(x_2,y_2)given unstable 
       y = back_function(u0,a,b); %(x_1,y_1) initial value
       iterates_U3(:,k,j)= Newton_back_function(y, u0, a, b, epsi); % we got (x_1,y_1)by Newton
    end
 end   
    S7 = iterates_U3(:,:,K);
    S8 = Q_N_Theta_U;          %T(Q_N_Theta_U, P_N_Lambda_Theta)=0 
    error = zeros(1,numPoints);         % to check norm((x_1,y_1)- Q_N_Theta_U)
    for k = 1:numPoints
    error(k)= norm(S7(:,k)-S8(:,k),inf);   
    end
   UnStable_error_max_F3 = max(error)
   
   
%    return 
   
   
 S = P_N_Theta_S;             %(x_2, y_2)
 K = 2;
 NumR = numPoints;
 iterates_S = zeros(2,NumR,K);
 iterates_S(:,:,1) = S;
 
 for j=2:K
    for k=1:NumR
       u0 = iterates_S(:,k,j-1); %(x_2,y_2)given unstable 
       y = for_function(u0,a,b); %(x_1,y_1) initial value
       iterates_S(:,k,j)= Newton_for_orbit(y, u0, a, b, epsi); % we got (x_1,y_1)by Newton
    end
 end   
    S3 =iterates_S(:,:,K);
    S4 = Q_N_Lambda_Theta_S;          %T(Q_N_Theta_U, P_N_Lambda_Theta)=0 
    error1=zeros(1,numPoints);         % to check norm((x_1,y_1)- Q_N_Theta_U)
    for k=1:numPoints
    error1(k)= norm(S3(:,k)-S4(:,k),inf);   
    end
   Stable_error_max_F = max(error1)  %Q(theta)= f^(-1)(P(lambda theta)) error stable
    