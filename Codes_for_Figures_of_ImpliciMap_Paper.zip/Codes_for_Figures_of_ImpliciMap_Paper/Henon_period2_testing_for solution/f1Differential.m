function df1 = f1Differential(p, a, b,epsi)
df1 = -1*linsolve([1-5*epsi*p(3)*p(3)*p(3)*p(3),0;0,1+5*epsi*p(4)*p(4)*p(4)*p(4)],[2*a*p(1), -1; 
               -b, 0]);
