function df = Diff_for_Eigen(x,alpha,beta, epsi)
df =-1*(B_1_forEigen(x, alpha,beta,epsi))^(-1)*(B_o_forEigen(x,alpha,beta,epsi));

end

