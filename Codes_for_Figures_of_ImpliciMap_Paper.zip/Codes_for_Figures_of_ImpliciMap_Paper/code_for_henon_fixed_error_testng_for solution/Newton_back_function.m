function x = Newton_back_function(x0,v0,alpha,beta,epsi)
x=x0;
for i=1:4
    F= [v0(1)-(1-alpha*x(1)^2+x(2)+epsi*v0(1)^5); v0(2)-beta*x(1)+epsi*v0(2)^5];
    DF= [2*alpha*x(1), -1; -beta,0;];   
    h=(-1)*linsolve(DF,F);
    x=x+h;    
end
x;

