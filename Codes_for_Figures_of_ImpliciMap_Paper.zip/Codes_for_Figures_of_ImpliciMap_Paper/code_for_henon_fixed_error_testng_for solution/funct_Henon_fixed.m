function F =funct_Henon_fixed(x,alpha,beta,epsi)
 F=[x(1)-1+alpha*x(1)^2-x(2)-epsi*x(1)^5; x(2)- beta*x(1)+ epsi*x(2)^5;];
end

