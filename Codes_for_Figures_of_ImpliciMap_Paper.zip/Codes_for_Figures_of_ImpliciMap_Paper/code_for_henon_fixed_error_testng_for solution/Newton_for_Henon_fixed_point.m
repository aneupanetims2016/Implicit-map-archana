function x = Newton_for_Henon_fixed_point(x0,alpha,beta,epsi)
x=x0;
  for i=1:10
  F = funct_Henon_fixed(x,alpha,beta,epsi);
  DF = Derivative__Hfixed_function(x,alpha,beta,epsi);
%    hn=intval((-1))*linsolve(DF,F);
%    norm(hn)
   x= x-DF^(-1)*F;
   end
funct_Henon_fixed(x,alpha,beta,epsi);
end


