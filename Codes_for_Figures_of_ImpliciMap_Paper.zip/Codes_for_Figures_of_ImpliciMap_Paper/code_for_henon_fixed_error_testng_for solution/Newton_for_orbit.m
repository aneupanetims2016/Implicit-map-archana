function x = Newton_for_orbit(x0,u0,alpha,beta,epsi)
x=x0;
for i=1:4
    F= [x(1)-(1-alpha*u0(1)^2+u0(2)+epsi*x(1)^5); x(2)-beta*u0(1)+epsi*x(2)^5];
    DF= [1-5*epsi*x(1)^4, 0; 0, 1+5*epsi*x(2)^4];   
    h=(-1)*linsolve(DF,F);
    x=x+h;    
end
x;
