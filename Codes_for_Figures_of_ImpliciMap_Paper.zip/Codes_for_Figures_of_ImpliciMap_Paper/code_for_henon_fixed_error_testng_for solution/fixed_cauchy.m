function [P,Q]=  fixed_cauchy(P,Q,p_f,mu,nu,alpha,beta,epsi,N)

 
for n = 2:N-1
      
      %Compute the homological matrix A:    
    A =  B_1_forEigen(p_f,alpha,beta,epsi)+(mu^n)*B_o_forEigen(p_f,alpha,beta,epsi);
    QB = B_1_forEigen(p_f,alpha,beta,epsi)+ (nu^n)*B_o_forEigen(p_f,alpha,beta,epsi);
    %     %Compute the right hand side of the homological equatoin:
    
    %for a^2 and a^5
     temp_P1 = P(1, 1:n+1);
     temp_P1(1) = 0;
     temp_P1(n+1) = 0;
     temp_P2 = fliplr(temp_P1);    
     sum1 = (-1)*alpha*sum(temp_P1.*temp_P2).*mu^n; 
     

     
     sum2_test = epsi*conv5(P(1, 1:n+1), n);
     
     
     %      
%       if n == 2
%          sum2
%          sum2_test
%           
%          crashNow = crashHere 
%       end
     
     
     
     
      sum3_test = (-1)*epsi*conv5(P(2, 1:n+1), n);
     
    
     
      sum4 = sum1 + sum2_test;
      %sum4 = sum1 +sum2;
      %S = [sum4;sum3;]; 
      S = [sum4; sum3_test];
      thisCoef = A\S;
     P(:, n+1) = thisCoef;
    
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    temp_Q1 = Q(1, 1:n+1);
     temp_Q1(1) = 0;
     temp_Q1(n+1) = 0;
     temp_Q2 = fliplr(temp_Q1);    
     Qsum1 = (-1)*alpha*sum(temp_Q1.*temp_Q2).*nu^n; 
     
    


     
     Qsum2_test = epsi*conv5(Q(1, 1:n+1), n);
     
     
  
         
      Qsum3_test = -epsi*conv5(Q(2, 1:n+1), n);
       
      Qsum4 = Qsum1 + Qsum2_test;
      QS = [Qsum4;Qsum3_test;];      
      QthisCoef = QB\QS;
      Q(:, n+1) = QthisCoef;      
     
end
end
