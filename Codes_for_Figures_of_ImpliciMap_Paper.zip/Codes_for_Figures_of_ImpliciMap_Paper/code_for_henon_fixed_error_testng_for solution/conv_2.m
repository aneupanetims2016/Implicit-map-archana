function s = conv_2(a, n)

s = 0;
for k = 1:n-1
   s = s + a(n-k+1)*a(k+1); 
end


end