function DF = Derivative__Hfixed_function(x,alpha,beta,epsi);
DF = [1 + 2*alpha*x(1)- 5*epsi*x(1).^4, -1; -beta, 1 + 5*epsi*x(2).^4;];
end

