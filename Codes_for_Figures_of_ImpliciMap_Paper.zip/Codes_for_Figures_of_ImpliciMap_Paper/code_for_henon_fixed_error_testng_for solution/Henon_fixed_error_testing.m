%error testing for 1D henon implicit fixed point

clear
format long

alpha = 1.4;
beta  = 0.3;
epsi  = 0.001;
N     = 50;        %Polynomial approximation order
scale_s = 3.0;
scale_u = 1.1;

x0 =[1;1];
p0 = Newton_for_Henon_fixed_point(x0,alpha,beta,epsi)
 

%Eigenvalues and Eigen Vectors
[R,Sigma] = eigs(Diff_for_Eigen(p0,alpha,beta, epsi));


% For manofold nearby fixed point
 P = zeros(2,N+1);
 Q = zeros(2,N+1);
 Lambda = Sigma(1,1); %unstable
 Tambda = Sigma(2,2); %stable
 mu = Lambda^(-1);
 nu = Tambda^(-1);
 P(:,1) = p0;
 P(:,2) = scale_u*R(:,1);
 Q(:,1) = p0;
 Q(:,2) = scale_s*R(:,2);
 P;
 Q;
 

 [P,Q]=fixed_cauchy(P,Q,p0,mu,nu,alpha,beta,epsi,N); 

P;%unstable
Q;%stable

numPoints = 100;
Thetas_S = linspace(-1,1, numPoints);%for stable
Thetas_U = linspace(-1/Lambda, 1/Lambda, numPoints); %for unstable
%Stable case
 Q_N_theta = [real(polyval(fliplr(Q(1, :)), Thetas_S));
                    real(polyval(fliplr(Q(2, :)), Thetas_S))];
 Q_N_Tambda_theta = [real(polyval(fliplr(Q(1, :)), Tambda*Thetas_S));
                    real(polyval(fliplr(Q(2, :)), Tambda*Thetas_S))]; 
                
   D=zeros(2,100);
   error=zeros(1,100);
  for i=1:100
    x = [Q_N_theta(:,i); Q_N_Tambda_theta(:,i)];
    D(:,i) = Imp_henon1(x, alpha, beta,epsi);
    error(i) = norm(D(:,i),inf);
  end  
    error;
   Stable_error_max_S = max(error) %stable error
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %stable case for P(theta)= f^(-1)(P(lambda theta))
    Q_N_Tambda_theta;    
    K=2;
 iterates_S1=zeros(2,numPoints,K); 
 iterates_S1(:,:,1)= Q_N_Tambda_theta;
  for j=2:K
    for i=1:numPoints
       v0=iterates_S1(:,i,j-1); %unstable        
       y = back_function(v0,alpha,beta);
       iterates_S1(:,i,j)= Newton_back_function(y,v0,alpha,beta,epsi);
    end
 end   
    S3=iterates_S1(:,:,2);
    S4=Q_N_theta;
    error_2=zeros(1,numPoints);
    for i=1:numPoints
    error_2(i)=norm(S3(:,i)-S4(:,i),inf);   
    end
   Stable_error_max_F_S = max(error_2)  %P(theta)= f^(-1)(p(lambda theta)) error stable
    
    
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Unstable case
  P_N_theta = [real(polyval(fliplr(P(1, :)), Thetas_U)); %unstable
                    real(polyval(fliplr(P(2, :)), Thetas_U))];
 P_N_Lambda_theta= [real(polyval(fliplr(P(1, :)), Lambda*Thetas_U));
                    real(polyval(fliplr(P(2, :)), Lambda*Thetas_U))]; 
                
    D_U = zeros(2,100);
   error_U = zeros(1,100);
  for i=1:100
    x=[P_N_theta(:,i); P_N_Lambda_theta(:,i)];
    D_U(:,i)= Imp_henon1(x, alpha, beta, epsi);
    error_U(i)= norm(D_U(:,i),inf);
  end  
    error_U;
   Unstable_error_max_U = max(error_U) %unstable error
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %This is for unstable orbit
    P_N_theta;    
    K=2;
 iterates_S=zeros(2,numPoints,K); 
 iterates_S(:,:,1)= P_N_theta;
  for j=2:K
    for i=1:numPoints
       u0=iterates_S(:,i,j-1); %unstable        
       y = for_function(u0,alpha,beta);
       iterates_S(:,i,j)= Newton_for_orbit(y,u0,alpha,beta,epsi);
    end
 end   
    S1=iterates_S(:,:,2);
    S2=P_N_Lambda_theta;
    error_1=zeros(1,numPoints);
    for i=1:numPoints
    error_1(i)=norm(S1(:,i)-S2(:,i),inf);   
    end
  Unstable_error_max_F_U= max(error_1)  %f(P(theta))= p(lambda theta) error unstable
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
   
 