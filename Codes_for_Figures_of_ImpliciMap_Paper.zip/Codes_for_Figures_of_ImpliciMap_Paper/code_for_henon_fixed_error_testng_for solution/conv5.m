function s = conv5(a, n)

s = 0;

for k1 = 0:n
    for k2 = 0:k1
        for k3 = 0:k2
            for k4 = 0:k3
                if ((n-k1 ~= n) & (k1-k2 ~= n) & (k2-k3 ~= n) ...
                        & (k3-k4 ~= n) & (k4 ~= n))      
                    s = ...
                        s + a(n-k1+1)*a(k1-k2+1)*a(k2-k3+1)*a(k3-k4+1)*a(k4+1);
                end
            end
        end
    end
end


end