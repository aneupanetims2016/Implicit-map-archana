function f = for_function(u0,alpha,beta)
f=[1-alpha*u0(1)^2+u0(2);beta*u0(1);];
end
