function Fx = newt_connect_function(K,P,Q,x0,alpha,beta,epsi)
x=x0;
K=2*(K+1);
F=zeros(K,1);
F(1,1)=real(polyval(fliplr(P(1, :)),x(1)))-x(2);
F(2,1)=real(polyval(fliplr(P(2, :)),x(1)))-x(3);
F(K-1,1)= x(K-2)-real(polyval(fliplr(Q(1, :)),x(K)));
F(K,1) = x(K-1)-real(polyval(fliplr(Q(2, :)),x(K)));
for i=1:(K-4)/2
    F(2*i+1,1)=x(2*i+2)-(1-alpha*x(2*i)^2+x(2*i+1)+epsi*x(2*i+2)^5);
    F(2*i+2,1)=x(2*i+3)-beta*x(2*i)+epsi*x(2*i+3)^5;
    
end
Fx=F;
%     F=[real(polyval(fliplr(P(1, :)),x(1)))-x(2);...
%         real(polyval(fliplr(P(2, :)),x(1)))-x(3);...
%        x(4)-(1-alpha*x(2)^2+x(3)+epsi*x(4)^5);...
%        x(5)-beta*x(2)+epsi*x(5)^5;...
%        x(6)-(1-alpha*x(4)^2+x(5)+epsi*x(6)^5);...
%        x(7)-beta*x(4)+epsi*x(7)^5;...
%        x(8)-(1-alpha*x(6)^2+x(7)+epsi*x(8)^5);...
%        x(9)-beta*x(6)+epsi*x(9)^5;
%        x(8)-real(polyval(fliplr(Q(1, :)), x(10)));
%        x(9)-real(polyval(fliplr(Q(2, :)), x(10)));];
