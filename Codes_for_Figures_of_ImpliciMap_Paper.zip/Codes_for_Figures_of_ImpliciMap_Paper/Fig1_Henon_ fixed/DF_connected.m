function DFx = DF_connected(K,P,Q,x0,alpha,beta,epsi,N)
x=x0;
K=2*(K+1);
D_theta_P=D_theta_1(P,N,x(1));
D_theta_Q=D_theta_1(Q,N,x(K));
DF=zeros(K,K);
DF(1:2,1)=D_theta_P;
DF(K-1:K,K)=-1*D_theta_Q;
DF(1,2)=-1;
DF(2,3)=-1;
DF(K-1,K-2)=1;
DF(K,K-1)=1;
for i= 1:(K-4)/2
    DF(2*i+1,2*i:2*i+2)=[2*alpha*x(2*i),-1,1-5*epsi*x(2*i+2)^4];
    DF(2*i+2,2*i:2*i+3)=[-beta,0,0,1+5*epsi*x(2*i+3)^4];    
end
DFx=DF;
% D_theta_P=D_theta_1(P,N,x(1));
%       D_sigma_Q=D_theta_1(Q,N,x(10));
%    
%    DF= [D_theta_P(1),-1,0,0,0,0,0,0,0,0;...
%         D_theta_P(2),0,-1,0,0,0,0,0,0,0;...
%        0,2*alpha*x(2),-1, 1-5*epsi*x(4)^4,0,0,0,0,0,0;...
%        0,-beta,0,0,1+5*epsi*x(5)^4,0,0,0,0,0;...
%        0,0,0,2*alpha*x(4),-1,1-5*epsi*x(6)^4,0,0,0,0;...
%        0,0,0,-beta,0,0,1+5*epsi*x(7)^4,0,0,0;...
%        0,0,0,0,0,2*alpha*x(6),-1,1-5*epsi*x(8)^4,0,0;...
%        0,0,0,0,0,-beta,0,0,1+5*epsi*x(9)^4,0;...
%        0,0,0,0,0,0,0,1,0,-D_sigma_Q(1);...
%        0,0,0,0,0,0,0,0,1,-D_sigma_Q(2);];
