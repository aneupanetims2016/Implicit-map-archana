function x =  Newton_for_connection(N,P,Q,theta,x1,x2,x3,x4,sigma,alpha,beta,epsi,K)
x0=[theta;x1(1);x1(2);x2(1);x2(2);x3(1);x3(2);x4(1);x4(2);sigma;];
x=x0;
error=1;
count=0;
while(error > 10^(-14))
    count=count+1
      F=newt_connect_function(K,P,Q,x,alpha,beta,epsi);
      DF=DF_connected(K,P,Q,x,alpha,beta,epsi,N);   
   
   h=(-1)*linsolve(DF,F);
   error=norm(h);
    x=x+h; 
        
end

