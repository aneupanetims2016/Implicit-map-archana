function f = back_function(u0,alpha,beta)
f=[u0(2)/beta; u0(1)-1+alpha*u0(2)^2/beta^2];
end

