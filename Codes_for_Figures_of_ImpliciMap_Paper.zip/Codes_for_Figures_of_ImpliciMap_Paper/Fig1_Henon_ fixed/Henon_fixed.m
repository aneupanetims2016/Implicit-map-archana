%Melbourne%validation for 1D henon implicit fixed point

clear
format long

alpha = 1.4;
beta  = 0.3;
epsi  = 0.01;
N     = 20;        %Polynomial approximation order
scale = 0.5;

%  x0 = [-3;3];
p3=[1;2];
p_3= Newton_for_Henon_fixed_point(p3,alpha,beta,epsi);
 
p2 = [-3;3];
p_f1 = Newton_for_Henon_fixed_point(p2,alpha,beta,epsi);
%Fixed Point of Henon Imp
x0 =[1;1];
p0 = Newton_for_Henon_fixed_point(x0,alpha,beta,epsi);
 
 figure
 hold on
 plot(p_f1(1),p_f1(2),'r*')
 plot(p0(1),p0(2),'k*')
 plot(p_3(1),p_3(2),'g*')
 hold off
%  return
%Eigenvalues and Eigen Vectors
[R,Sigma] = eigs(Diff_for_Eigen(p0,alpha,beta, epsi));


% For manofold nearby fixed point
 P = zeros(2,N+1);
 Q = zeros(2,N+1);
 Lambda = Sigma(1,1);
 Tambda = Sigma(2,2);
 mu = Lambda^(-1);
 nu=Tambda^(-1);%??????
 P(:,1) = p0;
 P(:,2) = scale*R(:,1);
 Q(:,1) =p0;
 Q(:,2)=scale*R(:,2);
 P;
 Q ;
 

 [P,Q]=fixed_cauchy(P,Q,p0,mu,nu,alpha,beta,epsi,N); 

P;
Q;

numPoints = 20000;
NumR =500;
radii = abs(mu);
Thetas = linspace(-1,1, numPoints);
Thetas1 = linspace(radii,1,NumR);
% Thetas2
Wu1 = [real(polyval(fliplr(P(1, :)), Thetas));
                   real(polyval(fliplr(P(2, :)), Thetas))];
               
Wu2 = [real(polyval(fliplr(Q(1, :)), Thetas));
                   real(polyval(fliplr(Q(2, :)), Thetas))];
               
Wuc =  [real(polyval(fliplr(P(1, :)), Thetas1));
                   real(polyval(fliplr(P(2, :)), Thetas1))];              
Wsc = [real(polyval(fliplr(Q(1, :)), Thetas1));
                   real(polyval(fliplr(Q(2, :)), Thetas1))];                 
               


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

figure
hold on
  plot(Wu1(1,:), Wu1(2,:), 'b','LineWidth',2)
  plot(Wu2(1,:), Wu2(2,:), 'r','LineWidth',2) 
%    plot(Wuc(1,:), Wuc(2,:), '*')
   plot(Wsc(1,:), Wsc(2,:), 'k') 
  plot(p0(1),p0(2),'k*')
  title('Stable and unstable 1D manifold of a fixed point')