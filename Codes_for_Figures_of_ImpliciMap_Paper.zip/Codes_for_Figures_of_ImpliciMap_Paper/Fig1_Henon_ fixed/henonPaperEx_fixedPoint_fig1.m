%Code for 1D henon implicit fixed point fig 1

clear
format long

alpha = 1.4;
beta  = 0.3;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We work on different values of epsilon
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
epsi  = 0.0315          %0.01, 0.02; -- Still look Henon-ish
                      %0.03, 0.031, 0.03115 -- Develops a ``bend''
                      %0.0312, 0.0315 -- one ``line'' broken...
                      %0.04 -- A ``hole'' in the attractor...
N     = 75;        %Polynomial approximation order
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We work on taking different scale
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
scale_u = 0.01;       %epsi = 0     -- scale_u = 10 
                   %epsi = 0.001  -- scale_u = 1.3
                   %epsi = 0.01   -- scale_u = 1
                   %epsi = 0.031  -- scale_u = 0.85
                   %epsi = 0.4    -- scale_u = 0.6
                   %
scale_s = 18;      %epsi = 0      -- scale_s = 62
                   %epsi = 0.001  -- scale_s = 25
                   %epsi = 0.01   -- scale_s = 22
                   %epsi = 0.031  -- scale_s = 18
                   %epsi = 0.4    -- scale_s = 15




%  x0 = [-3;3];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Intitial guess of fixed point and we use Newton's method to get converged
% fixed point. While computing this fixed point code, we use the following
% function : funct_Henon_fixed.m and Derivative__Hfixed_function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p3=[1;2];
p_3= Newton_for_Henon_fixed_point(p3,alpha,beta,epsi);

p2 = [-3;3];
p_f1 = Newton_for_Henon_fixed_point(p2,alpha,beta,epsi);


%Fixed Point of Henon Imp
x0 =[1;1];
p0 = Newton_for_Henon_fixed_point(x0,alpha,beta,epsi);
%%%%%%%%%%%%%%%%%%%%%%
% p0 is a fixed point we take to work on.
%%%%%%%%%%%%%%%%%%%%%

x1 = p0(1)
y1 = p0(2)
test_p01 = x1 - (1 - alpha*x1^2 + y1 + epsi*x1^5) % testing to check how close the fixed point is.
test_p02 = y1 - beta*x1 + epsi*y1^5


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finding Eigenvalues and Eigen Vectors of the linearization of the
% function
%%%%%%%%%%%%%%%%%%%
[R,Sigma] = eigs(Diff_for_Eigen(p0, alpha, beta, epsi));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For manofold nearby fixed point
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
 Lambda = Sigma(1,1);
 Tambda = Sigma(2,2);
 

% [P,Q]=fixed_cauchy(P,Q,p0,mu,nu,alpha,beta,epsi,N); 

D1T = [1-5*epsi*p0(1)^4,                0;
                      0, 1+5*epsi*p0(2)^4]; 
                  
D2T = [2*alpha*p0(1),   -1;
                 -beta,  0];
                  
DF_test = -inv(D1T)*D2T;
[E_test, Sigma_test] = eigs(DF_test)

errorTest = norm(Diff_for_Eigen(p0, alpha, beta, epsi) - DF_test, inf) 


% return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computing coefficients solutions with homological equation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P = computeParameterization(...
                 p0, E_test(:,1), Sigma_test(1,1), scale_u, alpha, beta, epsi, N)
 

        
 Q = computeParameterization(...
                 p0, E_test(:,2), Sigma_test(2,2), scale_s, alpha, beta, epsi, N)
             
                          
             
             
theta = -abs(Lambda)^(-1);
P_theta = evaluateParm(theta, P, N);
P_lambdaTheta = evaluateParm(Lambda*theta, P, N);
             
test_1 = norm(implicitHenon_T(P_lambdaTheta, P_theta, alpha, beta, epsi), inf)            


fx = evaluateImplicitmap_henon(P_theta, alpha, beta, epsi);

test_1_impMap = norm(fx - P_lambdaTheta)


theta = 1
Q_theta = evaluateParm(theta, Q, N);
Q_tambdaTheta = evaluateParm(Tambda*theta, Q, N);
             
test_2 = norm(implicitHenon_T(Q_tambdaTheta, Q_theta, alpha, beta, epsi), inf)            


     
             
             
%error = norm(P - P_test, inf)            
         


 coefAxis = linspace(0, N, N+1);
 figure 
 hold on 
 plot(coefAxis, log(max(abs(P)))/log(10))
 
 figure 
 hold on 
 plot(coefAxis, log(max(abs(Q)))/log(10))
 

 
 
numPoints = 20000;
NumR =500;

Thetas = linspace(-1,1, numPoints);

 
%  Wu = [real(polyval(fliplr(P_test(1, :)), Thetas));
%         real(polyval(fliplr(P_test(2, :)), Thetas))];
%                 
   
% 
 Wu = [real(polyval(fliplr(P(1, :)), Thetas));
        real(polyval(fliplr(P(2, :)), Thetas))];
%                  
%    
   
Ws = [real(polyval(fliplr(Q(1, :)), Thetas));
       real(polyval(fliplr(Q(2, :)), Thetas))];
  
   
% Wuc =  [real(polyval(fliplr(P(1, :)), Thetas1));
%                    real(polyval(fliplr(P(2, :)), Thetas1))];              
% Wsc = [real(polyval(fliplr(Q(1, :)), Thetas1));
%                    real(polyval(fliplr(Q(2, :)), Thetas1))];                 
               


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

% figure
% hold on
%   plot(Wu(1,:), Wu(2,:), 'b','LineWidth',2)
%   plot(Ws(1,:), Ws(2,:), 'r','LineWidth',2) 
%   plot(p0(1),p0(2),'k*')
 


figure
hold on
  %plot(Wu(1,:), Wu(2,:), 'b','LineWidth',2)
  plot(Ws(1,:), Ws(2,:), 'r','LineWidth',2) 
  plot(p0(1),p0(2),'k*')
  legend('Stable Manifold')
  axis([-5 5 -5 5])
 
  
numPoints = 1000
parm_fundDomain = linspace(1/abs(Lambda), 1, numPoints);
Wu1 = zeros(2, numPoints);  
Wu2 = zeros(2, numPoints);
Wu3 = zeros(2, numPoints);
Wu4 = zeros(2, numPoints);
Wu5 = zeros(2, numPoints);
Wu6 = zeros(2, numPoints);
Wu7 = zeros(2, numPoints);
Wu8 = zeros(2, numPoints);

parm_fundDomainB = linspace(-1, -1/abs(Lambda), numPoints);
Wu1B = zeros(2, numPoints);  
Wu2B = zeros(2, numPoints);
Wu3B = zeros(2, numPoints);
Wu4B = zeros(2, numPoints);
Wu5B = zeros(2, numPoints);
Wu6B = zeros(2, numPoints);
Wu7B = zeros(2, numPoints);
Wu8B = zeros(2, numPoints);

for k = 1:numPoints
    
    k
    
    theta = parm_fundDomain(k);
    P_theta = evaluateParm(theta, P, N);
    fx = evaluateImplicitmap_henon(P_theta, alpha, beta, epsi);
    Wu1(:, k) = fx;
    
    fx2 = evaluateImplicitmap_henon(fx, alpha, beta, epsi);
    Wu2(:, k) = fx2;
    
    fx3 = evaluateImplicitmap_henon(fx2, alpha, beta, epsi);
    Wu3(:, k) = fx3;
    
    fx4 = evaluateImplicitmap_henon(fx3, alpha, beta, epsi);
    Wu4(:, k) = fx4;
    
    fx5 = evaluateImplicitmap_henon(fx4, alpha, beta, epsi);
    Wu5(:, k) = fx5;
    
     fx6 = evaluateImplicitmap_henon(fx5, alpha, beta, epsi);
    Wu6(:, k) = fx6;
     fx7 = evaluateImplicitmap_henon(fx6, alpha, beta, epsi);
    Wu7(:, k) = fx7;
     fx8 = evaluateImplicitmap_henon(fx7, alpha, beta, epsi);
    Wu8(:, k) = fx8;
    
    theta = parm_fundDomainB(k);
    P_theta = evaluateParm(theta, P, N);
    fx = evaluateImplicitmap_henon(P_theta, alpha, beta, epsi);
    Wu1B(:, k) = fx;
    
    fx2 = evaluateImplicitmap_henon(fx, alpha, beta, epsi);
    Wu2B(:, k) = fx2;
    
    fx3 = evaluateImplicitmap_henon(fx2, alpha, beta, epsi);
    Wu3B(:, k) = fx3;
    
    fx4 = evaluateImplicitmap_henon(fx3, alpha, beta, epsi);
    Wu4B(:, k) = fx4;
    
    fx5 = evaluateImplicitmap_henon(fx4, alpha, beta, epsi);
    Wu5B(:, k) = fx5;
    
    fx6 = evaluateImplicitmap_henon(fx5, alpha, beta, epsi);
    Wu6B(:, k) = fx6;
    fx7 = evaluateImplicitmap_henon(fx6, alpha, beta, epsi);
    Wu7B(:, k) = fx7;
    fx8 = evaluateImplicitmap_henon(fx7, alpha, beta, epsi);
    Wu8B(:, k) = fx8;
    
end
  
  

figure
hold on
  
  plot(Wu1(1,:), Wu1(2,:), 'c.','LineWidth',2)
  plot(Wu2(1,:), Wu2(2,:), 'c.','LineWidth',2)
  plot(Wu3(1,:), Wu3(2,:), 'c.','LineWidth',2)
  plot(Wu4(1,:), Wu4(2,:), 'c.','LineWidth',2)
  plot(Wu5(1,:), Wu5(2,:), 'c.','LineWidth',2)
  plot(Wu6(1,:), Wu6(2,:), 'c.','LineWidth',2)
  plot(Wu7(1,:), Wu7(2,:), 'c.','LineWidth',2)
  plot(Wu8(1,:), Wu8(2,:), 'c.','LineWidth',2)
  
  plot(Wu1B(1,:), Wu1B(2,:), 'c.','LineWidth',2)
  plot(Wu2B(1,:), Wu2B(2,:), 'c.','LineWidth',2)
  plot(Wu3B(1,:), Wu3B(2,:), 'c.','LineWidth',2)
  plot(Wu4B(1,:), Wu4B(2,:), 'c.','LineWidth',2)
  plot(Wu5B(1,:), Wu5B(2,:), 'c.','LineWidth',2)
  plot(Wu6B(1,:), Wu6B(2,:), 'c.','LineWidth',2)
  plot(Wu7B(1,:), Wu7B(2,:), 'c.','LineWidth',2)
  plot(Wu8B(1,:), Wu8B(2,:), 'c.','LineWidth',2)
  %plot(Ws(1,:), Ws(2,:), 'r','LineWidth',5) 
 
  plot(Wu(1,:), Wu(2,:), 'b','LineWidth',5)
   plot(p0(1),p0(2),'k*')
   legend('Unstable Manifold')
  axis([-3 3 -0.6 0.6])  
  
  
figure
hold on
  plot(Ws(1,:), Ws(2,:), 'r','LineWidth',5) 
  plot(p0(1),p0(2),'k*')
  plot(Wu(1,:), Wu(2,:), 'b','LineWidth',5)
  legend('Stable Manifold')
  axis([-2 2 -6 6])  
  
  
  
